import * as React from 'react';
type NavKey = 'dashboard' | 'employee' | 'approvals';
export interface INavBarProps {
    activeItem?: NavKey;
    onNavigate?: (view: string) => void;
    /** When set (e.g. on Approvals page), overrides the fetched pending count */
    pendingApprovalsCount?: number;
}
declare const NavBar: React.FC<INavBarProps>;
export default NavBar;
//# sourceMappingURL=navbar.d.ts.map