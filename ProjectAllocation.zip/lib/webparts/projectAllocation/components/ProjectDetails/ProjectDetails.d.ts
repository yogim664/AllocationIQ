import * as React from 'react';
import type { ProjectRow } from '../Dashboard/dashboard';
export interface IProjectDetailsProps {
    project: ProjectRow;
    onBack: () => void;
}
declare const ProjectDetails: React.FC<IProjectDetailsProps>;
export default ProjectDetails;
//# sourceMappingURL=ProjectDetails.d.ts.map