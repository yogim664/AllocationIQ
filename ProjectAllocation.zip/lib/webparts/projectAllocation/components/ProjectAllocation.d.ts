import * as React from 'react';
import type { IProjectAllocationProps } from './IProjectAllocationProps';
import '../assets/style.css';
declare const ProjectAllocation: React.FC<IProjectAllocationProps>;
export default ProjectAllocation;
//# sourceMappingURL=ProjectAllocation.d.ts.map