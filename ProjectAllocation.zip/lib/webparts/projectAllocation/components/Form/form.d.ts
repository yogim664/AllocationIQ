import * as React from 'react';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
interface IProjectIntakeFormProps {
    onClose?: () => void;
    onStepChange?: (step: number) => void;
}
declare const ProjectIntakeForm: React.FC<IProjectIntakeFormProps>;
export default ProjectIntakeForm;
//# sourceMappingURL=form.d.ts.map