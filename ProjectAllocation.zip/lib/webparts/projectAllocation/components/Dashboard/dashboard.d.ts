import * as React from 'react';
export interface ProjectRow {
    id: string;
    name: string;
    subtitle: string;
    startDate: string;
    endDate: string;
    budget: string;
    team: string[];
    teamExtra: number;
}
export interface IDashboardProps {
    onCreateProject: () => void;
    onOpenProject: (project: ProjectRow) => void;
    onNavigate?: (view: string) => void;
}
declare const Dashboard: React.FC<IDashboardProps>;
export default Dashboard;
//# sourceMappingURL=dashboard.d.ts.map