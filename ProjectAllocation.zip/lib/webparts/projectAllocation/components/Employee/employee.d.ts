import * as React from 'react';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
export interface IEmployeeItem {
    Id: number;
    Title: string;
    field_1: string;
    field_2: string;
    field_3: string;
    field_4: string;
    field_5: number | null;
    field_6: string;
    field_7: string;
    field_8: string;
    field_9: string;
    field_10: string;
}
export interface IEmployeeProps {
    onNavigate?: (view: string) => void;
}
declare const Employee: React.FC<IEmployeeProps>;
export default Employee;
//# sourceMappingURL=employee.d.ts.map