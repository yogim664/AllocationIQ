import * as React from 'react';
export interface IUserBadgeClassNames {
    userBadge: string;
    userText: string;
    userName: string;
    userMail: string;
    userAvatar: string;
}
export interface IUserBadgeProps {
    classNames: IUserBadgeClassNames;
}
declare const UserBadge: React.FC<IUserBadgeProps>;
export default UserBadge;
//# sourceMappingURL=UserBadge.d.ts.map