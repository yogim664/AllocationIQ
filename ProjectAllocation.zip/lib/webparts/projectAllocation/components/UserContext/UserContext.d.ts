import * as React from 'react';
import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IUserContextValue {
    displayName: string;
    email: string;
    initials: string;
    greeting: string;
}
export interface IUserContextProviderProps {
    context: WebPartContext;
    children: React.ReactNode;
}
export declare const UserContextProvider: React.FC<IUserContextProviderProps>;
export declare const useUser: () => IUserContextValue;
//# sourceMappingURL=UserContext.d.ts.map