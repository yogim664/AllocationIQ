export interface AiResponse {
    response: string;
}
export declare const uploadPdfAndAnalyze: (fileOrText: File | string) => Promise<AiResponse>;
export declare const StaffRecommandAgent: (skills: string[], ProjectData: any) => Promise<{
    EmployeeID: string;
    initials: string;
    name: string;
    role: string;
    department: string;
    match: number;
    availability: number;
    success: number;
}[]>;
export declare const ProjectPlanAgent: (Staff: string[], ProjectData: any) => Promise<({
    startDate: string;
    endDate: string;
    status: string;
    slNo: number;
    feature: string;
    task: string;
    efforts: number;
    lane: string;
    startSlot: number;
    durationSlots: number;
    assignee: string;
    availability: number;
} | {
    startDate: string;
    endDate: string;
    status: string;
    slNo: number;
    feature: string;
    task: string;
    efforts: number;
    lane: string;
    startSlot: number;
    durationSlots: number;
    assignee: string;
    availability?: undefined;
} | {
    startDate: string;
    endDate: string;
    status: string;
    slNo: number;
    feature: string;
    task: string;
    efforts: number;
    lane: string;
    startSlot: number;
    durationSlots: number;
    assignee: string;
    availability?: undefined;
})[]>;
//# sourceMappingURL=aiagents.d.ts.map