export declare const extractPdfText: (file: File) => Promise<string>;
//# sourceMappingURL=extractpdf.d.ts.map