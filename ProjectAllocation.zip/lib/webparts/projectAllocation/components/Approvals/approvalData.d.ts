/** Count of projects in the Pending Approval Queue (isManagerApproved === false). */
export declare function fetchPendingApprovalsCount(): Promise<number>;
//# sourceMappingURL=approvalData.d.ts.map