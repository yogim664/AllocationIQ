import * as React from 'react';
interface StaffMember {
    initials: string;
    name: string;
    role: string;
    department: string;
    match: number;
    availability: number;
    success: number;
}
interface PlanItem {
    slNo: number;
    feature: string;
    task: string;
    startDate: string;
    endDate: string;
    efforts: number;
    lane: 'development' | 'demo' | 'testing';
    assignee: string;
    status: 'Not Started' | 'In Progress' | 'Done';
}
export interface ApprovalProject {
    spItemId: number;
    id: string;
    name: string;
    subtitle: string;
    client: string;
    budget: string;
    startDate: string;
    endDate: string;
    priority: 'Low' | 'Medium' | 'High' | 'Critical';
    skills: string[];
    team: string[];
    teamExtra: number;
    status: 'Pending' | 'Approved' | 'Rejected';
    staff: StaffMember[];
    planItems: PlanItem[];
}
export interface IApprovalsProps {
    onNavigate?: (view: string) => void;
}
declare const Approvals: React.FC<IApprovalsProps>;
export default Approvals;
//# sourceMappingURL=approvals.d.ts.map