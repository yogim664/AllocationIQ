import { WebPartContext } from "@microsoft/sp-webpart-base";
import { GraphFI } from "@pnp/graph";
import { SPFI } from "@pnp/sp";
export declare const initService: (context: WebPartContext) => void;
export declare const getSP: () => SPFI;
export declare const getGraph: () => GraphFI;
//# sourceMappingURL=initservice.d.ts.map