import * as React from 'react';
import styles from './dashboard.module.scss';
import NavBar from '../NavBar/navbar';
import UserBadge from '../UserContext/UserBadge';
import { getSP } from '../../../../service/initservice';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface ProjectRow {
  id: string;
  name: string;
  subtitle: string;
  startDate: string;
  endDate: string;
  budget: string;
  team: string[];
  teamExtra: number;
}

export interface IDashboardProps {
  onCreateProject: () => void;
  onOpenProject: (project: ProjectRow) => void;
  onNavigate?: (view: string) => void;
}

// ─── Constants ────────────────────────────────────────────────────────────────

const SAMPLE_PROJECTS: ProjectRow[] = [
  {
    id: 'PRJ-2026-01',
    name: 'Project Orion Data Nexus',
    subtitle: 'Cloud architecture, infrastructure scale',
    startDate: 'Jan 15, 2026',
    endDate: 'Aug 30, 2026',
    budget: '$142,500',
    team: ['SJ', 'AK', 'TM'],
    teamExtra: 2
  },
  {
    id: 'PRJ-2026-02',
    name: 'Project Helios AI Optimizer',
    subtitle: 'Core telemetry and workflow analytics',
    startDate: 'Feb 01, 2026',
    endDate: 'Dec 15, 2026',
    budget: '$295,000',
    team: ['SM', 'RG', 'NP'],
    teamExtra: 3
  },
  {
    id: 'PRJ-2026-03',
    name: 'Project Aurora CoPilot',
    subtitle: 'Natural language interface extension',
    startDate: 'Mar 10, 2026',
    endDate: 'Oct 20, 2026',
    budget: '$88,000',
    team: ['CM', 'NL', 'HM'],
    teamExtra: 2
  }
];

const AVATAR_COLORS = ['#dbeafe', '#e0e7ff', '#fce7f3', '#d1fae5', '#fef3c7'];
const AVATAR_TEXT   = ['#6d28d9', '#7c3aed', '#be185d', '#047857', '#b45309'];

// ─── Helpers ──────────────────────────────────────────────────────────────────

const getFieldValue = (item: any, fieldName: string): any => {
  if (!item) return undefined;
  const lower = fieldName.toLowerCase();
  for (const key of Object.keys(item)) {
    if (key.toLowerCase() === lower) {
      const val = item[key];
      if (val && typeof val === 'object') {
        if (val.LookupValue !== undefined) return val.LookupValue;
        if (val.Title !== undefined) return val.Title;
        if (val.Label !== undefined) return val.Label;
      }
      return val;
    }
  }
  return undefined;
};

const formatDate = (dateStr: string): string => {
  if (!dateStr) return '';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
  } catch {
    return dateStr;
  }
};

const getInitials = (fullName: string): string => {
  if (!fullName) return '??';
  const parts = fullName.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
};

const parseBudget = (val: unknown): number => {
  if (typeof val === 'number') return isNaN(val) ? 0 : val;
  if (typeof val === 'string') {
    const cleaned = val.replace(/[^0-9.-]+/g, '');
    const n = parseFloat(cleaned);
    return isNaN(n) ? 0 : n;
  }
  return 0;
};

// ─── Component ────────────────────────────────────────────────────────────────

const Dashboard: React.FC<IDashboardProps> = ({ onCreateProject, onOpenProject, onNavigate }) => {
  const css = styles as typeof styles & Record<string, string>;

  // All hooks must be at the top of the component
  const [projects, setProjects] = React.useState<ProjectRow[]>([]);
  const [loading, setLoading]   = React.useState<boolean>(true);

  // Decide which list to render — SP data when available, otherwise sample data
  const projectsToRender = projects.length > 0 ? projects : SAMPLE_PROJECTS;

  // ── Derived stats ──────────────────────────────────────────────────────────

  const totalBudget = React.useMemo(
    () => projectsToRender.reduce((sum, p) => sum + parseBudget(p.budget), 0),
    [projectsToRender]
  );

  const avgDurationMonths = React.useMemo(() => {
    let totalMonths = 0;
    let valid = 0;
    projectsToRender.forEach((p) => {
      const start = new Date(p.startDate);
      const end   = new Date(p.endDate);
      if (!isNaN(start.getTime()) && !isNaN(end.getTime())) {
        totalMonths += Math.abs(end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24 * 30.4);
        valid++;
      }
    });
    return valid > 0 ? (totalMonths / valid).toFixed(1) : '0';
  }, [projectsToRender]);

  // ── Fetch from SharePoint ──────────────────────────────────────────────────

  const fetchProjects = React.useCallback(async (): Promise<void> => {
    try {
      setLoading(true);
      const sp = getSP();

      // Fetch Project list items
      const spItems: any[] = await sp.web.lists
        .getByTitle('Project')
        .items
        .select('Id', 'ProjectCode', 'ProjectName', 'Client', 'StartDate', 'EndDate', 'Budget', 'RequiredSkills', 'Description')
        .top(5000)();

      // Fetch ProjectParticipation to build team member lists
      let participations: any[] = [];
      try {
        participations = await sp.web.lists
          .getByTitle('ProjectParticipation')
          .items
          .select('field_2', 'field_3')
          .top(5000)();
      } catch {
        // ProjectParticipation may not exist yet; ignore gracefully
      }

      const mapped: ProjectRow[] = spItems.map((item) => {
        const projectCode = getFieldValue(item, 'ProjectCode') || '';
        const budgetVal   = getFieldValue(item, 'Budget');
        const budgetNum   = parseBudget(budgetVal);
        const budgetStr   = `$${budgetNum.toLocaleString()}`;
        const nameVal     = getFieldValue(item, 'ProjectName') || 'Untitled Project';
        const descVal     = getFieldValue(item, 'Description') || getFieldValue(item, 'Client') || '';
        const startVal    = getFieldValue(item, 'StartDate') || '';
        const endVal      = getFieldValue(item, 'EndDate') || '';
        const spId        = getFieldValue(item, 'Id') || '';

        // Collect team members for this project
        const members = participations
          .filter((p) => p.field_3 === projectCode && p.field_2)
          .map((p) => String(p.field_2));

        const visibleTeam = members.slice(0, 3).map(getInitials);
        const extraCount  = Math.max(0, members.length - 3);

        return {
          id:        projectCode || `PRJ-${spId}`,
          name:      nameVal,
          subtitle:  descVal,
          startDate: formatDate(startVal),
          endDate:   formatDate(endVal),
          budget:    budgetStr,
          team:      visibleTeam,
          teamExtra: extraCount
        } as ProjectRow;
      });

      setProjects(mapped);
    } catch (error) {
      console.error('Dashboard: Error fetching projects from SharePoint:', error);
      // On error, keep showing sample data (projects state stays empty)
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchProjects().catch(console.error);
  }, [fetchProjects]);

  // ── Render ─────────────────────────────────────────────────────────────────

  return (
    <div className={css.page}>
      <div className={css.pageMesh} aria-hidden="true" />
      <div className={css.pageOrb} aria-hidden="true" />
      <div className={css.pageOrb2} aria-hidden="true" />

      <NavBar activeItem="dashboard" onNavigate={onNavigate} />

      <main className={css.main}>
        {/* ── Top bar ── */}
        <header className={css.topBar}>
          <div className={css.topBarLeft}>
            <h2 className={css.workspaceTitle}>Project Workspace</h2>
            <span className={css.enterpriseBadge}>Enterprise</span>
          </div>
          <UserBadge classNames={{
            userBadge: css.userBadge,
            userText: css.userText,
            userName: css.userName,
            userMail: css.userMail,
            userAvatar: css.userAvatar
          }} />
        </header>

        {/* ── Stats row ── */}
        <section className={css.statsRow} aria-label="Workspace summary">
          <article className={`${css.statCard} ${css.statProjects}`}>
            <div className={css.statCardHead}>
              <p className={css.statLabel}>Active Projects</p>
              <span className={css.statIcon} aria-hidden="true">◆</span>
            </div>
            <p className={css.statValue}>{projectsToRender.length}</p>
            <span className={css.statTrend}>All on track</span>
          </article>
          <article className={`${css.statCard} ${css.statBudget}`}>
            <div className={css.statCardHead}>
              <p className={css.statLabel}>Total Budget</p>
              <span className={css.statIcon} aria-hidden="true">$</span>
            </div>
            <p className={css.statValue}>${(totalBudget / 1000).toFixed(1)}K</p>
            <span className={css.statTrend}>FY26 allocated</span>
          </article>
          <article className={`${css.statCard} ${css.statDuration}`}>
            <div className={css.statCardHead}>
              <p className={css.statLabel}>Avg. Duration</p>
              <span className={css.statIcon} aria-hidden="true">⏱</span>
            </div>
            <p className={css.statValue}>{avgDurationMonths} mo</p>
            <span className={css.statTrend}>Across pipeline</span>
          </article>
        </section>

        {/* ── Projects table ── */}
        <section className={css.card}>
          <div className={css.cardGlow} aria-hidden="true" />
          <div className={css.cardInner}>
            <div className={css.cardHead}>
              <div className={css.cardHeadText}>
                <span className={css.cardKicker}>Pipeline</span>
                <h3>Active Initiatives</h3>
                <p>Overview of current pipeline scope, schedules, and financial allocations.</p>
              </div>
              <button type="button" className={css.createBtn} onClick={onCreateProject}>
                <span className={css.createBtnIcon} aria-hidden="true">+</span>
                Create Project
              </button>
            </div>

            {loading ? (
              <div className={css.loadingWrap} aria-live="polite">
                <div className={css.spinner} />
                <span>Loading projects…</span>
              </div>
            ) : (
              <div className={css.tableWrap}>
                <table className={css.table}>
                  <thead>
                    <tr>
                      <th>Project ID</th>
                      <th>Project Name</th>
                      <th>Start Date</th>
                      <th>End Date</th>
                      <th className={css.budgetCol}>Budgeted Amount</th>
                      <th className={css.teamCol}>Team Members</th>
                      <th className={css.colAction} aria-hidden="true" />
                    </tr>
                  </thead>
                  <tbody>
                    {projectsToRender.map((project) => (
                      <tr
                        key={project.id}
                        className={css.projectRow}
                        onClick={() => onOpenProject(project)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            onOpenProject(project);
                          }
                        }}
                        tabIndex={0}
                        role="button"
                        aria-label={`Open ${project.name}`}
                      >
                        <td className={css.idCell}>
                          <span className={css.idPill}>{project.id}</span>
                        </td>
                        <td className={css.nameCell}>
                          <strong>{project.name}</strong>
                          <span>{project.subtitle}</span>
                        </td>
                        <td className={css.dateCell}>{project.startDate}</td>
                        <td className={css.dateCell}>{project.endDate}</td>
                        <td className={`${css.amountCell} ${css.budgetCol}`}>
                          <span className={css.amountVal}>{project.budget}</span>
                          <small>USD</small>
                        </td>
                        <td className={css.teamCol}>
                          <div className={css.teamRow}>
                            {(project.team || []).length === 0 ? (
                              <span className={css.teamEmpty}>No team</span>
                            ) : (
                              <>
                                {(project.team || []).map((initials, i) => (
                                  <span
                                    key={`${initials}-${i}`}
                                    className={css.teamChip}
                                    style={{
                                      background: AVATAR_COLORS[i % AVATAR_COLORS.length],
                                      color:      AVATAR_TEXT[i % AVATAR_TEXT.length],
                                      zIndex:     (project.team || []).length - i
                                    }}
                                  >
                                    {initials}
                                  </span>
                                ))}
                                {project.teamExtra > 0 && (
                                  <span className={css.teamMore}>+{project.teamExtra}</span>
                                )}
                              </>
                            )}
                          </div>
                        </td>
                        <td className={css.colAction}>
                          <span className={css.rowChevron} aria-hidden="true">
                            <svg viewBox="0 0 24 24">
                              <path
                                d="M9 6l6 6-6 6"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                fill="none"
                              />
                            </svg>
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div className={css.cardFoot}>
              <span>
                Showing <strong>{projectsToRender.length}</strong> of{' '}
                <strong>{projectsToRender.length}</strong> projects
              </span>
              <span className={css.pipelineHint}>
                Pipeline value · ${totalBudget.toLocaleString()} USD
              </span>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Dashboard;
