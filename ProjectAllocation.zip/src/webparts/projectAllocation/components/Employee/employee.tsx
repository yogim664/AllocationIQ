import * as React from 'react';
import styles from './employee.module.scss';
import NavBar from '../NavBar/navbar';
import UserBadge from '../UserContext/UserBadge';
import { getSP } from '../../../../service/initservice';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";

export interface IEmployeeItem {
  Id: number;
  Title: string;           // Employee ID
  field_1: string;         // FullName
  field_2: string;         // Department
  field_3: string;         // Designation
  field_4: string;         // Email
  field_5: number | null;  // Phone
  field_6: string;         // Location
  field_7: string;         // JoiningDate
  field_8: string;         // EmploymentType
  field_9: string;         // ManagerID
  field_10: string;        // Status
}

export interface IEmployeeProps {
  onNavigate?: (view: string) => void;
}

const AVATAR_GRADIENTS = [
  'linear-gradient(135deg, #7c3aed, #8b5cf6)',
  'linear-gradient(135deg, #6366f1, #818cf8)',
  'linear-gradient(135deg, #0ea5e9, #38bdf8)',
  'linear-gradient(135deg, #10b981, #34d399)',
  'linear-gradient(135deg, #f59e0b, #fbbf24)',
  'linear-gradient(135deg, #ec4899, #f472b6)',
  'linear-gradient(135deg, #8b5cf6, #a78bfa)',
];

const getInitials = (name: string): string => {
  if (!name) return '??';
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  return name.slice(0, 2).toUpperCase();
};

const formatDate = (dateStr: string): string => {
  if (!dateStr) return '—';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  } catch {
    return dateStr;
  }
};

const getStatusClass = (status: string): string => {
  const s = (status || '').toLowerCase().trim();
  if (s === 'active') return styles.statusActive;
  if (s === 'inactive') return styles.statusInactive;
  if (s === 'on leave' || s === 'onleave') return styles.statusOnLeave;
  return styles.statusActive;
};

const getEmpTypeClass = (type: string): string => {
  const t = (type || '').toLowerCase().trim();
  if (t === 'full-time' || t === 'fulltime' || t === 'full time') return styles.empTypeFull;
  if (t === 'contract' || t === 'contractor') return styles.empTypeContract;
  if (t === 'intern' || t === 'internship') return styles.empTypeIntern;
  return styles.empTypeDefault;
};

const Employee: React.FC<IEmployeeProps> = ({ onNavigate }) => {
  const css = styles as typeof styles & Record<string, string>;

  const [employees, setEmployees] = React.useState<IEmployeeItem[]>([]);
  const [loading, setLoading] = React.useState<boolean>(true);
  const [error, setError] = React.useState<string>('');
  const [searchTerm, setSearchTerm] = React.useState<string>('');

  const fetchEmployees = React.useCallback(async (): Promise<void> => {
    setLoading(true);
    setError('');
    try {
      const sp = getSP();
      const items: IEmployeeItem[] = await sp.web.lists
        .getByTitle("Employees")
        .items
        .select(
          "*"
        )
        .top(5000)();
      setEmployees(items);
    } catch (err) {
      console.error("Error fetching employees:", err);
      setError("Failed to load employee data. Please try again.");
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchEmployees().catch(console.error);
  }, [fetchEmployees]);

  // Filter employees by search
  const filtered = React.useMemo(() => {
    if (!searchTerm.trim()) return employees;
    const q = searchTerm.toLowerCase();
    return employees.filter(
      (emp) =>
        (emp.field_1 || '').toLowerCase().includes(q) ||
        (emp.Title || '').toLowerCase().includes(q) ||
        (emp.field_2 || '').toLowerCase().includes(q) ||
        (emp.field_3 || '').toLowerCase().includes(q) ||
        (emp.field_4 || '').toLowerCase().includes(q) ||
        (emp.field_6 || '').toLowerCase().includes(q) ||
        (emp.field_10 || '').toLowerCase().includes(q)
    );
  }, [employees, searchTerm]);

  // Compute stats
  const stats = React.useMemo(() => {
    const total = employees.length;
    const active = employees.filter((e) => (e.field_10 || '').toLowerCase() === 'active').length;
    const departments = new Set(employees.map((e) => e.field_2).filter(Boolean)).size;
    const locations = new Set(employees.map((e) => e.field_6).filter(Boolean)).size;
    return { total, active, departments, locations };
  }, [employees]);

  return (
    <div className={css.page}>
      <div className={css.pageMesh} aria-hidden="true" />
      <div className={css.pageOrb} aria-hidden="true" />
      <div className={css.pageOrb2} aria-hidden="true" />

      <NavBar activeItem="employee" onNavigate={onNavigate} />

      <main className={css.main}>
        {/* Header */}
        <header className={css.topBar}>
          <div className={css.topBarLeft}>
            <h2 className={css.workspaceTitle}>Employee Directory</h2>
            <span className={css.enterpriseBadge}>HR Module</span>
          </div>
          <UserBadge classNames={{
            userBadge: css.userBadge,
            userText: css.userText,
            userName: css.userName,
            userMail: css.userMail,
            userAvatar: css.userAvatar
          }} />
        </header>

        {/* Stats */}
        <section className={css.statsRow} aria-label="Employee summary">
          <article className={`${css.statCard} ${css.statTotal}`}>
            <div className={css.statCardHead}>
              <p className={css.statLabel}>Total Employees</p>
              <span className={css.statIcon} aria-hidden="true">👥</span>
            </div>
            <p className={css.statValue}>{stats.total}</p>
            <span className={css.statTrend}>All records</span>
          </article>
          <article className={`${css.statCard} ${css.statActive}`}>
            <div className={css.statCardHead}>
              <p className={css.statLabel}>Active</p>
              <span className={css.statIcon} aria-hidden="true">✓</span>
            </div>
            <p className={css.statValue}>{stats.active}</p>
            <span className={css.statTrend}>Currently active</span>
          </article>
          <article className={`${css.statCard} ${css.statDept}`}>
            <div className={css.statCardHead}>
              <p className={css.statLabel}>Departments</p>
              <span className={css.statIcon} aria-hidden="true">◫</span>
            </div>
            <p className={css.statValue}>{stats.departments}</p>
            <span className={css.statTrend}>Across org</span>
          </article>
          <article className={`${css.statCard} ${css.statLocation}`}>
            <div className={css.statCardHead}>
              <p className={css.statLabel}>Locations</p>
              <span className={css.statIcon} aria-hidden="true">⌖</span>
            </div>
            <p className={css.statValue}>{stats.locations}</p>
            <span className={css.statTrend}>Office sites</span>
          </article>
        </section>

        {/* Data Card */}
        <section className={css.card}>
          <div className={css.cardGlow} aria-hidden="true" />
          <div className={css.cardInner}>
            <div className={css.cardHead}>
              <div className={css.cardHeadText}>
                <span className={css.cardKicker}>Directory</span>
                <h3>Employee Records</h3>
                <p>Complete directory of employees sourced from the SharePoint Employee list.</p>
              </div>
              <div className={css.toolbar}>
                <div className={css.searchBox}>
                  <svg className={css.searchIcon} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="11" cy="11" r="8" />
                    <path d="M21 21l-4.35-4.35" />
                  </svg>
                  <input
                    type="text"
                    className={css.searchInput}
                    placeholder="Search employees..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    aria-label="Search employees"
                  />
                </div>
                <button
                  type="button"
                  className={css.refreshBtn}
                  onClick={() => fetchEmployees().catch(console.error)}
                  title="Refresh data"
                  aria-label="Refresh employee data"
                >
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M23 4v6h-6" />
                    <path d="M1 20v-6h6" />
                    <path d="M3.51 9a9 9 0 0114.85-3.36L23 10" />
                    <path d="M20.49 15a9 9 0 01-14.85 3.36L1 14" />
                  </svg>
                </button>
              </div>
            </div>

            {/* Loading state */}
            {loading && (
              <div className={css.loadingWrap}>
                <div className={css.spinner} />
                <span className={css.loadingText}>Loading employee data…</span>
              </div>
            )}

            {/* Error state */}
            {!loading && error && (
              <div className={css.errorText}>{error}</div>
            )}

            {/* Empty state */}
            {!loading && !error && filtered.length === 0 && (
              <div className={css.emptyWrap}>
                <svg className={css.emptyIcon} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="9" cy="8" r="3" />
                  <path d="M3.5 18c0-2.6 2.4-4.5 5.5-4.5s5.5 1.9 5.5 4.5" />
                  <circle cx="17" cy="9" r="2.5" />
                  <path d="M14 17.5c.7-1.6 2.3-2.7 4.5-2.7 1.3 0 2.3.4 3 .9" />
                </svg>
                <span className={css.emptyText}>
                  {searchTerm ? 'No employees match your search' : 'No employee records found'}
                </span>
                <span className={css.emptySub}>
                  {searchTerm ? 'Try a different search term' : 'Employee data will appear here once added'}
                </span>
              </div>
            )}

            {/* Table */}
            {!loading && !error && filtered.length > 0 && (
              <div className={css.tableWrap}>
                <table className={css.table}>
                  <thead>
                    <tr>
                      <th>Employee Name</th>
                      <th>Employee ID</th>
                      <th>Department</th>
                      <th>Designation</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Location</th>
                      <th>Joining Date</th>
                      <th>Type</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((emp, idx) => (
                      <tr key={emp.Id} className={css.empRow} tabIndex={0}>
                        <td className={css.nameCell}>
                          <div className={css.nameRow}>
                            <span
                              className={css.avatar}
                              style={{ background: AVATAR_GRADIENTS[idx % AVATAR_GRADIENTS.length] }}
                            >
                              {getInitials(emp.field_1 || emp.Title)}
                            </span>
                            <div className={css.nameText}>
                              <strong>{emp.field_1 || '—'}</strong>
                              <span>{emp.field_3 || emp.field_2 || ''}</span>
                            </div>
                          </div>
                        </td>
                        <td>
                          <span className={css.idPill}>{emp.Title || '—'}</span>
                        </td>
                        <td>{emp.field_2 || '—'}</td>
                        <td>{emp.field_3 || '—'}</td>
                        <td>
                          {emp.field_4 ? (
                            <a href={`mailto:${emp.field_4}`} className={css.emailLink}>{emp.field_4}</a>
                          ) : '—'}
                        </td>
                        <td>
                          <span className={css.phoneText}>{emp.field_5 ?? '—'}</span>
                        </td>
                        <td>
                          <span className={css.locationCell}>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
                              <circle cx="12" cy="10" r="3" />
                            </svg>
                            {emp.field_6 || '—'}
                          </span>
                        </td>
                        <td>
                          <span className={css.dateText}>{formatDate(emp.field_7)}</span>
                        </td>
                        <td>
                          <span className={`${css.empTypeBadge} ${getEmpTypeClass(emp.field_8)}`}>
                            {emp.field_8 || '—'}
                          </span>
                        </td>
                        <td>
                          <span className={`${css.statusPill} ${getStatusClass(emp.field_10)}`}>
                            <span className={css.statusDot} />
                            {emp.field_10 || '—'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div className={css.cardFoot}>
              <span>
                Showing <strong>{filtered.length}</strong> of <strong>{employees.length}</strong> employees
              </span>
              <span className={css.pipelineHint}>
                Active · {stats.active} employees
              </span>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Employee;
