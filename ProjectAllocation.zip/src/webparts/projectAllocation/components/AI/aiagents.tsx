
export interface AiResponse {
  response: string;
}



 const endpoint =
    "https://agentleagueproject-resource.services.ai.azure.com/api/projects/agentleagueproject";
  const agentName = "ProjectAnalysisAgent";
  const agentVersion = "3";




export const uploadPdfAndAnalyze = async (
  fileOrText: File | string
): Promise<AiResponse> => {
  console.log("Extracting and analyzing file/text:", fileOrText);

  try {


    // Call the agent responses endpoint with the text content
    const response = await fetch(
      `${endpoint}/openai/v1/responses`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer 79v3EwY4YSoZH4oHyFfVD4MRnJbgKfNGKv2xAwWTq1Qnkl0JHDI2JQQJ99CFAC77bzfXJ3w3AAAAACOGaD47`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          input: [
            {
              role: "user",
              content: `${fileOrText}`,
            },
          ],
          agent_reference: {
            name: agentName,
            version: agentVersion,
            type: "agent_reference",
          },
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Agent execution failed: ${response.status} - ${errorText}`);
    }


    const responseData = await response.json();
    const text = responseData.output[0].content[0].text;


    console.log("text",text)
    return {
      response: text
    };
  } catch (error) {
    console.error("AI analysis failed:", error);
    throw error;
  }
};

export const StaffRecommandAgent = async (
  skills: string[],
  ProjectData: any
) => {

const endpoint = "https://agentleagueproject-resource.services.ai.azure.com/api/projects/agentleagueproject";
const agentName = "TeamAllocation";
const agentVersion = "24";


debugger
  // try {


  //   // Call the agent responses endpoint with the text content
  //   const response = await fetch(
  //     `${endpoint}/openai/v1/responses`,
  //     {
  //       method: "POST",
  //       headers: {
  //         Authorization: `Bearer 79v3EwY4YSoZH4oHyFfVD4MRnJbgKfNGKv2xAwWTq1Qnkl0JHDI2JQQJ99CFAC77bzfXJ3w3AAAAACOGaD47`,
  //         "Content-Type": "application/json",
  //       },
  //       body: JSON.stringify({
  //         input: [
  //           {
  //             role: "user",
  //             content: `${ProjectData} and required skills are ${skills}`,
  //           },
  //         ],
  //         agent_reference: {
  //           name: agentName,
  //           version: agentVersion,
  //           type: "agent_reference",
  //         },
  //       }),
  //     }
  //   );

  //   if (!response.ok) {
  //     const errorText = await response.text();
  //     throw new Error(`Agent execution failed: ${response.status} - ${errorText}`);
  //   }


  //   const responseData = await response.json();
  //   const text = responseData.output[0].content[0].text;


  //   console.log("text",text)
  //   return {
  //     response: text
  //   };
  // } catch (error) {
  //   console.error("AI analysis failed:", error);
  //   throw error;
  // }
 
  return [
    {
      EmployeeID:"Emp001",
      initials: 'AR',
      name: 'Arun Raj',
      role: 'PROJECT MANAGER',
      department: 'Program Delivery',
      match: 98,
      availability: 85,
      success: 94
    },
    {
         EmployeeID:"Emp002",
      initials: 'PK',
      name: 'Priya Krishnan',
      role: 'SOLUTION ARCHITECT',
      department: 'Enterprise Architecture',
      match: 95,
      availability: 72,
      success: 91
    },
    {
         EmployeeID:"Emp003",
      initials: 'VK',
      name: 'Vignesh Kumar',
      role: 'AI ENGINEER',
      department: 'AI Innovation Lab',
      match: 99,
      availability: 68,
      success: 97
    },
    {
         EmployeeID:"Emp004",
      initials: 'SK',
      name: 'Shruthi Karthik',
      role: 'FRONTEND DEVELOPER',
      department: 'Digital Experience',
      match: 94,
      availability: 80,
      success: 89
    },
    {
         EmployeeID:"Emp005",
      initials: 'RM',
      name: 'Ramesh Murugan',
      role: 'BACKEND DEVELOPER',
      department: 'Platform Engineering',
      match: 96,
      availability: 75,
      success: 92
    },
    {
         EmployeeID:"Emp006",
      initials: 'NP',
      name: 'Naveen Prakash',
      role: 'QA ENGINEER',
      department: 'Quality Assurance',
      match: 92,
      availability: 88,
      success: 90
    }
  ];
};



export const ProjectPlanAgent = async (
  Staff: string[],
  ProjectData: any
) => {
  const originalPlan = [
    {
      "slNo": 1,
      "feature": "Project Initiation",
      "task": "Requirement Gathering & Bid Process Analysis",
      "startDate": "01-Jun-26",
      "endDate": "05-Jun-26",
      "efforts": 40,
      "lane": "planning",
      "startSlot": 0,
      "durationSlots": 1,
      "assignee": "Arun Raj",
      "availability":80,
    },
    {
      "slNo": 1,
      "feature": "Architecture",
      "task": "Solution Architecture & Technical Design",
      "startDate": "08-Jun-26",
      "endDate": "19-Jun-26",
      "efforts": 80,
      "lane": "planning",
      "startSlot": 1,
      "durationSlots": 2,
      "assignee": "Priya Krishnan",
      "availability":80,
    },
    {
      "slNo": 2,
      "feature": "Infrastructure",
      "task": "SharePoint Environment Setup",
      "startDate": "22-Jun-26",
      "endDate": "26-Jun-26",
      "efforts": 40,
      "lane": "development",
      "startSlot": 3,
      "durationSlots": 1,
      "assignee": "Ramesh Murugan",
      "availability":80,
    },
    {
      "slNo": 2,
      "feature": "Infrastructure",
      "task": "Dataverse & Storage Configuration",
      "startDate": "29-Jun-26",
      "endDate": "03-Jul-26",
      "efforts": 40,
      "lane": "development",
      "startSlot": 4,
      "durationSlots": 1,
      "assignee": "Ramesh Murugan","availability":80,
    },
    {
      "slNo": 3,
      "feature": "Bid Dashboard",
      "task": "Dashboard UI Design",
      "startDate": "06-Jul-26",
      "endDate": "17-Jul-26",
      "efforts": 80,
      "lane": "development",
      "startSlot": 5,
      "durationSlots": 2,
      "assignee": "Shruthi Karthik",
      "availability":80,
    },
    {
      "slNo": 3,
      "feature": "Bid Dashboard",
      "task": "Dashboard Development & Analytics",
      "startDate": "20-Jul-26",
      "endDate": "31-Jul-26",
      "efforts": 80,
      "lane": "development",
      "startSlot": 7,
      "durationSlots": 2,
      "assignee": "Shruthi Karthik",
      "availability":80,
    },
    {
      "slNo": 4,
      "feature": "Bid Management",
      "task": "Bid Creation & Submission Module",
      "startDate": "03-Aug-26",
      "endDate": "21-Aug-26",
      "efforts": 120,
      "lane": "development",
      "startSlot": 9,
      "durationSlots": 3,
      "assignee": "Ramesh Murugan",
      "availability":80
    },
    {
      "slNo": 4,
      "feature": "Bid Management",
      "task": "Approval Workflow Development",
      "startDate": "24-Aug-26",
      "endDate": "04-Sep-26",
      "efforts": 80,
      "lane": "development",
      "startSlot": 12,
      "durationSlots": 2,
      "assignee": "Arun Raj",
      "availability":80
    },
    {
      "slNo": 5,
      "feature": "AI Engine",
      "task": "Historical Bid Data Processing",
      "startDate": "07-Sep-26",
      "endDate": "18-Sep-26",
      "efforts": 80,
      "lane": "development",
      "startSlot": 14,
      "durationSlots": 2,
      "assignee": "Vignesh Kumar",
      "availability":80
    },
    {
      "slNo": 5,
      "feature": "AI Engine",
      "task": "AI Bid Recommendation Model",
      "startDate": "21-Sep-26",
      "endDate": "16-Oct-26",
      "efforts": 160,
      "lane": "development",
      "startSlot": 16,
      "durationSlots": 4,
      "assignee": "Vignesh Kumar",
      "status": "In Progress",
    },
    {
      "slNo": 5,
      "feature": "AI Engine",
      "task": "Win Probability Prediction",
      "startDate": "19-Oct-26",
      "endDate": "30-Oct-26",
      "efforts": 80,
      "lane": "development",
      "startSlot": 20,
      "durationSlots": 2,
      "assignee": "Vignesh Kumar"
    },
    {
      "slNo": 6,
      "feature": "Document Management",
      "task": "Proposal Repository Module",
      "startDate": "02-Nov-26",
      "endDate": "13-Nov-26",
      "efforts": 80,
      "lane": "development",
      "startSlot": 22,
      "durationSlots": 2,
      "assignee": "Ramesh Murugan"
    },
    {
      "slNo": 6,
      "feature": "Document Management",
      "task": "Document Search & Classification",
      "startDate": "16-Nov-26",
      "endDate": "27-Nov-26",
      "efforts": 80,
      "lane": "development",
      "startSlot": 24,
      "durationSlots": 2,
      "assignee": "Vignesh Kumar"
    },
    {
      "slNo": 7,
      "feature": "Notifications",
      "task": "Email & Teams Notifications",
      "startDate": "30-Nov-26",
      "endDate": "11-Dec-26",
      "efforts": 80,
      "lane": "development",
      "startSlot": 26,
      "durationSlots": 2,
      "assignee": "Shruthi Karthik"
    },
    {
      "slNo": 8,
      "feature": "Security",
      "task": "Role-Based Access Control",
      "startDate": "14-Dec-26",
      "endDate": "18-Dec-26",
      "efforts": 40,
      "lane": "development",
      "startSlot": 28,
      "durationSlots": 1,
      "assignee": "Priya Krishnan"
    },
    {
      "slNo": 9,
      "feature": "Testing",
      "task": "System Integration Testing",
      "startDate": "21-Dec-26",
      "endDate": "25-Dec-26",
      "efforts": 40,
      "lane": "testing",
      "startSlot": 29,
      "durationSlots": 1,
      "assignee": "Naveen Prakash"
    },
    {
      "slNo": 9,
      "feature": "Testing",
      "task": "User Acceptance Testing",
      "startDate": "28-Dec-26",
      "endDate": "30-Dec-26",
      "efforts": 24,
      "lane": "testing",
      "startSlot": 30,
      "durationSlots": 1,
      "assignee": "Naveen Prakash"
    },
    {
      "slNo": 10,
      "feature": "Deployment",
      "task": "Production Deployment & Go Live",
      "startDate": "01-Jan-27",
      "endDate": "01-Jan-27",
      "efforts": 8,
      "lane": "demo",
      "startSlot": 31,
      "durationSlots": 1,
      "assignee": "Arun Raj"
    }
  ];

  const parseInputDate = (dateVal: any, defaultDate: Date): Date => {
    if (!dateVal) return defaultDate;
    let d = new Date(dateVal);
    if (isNaN(d.getTime())) {
      const parts = String(dateVal).split('-');
      if (parts.length === 3) {
        if (parts[0].length === 4) {
          d = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
        } else {
          d = new Date(parseInt(parts[2], 10), parseInt(parts[1], 10) - 1, parseInt(parts[0], 10));
        }
      }
    }
    return isNaN(d.getTime()) ? defaultDate : d;
  };

  const parseDateStr = (dateStr: string): Date => {
    const parts = dateStr.split('-');
    const day = parseInt(parts[0], 10);
    const monthStr = parts[1];
    let year = parseInt(parts[2], 10);
    if (year < 100) year += 2000;
    const months: Record<string, number> = {
      jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5,
      jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11
    };
    const month = months[monthStr.toLowerCase()];
    return new Date(year, month, day);
  };

  const formatDateObj = (date: Date): string => {
    const dVal = date.getDate();
    const day = dVal < 10 ? '0' + dVal : String(dVal);
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const month = months[date.getMonth()];
    const year = String(date.getFullYear()).slice(-2);
    return `${day}-${month}-${year}`;
  };

  const origStart = parseDateStr("01-Jun-26");
  const origEnd = parseDateStr("01-Jan-27");
  const origDuration = origEnd.getTime() - origStart.getTime();

  const targetStart = parseInputDate(ProjectData?.startDate, origStart);
  const targetEnd = parseInputDate(ProjectData?.endDate || ProjectData?.dueDate, origEnd);

  const targetDuration = targetEnd.getTime() - targetStart.getTime();
  const scale = targetDuration > 0 ? targetDuration / origDuration : 1;

  return originalPlan.map((item) => {
    const itemOrigStart = parseDateStr(item.startDate);
    const itemOrigEnd = parseDateStr(item.endDate);

    const startOffset = itemOrigStart.getTime() - origStart.getTime();
    const endOffset = itemOrigEnd.getTime() - origStart.getTime();

    const newStart = new Date(targetStart.getTime() + startOffset * scale);
    const newEnd = new Date(targetStart.getTime() + endOffset * scale);

    if (newEnd.getTime() < newStart.getTime()) {
      newEnd.setTime(newStart.getTime());
    }

    return {
      ...item,
      startDate: formatDateObj(newStart),
      endDate: formatDateObj(newEnd),
      status: item.status ?? 'Not Started'
    };
  });
};