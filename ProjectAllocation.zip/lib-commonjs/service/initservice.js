"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getGraph = exports.getSP = exports.initService = void 0;
var graph_1 = require("@pnp/graph");
var sp_1 = require("@pnp/sp");
var _sp;
var _graph;
var initService = function (context) {
    _sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(context));
    _graph = (0, graph_1.graphfi)().using((0, graph_1.SPFx)(context));
};
exports.initService = initService;
var getSP = function () {
    if (!_sp)
        throw new Error("SP not initialized");
    return _sp;
};
exports.getSP = getSP;
var getGraph = function () {
    if (!_graph)
        throw new Error("Graph not initialized");
    return _graph;
};
exports.getGraph = getGraph;
//# sourceMappingURL=initservice.js.map