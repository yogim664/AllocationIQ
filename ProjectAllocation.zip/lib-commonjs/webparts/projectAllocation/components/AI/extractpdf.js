"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.extractPdfText = void 0;
var tslib_1 = require("tslib");
var pdfjsLib = tslib_1.__importStar(require("pdfjs-dist"));
pdfjsLib.GlobalWorkerOptions.workerSrc = new URL("pdfjs-dist/build/pdf.worker.mjs", import.meta.url).toString();
var extractPdfText = function (file) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    var arrayBuffer, pdf, text, pageNum, page, content, pageText;
    return tslib_1.__generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, file.arrayBuffer()];
            case 1:
                arrayBuffer = _a.sent();
                return [4 /*yield*/, pdfjsLib.getDocument({
                        data: arrayBuffer,
                    }).promise];
            case 2:
                pdf = _a.sent();
                text = "";
                pageNum = 1;
                _a.label = 3;
            case 3:
                if (!(pageNum <= pdf.numPages)) return [3 /*break*/, 7];
                return [4 /*yield*/, pdf.getPage(pageNum)];
            case 4:
                page = _a.sent();
                return [4 /*yield*/, page.getTextContent()];
            case 5:
                content = _a.sent();
                pageText = content.items
                    .map(function (item) { return item.str; })
                    .join(" ");
                text += pageText + "\n";
                _a.label = 6;
            case 6:
                pageNum++;
                return [3 /*break*/, 3];
            case 7: return [2 /*return*/, text];
        }
    });
}); };
exports.extractPdfText = extractPdfText;
//# sourceMappingURL=extractpdf.js.map