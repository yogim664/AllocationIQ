"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var employee_module_scss_1 = tslib_1.__importDefault(require("./employee.module.scss"));
var navbar_1 = tslib_1.__importDefault(require("../NavBar/navbar"));
var UserBadge_1 = tslib_1.__importDefault(require("../UserContext/UserBadge"));
var initservice_1 = require("../../../../service/initservice");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/items");
var AVATAR_GRADIENTS = [
    'linear-gradient(135deg, #7c3aed, #8b5cf6)',
    'linear-gradient(135deg, #6366f1, #818cf8)',
    'linear-gradient(135deg, #0ea5e9, #38bdf8)',
    'linear-gradient(135deg, #10b981, #34d399)',
    'linear-gradient(135deg, #f59e0b, #fbbf24)',
    'linear-gradient(135deg, #ec4899, #f472b6)',
    'linear-gradient(135deg, #8b5cf6, #a78bfa)',
];
var getInitials = function (name) {
    if (!name)
        return '??';
    var parts = name.trim().split(/\s+/);
    if (parts.length >= 2)
        return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    return name.slice(0, 2).toUpperCase();
};
var formatDate = function (dateStr) {
    if (!dateStr)
        return '—';
    try {
        var d = new Date(dateStr);
        if (isNaN(d.getTime()))
            return dateStr;
        return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    }
    catch (_a) {
        return dateStr;
    }
};
var getStatusClass = function (status) {
    var s = (status || '').toLowerCase().trim();
    if (s === 'active')
        return employee_module_scss_1.default.statusActive;
    if (s === 'inactive')
        return employee_module_scss_1.default.statusInactive;
    if (s === 'on leave' || s === 'onleave')
        return employee_module_scss_1.default.statusOnLeave;
    return employee_module_scss_1.default.statusActive;
};
var getEmpTypeClass = function (type) {
    var t = (type || '').toLowerCase().trim();
    if (t === 'full-time' || t === 'fulltime' || t === 'full time')
        return employee_module_scss_1.default.empTypeFull;
    if (t === 'contract' || t === 'contractor')
        return employee_module_scss_1.default.empTypeContract;
    if (t === 'intern' || t === 'internship')
        return employee_module_scss_1.default.empTypeIntern;
    return employee_module_scss_1.default.empTypeDefault;
};
var Employee = function (_a) {
    var onNavigate = _a.onNavigate;
    var css = employee_module_scss_1.default;
    var _b = React.useState([]), employees = _b[0], setEmployees = _b[1];
    var _c = React.useState(true), loading = _c[0], setLoading = _c[1];
    var _d = React.useState(''), error = _d[0], setError = _d[1];
    var _e = React.useState(''), searchTerm = _e[0], setSearchTerm = _e[1];
    var fetchEmployees = React.useCallback(function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, items, err_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    setLoading(true);
                    setError('');
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, 4, 5]);
                    sp = (0, initservice_1.getSP)();
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("Employees")
                            .items
                            .select("*")
                            .top(5000)()];
                case 2:
                    items = _a.sent();
                    setEmployees(items);
                    return [3 /*break*/, 5];
                case 3:
                    err_1 = _a.sent();
                    console.error("Error fetching employees:", err_1);
                    setError("Failed to load employee data. Please try again.");
                    return [3 /*break*/, 5];
                case 4:
                    setLoading(false);
                    return [7 /*endfinally*/];
                case 5: return [2 /*return*/];
            }
        });
    }); }, []);
    React.useEffect(function () {
        fetchEmployees().catch(console.error);
    }, [fetchEmployees]);
    // Filter employees by search
    var filtered = React.useMemo(function () {
        if (!searchTerm.trim())
            return employees;
        var q = searchTerm.toLowerCase();
        return employees.filter(function (emp) {
            return (emp.field_1 || '').toLowerCase().includes(q) ||
                (emp.Title || '').toLowerCase().includes(q) ||
                (emp.field_2 || '').toLowerCase().includes(q) ||
                (emp.field_3 || '').toLowerCase().includes(q) ||
                (emp.field_4 || '').toLowerCase().includes(q) ||
                (emp.field_6 || '').toLowerCase().includes(q) ||
                (emp.field_10 || '').toLowerCase().includes(q);
        });
    }, [employees, searchTerm]);
    // Compute stats
    var stats = React.useMemo(function () {
        var total = employees.length;
        var active = employees.filter(function (e) { return (e.field_10 || '').toLowerCase() === 'active'; }).length;
        var departments = new Set(employees.map(function (e) { return e.field_2; }).filter(Boolean)).size;
        var locations = new Set(employees.map(function (e) { return e.field_6; }).filter(Boolean)).size;
        return { total: total, active: active, departments: departments, locations: locations };
    }, [employees]);
    return (React.createElement("div", { className: css.page },
        React.createElement("div", { className: css.pageMesh, "aria-hidden": "true" }),
        React.createElement("div", { className: css.pageOrb, "aria-hidden": "true" }),
        React.createElement("div", { className: css.pageOrb2, "aria-hidden": "true" }),
        React.createElement(navbar_1.default, { activeItem: "employee", onNavigate: onNavigate }),
        React.createElement("main", { className: css.main },
            React.createElement("header", { className: css.topBar },
                React.createElement("div", { className: css.topBarLeft },
                    React.createElement("h2", { className: css.workspaceTitle }, "Employee Directory"),
                    React.createElement("span", { className: css.enterpriseBadge }, "HR Module")),
                React.createElement(UserBadge_1.default, { classNames: {
                        userBadge: css.userBadge,
                        userText: css.userText,
                        userName: css.userName,
                        userMail: css.userMail,
                        userAvatar: css.userAvatar
                    } })),
            React.createElement("section", { className: css.statsRow, "aria-label": "Employee summary" },
                React.createElement("article", { className: "".concat(css.statCard, " ").concat(css.statTotal) },
                    React.createElement("div", { className: css.statCardHead },
                        React.createElement("p", { className: css.statLabel }, "Total Employees"),
                        React.createElement("span", { className: css.statIcon, "aria-hidden": "true" }, "\uD83D\uDC65")),
                    React.createElement("p", { className: css.statValue }, stats.total),
                    React.createElement("span", { className: css.statTrend }, "All records")),
                React.createElement("article", { className: "".concat(css.statCard, " ").concat(css.statActive) },
                    React.createElement("div", { className: css.statCardHead },
                        React.createElement("p", { className: css.statLabel }, "Active"),
                        React.createElement("span", { className: css.statIcon, "aria-hidden": "true" }, "\u2713")),
                    React.createElement("p", { className: css.statValue }, stats.active),
                    React.createElement("span", { className: css.statTrend }, "Currently active")),
                React.createElement("article", { className: "".concat(css.statCard, " ").concat(css.statDept) },
                    React.createElement("div", { className: css.statCardHead },
                        React.createElement("p", { className: css.statLabel }, "Departments"),
                        React.createElement("span", { className: css.statIcon, "aria-hidden": "true" }, "\u25EB")),
                    React.createElement("p", { className: css.statValue }, stats.departments),
                    React.createElement("span", { className: css.statTrend }, "Across org")),
                React.createElement("article", { className: "".concat(css.statCard, " ").concat(css.statLocation) },
                    React.createElement("div", { className: css.statCardHead },
                        React.createElement("p", { className: css.statLabel }, "Locations"),
                        React.createElement("span", { className: css.statIcon, "aria-hidden": "true" }, "\u2316")),
                    React.createElement("p", { className: css.statValue }, stats.locations),
                    React.createElement("span", { className: css.statTrend }, "Office sites"))),
            React.createElement("section", { className: css.card },
                React.createElement("div", { className: css.cardGlow, "aria-hidden": "true" }),
                React.createElement("div", { className: css.cardInner },
                    React.createElement("div", { className: css.cardHead },
                        React.createElement("div", { className: css.cardHeadText },
                            React.createElement("span", { className: css.cardKicker }, "Directory"),
                            React.createElement("h3", null, "Employee Records"),
                            React.createElement("p", null, "Complete directory of employees sourced from the SharePoint Employee list.")),
                        React.createElement("div", { className: css.toolbar },
                            React.createElement("div", { className: css.searchBox },
                                React.createElement("svg", { className: css.searchIcon, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" },
                                    React.createElement("circle", { cx: "11", cy: "11", r: "8" }),
                                    React.createElement("path", { d: "M21 21l-4.35-4.35" })),
                                React.createElement("input", { type: "text", className: css.searchInput, placeholder: "Search employees...", value: searchTerm, onChange: function (e) { return setSearchTerm(e.target.value); }, "aria-label": "Search employees" })),
                            React.createElement("button", { type: "button", className: css.refreshBtn, onClick: function () { return fetchEmployees().catch(console.error); }, title: "Refresh data", "aria-label": "Refresh employee data" },
                                React.createElement("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" },
                                    React.createElement("path", { d: "M23 4v6h-6" }),
                                    React.createElement("path", { d: "M1 20v-6h6" }),
                                    React.createElement("path", { d: "M3.51 9a9 9 0 0114.85-3.36L23 10" }),
                                    React.createElement("path", { d: "M20.49 15a9 9 0 01-14.85 3.36L1 14" }))))),
                    loading && (React.createElement("div", { className: css.loadingWrap },
                        React.createElement("div", { className: css.spinner }),
                        React.createElement("span", { className: css.loadingText }, "Loading employee data\u2026"))),
                    !loading && error && (React.createElement("div", { className: css.errorText }, error)),
                    !loading && !error && filtered.length === 0 && (React.createElement("div", { className: css.emptyWrap },
                        React.createElement("svg", { className: css.emptyIcon, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round" },
                            React.createElement("circle", { cx: "9", cy: "8", r: "3" }),
                            React.createElement("path", { d: "M3.5 18c0-2.6 2.4-4.5 5.5-4.5s5.5 1.9 5.5 4.5" }),
                            React.createElement("circle", { cx: "17", cy: "9", r: "2.5" }),
                            React.createElement("path", { d: "M14 17.5c.7-1.6 2.3-2.7 4.5-2.7 1.3 0 2.3.4 3 .9" })),
                        React.createElement("span", { className: css.emptyText }, searchTerm ? 'No employees match your search' : 'No employee records found'),
                        React.createElement("span", { className: css.emptySub }, searchTerm ? 'Try a different search term' : 'Employee data will appear here once added'))),
                    !loading && !error && filtered.length > 0 && (React.createElement("div", { className: css.tableWrap },
                        React.createElement("table", { className: css.table },
                            React.createElement("thead", null,
                                React.createElement("tr", null,
                                    React.createElement("th", null, "Employee Name"),
                                    React.createElement("th", null, "Employee ID"),
                                    React.createElement("th", null, "Department"),
                                    React.createElement("th", null, "Designation"),
                                    React.createElement("th", null, "Email"),
                                    React.createElement("th", null, "Phone"),
                                    React.createElement("th", null, "Location"),
                                    React.createElement("th", null, "Joining Date"),
                                    React.createElement("th", null, "Type"),
                                    React.createElement("th", null, "Status"))),
                            React.createElement("tbody", null, filtered.map(function (emp, idx) {
                                var _a;
                                return (React.createElement("tr", { key: emp.Id, className: css.empRow, tabIndex: 0 },
                                    React.createElement("td", { className: css.nameCell },
                                        React.createElement("div", { className: css.nameRow },
                                            React.createElement("span", { className: css.avatar, style: { background: AVATAR_GRADIENTS[idx % AVATAR_GRADIENTS.length] } }, getInitials(emp.field_1 || emp.Title)),
                                            React.createElement("div", { className: css.nameText },
                                                React.createElement("strong", null, emp.field_1 || '—'),
                                                React.createElement("span", null, emp.field_3 || emp.field_2 || '')))),
                                    React.createElement("td", null,
                                        React.createElement("span", { className: css.idPill }, emp.Title || '—')),
                                    React.createElement("td", null, emp.field_2 || '—'),
                                    React.createElement("td", null, emp.field_3 || '—'),
                                    React.createElement("td", null, emp.field_4 ? (React.createElement("a", { href: "mailto:".concat(emp.field_4), className: css.emailLink }, emp.field_4)) : '—'),
                                    React.createElement("td", null,
                                        React.createElement("span", { className: css.phoneText }, (_a = emp.field_5) !== null && _a !== void 0 ? _a : '—')),
                                    React.createElement("td", null,
                                        React.createElement("span", { className: css.locationCell },
                                            React.createElement("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" },
                                                React.createElement("path", { d: "M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" }),
                                                React.createElement("circle", { cx: "12", cy: "10", r: "3" })),
                                            emp.field_6 || '—')),
                                    React.createElement("td", null,
                                        React.createElement("span", { className: css.dateText }, formatDate(emp.field_7))),
                                    React.createElement("td", null,
                                        React.createElement("span", { className: "".concat(css.empTypeBadge, " ").concat(getEmpTypeClass(emp.field_8)) }, emp.field_8 || '—')),
                                    React.createElement("td", null,
                                        React.createElement("span", { className: "".concat(css.statusPill, " ").concat(getStatusClass(emp.field_10)) },
                                            React.createElement("span", { className: css.statusDot }),
                                            emp.field_10 || '—'))));
                            }))))),
                    React.createElement("div", { className: css.cardFoot },
                        React.createElement("span", null,
                            "Showing ",
                            React.createElement("strong", null, filtered.length),
                            " of ",
                            React.createElement("strong", null, employees.length),
                            " employees"),
                        React.createElement("span", { className: css.pipelineHint },
                            "Active \u00B7 ",
                            stats.active,
                            " employees")))))));
};
exports.default = Employee;
//# sourceMappingURL=employee.js.map