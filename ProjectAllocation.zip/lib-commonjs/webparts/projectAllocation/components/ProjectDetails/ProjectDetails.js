"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var projectdetails_module_scss_1 = tslib_1.__importDefault(require("./projectdetails.module.scss"));
var initservice_1 = require("../../../../service/initservice");
var UserContext_1 = require("../UserContext/UserContext");
// ─── Helpers ──────────────────────────────────────────────────────────────────
var VALID_STATUSES = ['open', 'in_progress', 'review', 'completed', 'blocked'];
var VALID_PRIORITIES = ['low', 'medium', 'high', 'critical'];
var normaliseStatus = function (raw) {
    var s = (raw || '').toLowerCase().replace(/\s+/g, '_');
    // Map common SP values → our internal values
    if (s === 'not_started' || s === 'not started')
        return 'open';
    if (s === 'in_progress' || s === 'in progress')
        return 'in_progress';
    if (s === 'review' || s === 'in_review')
        return 'review';
    if (s === 'done' || s === 'completed')
        return 'completed';
    if (s === 'blocked' || s === 'on_hold')
        return 'blocked';
    return VALID_STATUSES.indexOf(s) >= 0 ? s : 'open';
};
var normalisePriority = function (raw) {
    var p = (raw || '').toLowerCase();
    return VALID_PRIORITIES.indexOf(p) >= 0 ? p : 'medium';
};
var getInitials = function (name) {
    if (!name)
        return '??';
    var parts = name.trim().split(/\s+/);
    if (parts.length === 1)
        return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
};
var formatDate = function (dateStr) {
    if (!dateStr)
        return '—';
    try {
        var d = new Date(dateStr);
        if (isNaN(d.getTime()))
            return dateStr;
        return d.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    }
    catch (_a) {
        return dateStr;
    }
};
var getFieldValue = function (item, fieldName) {
    if (!item)
        return undefined;
    var lower = fieldName.toLowerCase();
    for (var _i = 0, _a = Object.keys(item); _i < _a.length; _i++) {
        var key = _a[_i];
        if (key.toLowerCase() === lower) {
            var val = item[key];
            if (val && typeof val === 'object') {
                if (val.LookupValue !== undefined)
                    return val.LookupValue;
                if (val.Title !== undefined)
                    return val.Title;
                if (val.Label !== undefined)
                    return val.Label;
            }
            return val;
        }
    }
    return undefined;
};
var normalizeProjectCode = function (code) {
    return (code !== null && code !== void 0 ? code : '').toString().trim().toLowerCase();
};
var escapeODataString = function (value) {
    return value.replace(/'/g, "''");
};
var projectCodesMatch = function (selectedCode, taskCode) {
    var a = normalizeProjectCode(selectedCode);
    var b = normalizeProjectCode(taskCode);
    if (!a || !b)
        return false;
    if (a === b)
        return true;
    // Fallback: PRJ-123 vs 123
    if (a.indexOf('prj-') === 0 && b === a.replace('prj-', ''))
        return true;
    if (b.indexOf('prj-') === 0 && a === b.replace('prj-', ''))
        return true;
    return false;
};
// ─── Static fallback data ─────────────────────────────────────────────────────
var SAMPLE_TASKS = [
    { id: 'T-01', name: 'Groups Cleanup', associated: 'Not Associated', tags: ['Cleanup'], owner: 'Yogesh Mu', ownerInitials: 'YM', priority: 'high', status: 'open', startDate: 'Jun 01, 2026', dueDate: 'Jun 12, 2026', progress: 35, workHours: '00:00', timeLog: '21:00', difference: '- 21:00', billingType: 'None', effort: '4', lane: 'development' },
    { id: 'T-02', name: 'Site Cleanup', associated: 'Not Associated', tags: ['Cleanup'], owner: 'Yogesh Mu', ownerInitials: 'YM', priority: 'medium', status: 'in_progress', startDate: 'Jun 05, 2026', dueDate: 'Jun 18, 2026', progress: 80, workHours: '00:00', timeLog: '07:00', difference: '- 07:00', billingType: 'None', effort: '6', lane: 'development' },
    { id: 'T-03', name: 'Site Access Setup', associated: 'Not Associated', tags: ['Security'], owner: 'Yogesh Mu', ownerInitials: 'YM', priority: 'critical', status: 'review', startDate: 'Jun 10, 2026', dueDate: 'Jun 22, 2026', progress: 65, workHours: '00:00', timeLog: '14:00', difference: '- 14:00', billingType: 'None', effort: '5', lane: 'development' },
    { id: 'T-04', name: 'PowerApps Cleanup', associated: 'Not Associated', tags: ['Cleanup'], owner: 'Yogesh Mu', ownerInitials: 'YM', priority: 'low', status: 'blocked', startDate: 'Jun 15, 2026', dueDate: 'Jul 01, 2026', progress: 10, workHours: '00:00', timeLog: '00:00', difference: '00:00', billingType: 'None', effort: '3', lane: 'development' },
    { id: 'T-05', name: 'Task Pipeline Review', associated: 'Not Associated', tags: ['Infrastructure'], owner: 'Yogesh Mu', ownerInitials: 'YM', priority: 'medium', status: 'completed', startDate: 'May 20, 2026', dueDate: 'May 28, 2026', progress: 100, workHours: '00:00', timeLog: '00:00', difference: '00:00', billingType: 'None', effort: '8', lane: 'testing' }
];
var ORION_TASKS = [
    { id: 'T-01', name: 'Cloud Architecture Design', associated: 'Lane: Development', tags: ['Architecture'], owner: 'Sarah Jenkins', ownerInitials: 'SJ', priority: 'high', status: 'completed', startDate: 'Jan 15, 2026', dueDate: 'Feb 10, 2026', progress: 100, workHours: '40:00', timeLog: '40:00', difference: '00:00', billingType: 'Fixed', effort: '40', lane: 'development' },
    { id: 'T-02', name: 'Database Nexus Clustering', associated: 'Lane: Development', tags: ['Database'], owner: 'Michael Chen', ownerInitials: 'MC', priority: 'critical', status: 'in_progress', startDate: 'Feb 12, 2026', dueDate: 'Apr 30, 2026', progress: 50, workHours: '80:00', timeLog: '35:00', difference: '- 45:00', billingType: 'Hourly', effort: '80', lane: 'development' },
    { id: 'T-03', name: 'Data Migration Pipeline', associated: 'Lane: Development', tags: ['Pipeline'], owner: 'Elena Rostova', ownerInitials: 'ER', priority: 'medium', status: 'open', startDate: 'May 01, 2026', dueDate: 'Jun 15, 2026', progress: 0, workHours: '60:00', timeLog: '00:00', difference: '00:00', billingType: 'Hourly', effort: '60', lane: 'development' },
    { id: 'T-04', name: 'Load Balancer Config', associated: 'Lane: Testing', tags: ['Infrastructure'], owner: 'Siddharth Rao', ownerInitials: 'SR', priority: 'medium', status: 'open', startDate: 'Jun 18, 2026', dueDate: 'Jul 10, 2026', progress: 0, workHours: '20:00', timeLog: '00:00', difference: '00:00', billingType: 'Hourly', effort: '20', lane: 'testing' },
    { id: 'T-05', name: 'Security Audit & Hardening', associated: 'Lane: Demo', tags: ['Security'], owner: 'Sarah Jenkins', ownerInitials: 'SJ', priority: 'high', status: 'blocked', startDate: 'Jul 15, 2026', dueDate: 'Aug 20, 2026', progress: 10, workHours: '30:00', timeLog: '05:00', difference: '- 25:00', billingType: 'Fixed', effort: '30', lane: 'demo' }
];
var HELIOS_TASKS = [
    { id: 'T-01', name: 'Telemetry Agent Setup', associated: 'Lane: Development', tags: ['Telemetry'], owner: 'Sarah Jenkins', ownerInitials: 'SJ', priority: 'high', status: 'completed', startDate: 'Feb 05, 2026', dueDate: 'Mar 01, 2026', progress: 100, workHours: '30:00', timeLog: '30:00', difference: '00:00', billingType: 'Fixed', effort: '30', lane: 'development' },
    { id: 'T-02', name: 'Core Ingestion Engine', associated: 'Lane: Development', tags: ['Backend'], owner: 'Elena Rostova', ownerInitials: 'ER', priority: 'critical', status: 'in_progress', startDate: 'Mar 05, 2026', dueDate: 'May 30, 2026', progress: 75, workHours: '120:00', timeLog: '90:00', difference: '- 30:00', billingType: 'Hourly', effort: '120', lane: 'development' },
    { id: 'T-03', name: 'Workflow Analytics UI', associated: 'Lane: Development', tags: ['Frontend'], owner: 'Clara Oswald', ownerInitials: 'CO', priority: 'medium', status: 'in_progress', startDate: 'May 10, 2026', dueDate: 'Jul 15, 2026', progress: 40, workHours: '70:00', timeLog: '25:00', difference: '- 45:00', billingType: 'Hourly', effort: '70', lane: 'development' },
    { id: 'T-04', name: 'Anomaly Detection Tuning', associated: 'Lane: Testing', tags: ['AI/ML'], owner: 'Michael Chen', ownerInitials: 'MC', priority: 'high', status: 'open', startDate: 'Jul 20, 2026', dueDate: 'Sep 10, 2026', progress: 0, workHours: '90:00', timeLog: '00:00', difference: '00:00', billingType: 'Hourly', effort: '90', lane: 'testing' },
    { id: 'T-05', name: 'System Integration Test', associated: 'Lane: Demo', tags: ['QA'], owner: 'Siddharth Rao', ownerInitials: 'SR', priority: 'medium', status: 'open', startDate: 'Sep 15, 2026', dueDate: 'Oct 30, 2026', progress: 0, workHours: '40:00', timeLog: '00:00', difference: '00:00', billingType: 'Fixed', effort: '40', lane: 'demo' }
];
var AURORA_TASKS = [
    { id: 'T-01', name: 'LLM API Integration', associated: 'Lane: Development', tags: ['AI/ML'], owner: 'Michael Chen', ownerInitials: 'MC', priority: 'critical', status: 'completed', startDate: 'Mar 15, 2026', dueDate: 'Apr 20, 2026', progress: 100, workHours: '60:00', timeLog: '60:00', difference: '00:00', billingType: 'Hourly', effort: '60', lane: 'development' },
    { id: 'T-02', name: 'Prompt Engineering & Tuning', associated: 'Lane: Development', tags: ['AI/PM'], owner: 'Sarah Jenkins', ownerInitials: 'SJ', priority: 'high', status: 'in_progress', startDate: 'Apr 25, 2026', dueDate: 'Jun 30, 2026', progress: 80, workHours: '50:00', timeLog: '42:00', difference: '- 08:00', billingType: 'Fixed', effort: '50', lane: 'development' },
    { id: 'T-03', name: 'Chat Interface Components', associated: 'Lane: Development', tags: ['Frontend'], owner: 'Clara Oswald', ownerInitials: 'CO', priority: 'medium', status: 'in_progress', startDate: 'May 01, 2026', dueDate: 'Jul 10, 2026', progress: 60, workHours: '80:00', timeLog: '48:00', difference: '- 32:00', billingType: 'Hourly', effort: '80', lane: 'development' },
    { id: 'T-04', name: 'Context Window Mgmt', associated: 'Lane: Testing', tags: ['Backend'], owner: 'Elena Rostova', ownerInitials: 'ER', priority: 'high', status: 'open', startDate: 'Jul 15, 2026', dueDate: 'Sep 05, 2026', progress: 0, workHours: '40:00', timeLog: '00:00', difference: '00:00', billingType: 'Hourly', effort: '40', lane: 'testing' },
    { id: 'T-05', name: 'UAT Feedback Loop', associated: 'Lane: Demo', tags: ['UAT'], owner: 'Siddharth Rao', ownerInitials: 'SR', priority: 'medium', status: 'open', startDate: 'Sep 10, 2026', dueDate: 'Oct 15, 2026', progress: 0, workHours: '30:00', timeLog: '00:00', difference: '00:00', billingType: 'Fixed', effort: '30', lane: 'demo' }
];
// ─── Constants ────────────────────────────────────────────────────────────────
var TABS = [
    { id: 'tasks', label: 'Tasks', icon: 'tasks' },
    { id: 'logs', label: 'Log Hours', icon: 'clock' }
];
var STATUS_LABEL = {
    open: 'Open',
    in_progress: 'In Progress',
    review: 'Review',
    completed: 'Completed',
    blocked: 'Blocked'
};
var GROUP_OPTIONS = ['Task List (General)', 'By Status', 'By Owner', 'By Priority'];
// ─── Small SVG icons ──────────────────────────────────────────────────────────
var TabIcon = function (_a) {
    var type = _a.type, className = _a.className;
    if (type === 'clock') {
        return (React.createElement("svg", { viewBox: "0 0 24 24", className: className, "aria-hidden": "true" },
            React.createElement("circle", { cx: "12", cy: "12", r: "9", stroke: "currentColor", strokeWidth: "2", fill: "none" }),
            React.createElement("path", { d: "M12 7v5l3 2", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", fill: "none" })));
    }
    return (React.createElement("svg", { viewBox: "0 0 24 24", className: className, "aria-hidden": "true" },
        React.createElement("rect", { x: "4", y: "4", width: "16", height: "16", rx: "3", stroke: "currentColor", strokeWidth: "2", fill: "none" }),
        React.createElement("path", { d: "M8 10h8M8 14h5", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round" })));
};
// ─── Main Component ───────────────────────────────────────────────────────────
var ProjectDetails = function (_a) {
    var project = _a.project, onBack = _a.onBack;
    var css = projectdetails_module_scss_1.default;
    var _b = (0, UserContext_1.useUser)(), displayName = _b.displayName, email = _b.email, initials = _b.initials, greeting = _b.greeting;
    // ── UI state ──────────────────────────────────────────────────────────────
    var _c = React.useState('tasks'), tab = _c[0], setTab = _c[1];
    var _d = React.useState(GROUP_OPTIONS[0]), groupBy = _d[0], setGroupBy = _d[1];
    var _e = React.useState(new Set()), selectedIds = _e[0], setSelectedIds = _e[1];
    // ── Data state ────────────────────────────────────────────────────────────
    var _f = React.useState([]), tasks = _f[0], setTasks = _f[1];
    var _g = React.useState(true), loading = _g[0], setLoading = _g[1];
    // ── Fetch tasks from SharePoint TaskDetails list, filtered by ProjectCode ─
    var fetchTasks = React.useCallback(function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, projectCode_1, taskFields, spItems, filterErr_1, allItems, matchedItems, isDemoProject, template, mapped, error_1;
        var _a, _b;
        return tslib_1.__generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    _c.trys.push([0, 7, 8, 9]);
                    setLoading(true);
                    setTasks([]);
                    sp = (0, initservice_1.getSP)();
                    projectCode_1 = (project.id || '').trim();
                    taskFields = [
                        'Id', 'Task', 'Sno', 'ProjectCode', 'Assignee', 'lane',
                        'Effort', 'Status', 'StartDate', 'EndDate'
                    ];
                    spItems = [];
                    if (!projectCode_1) return [3 /*break*/, 4];
                    _c.label = 1;
                case 1:
                    _c.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, (_a = sp.web.lists
                            .getByTitle('TaskDetails')
                            .items)
                            .select.apply(_a, taskFields).filter("ProjectCode eq '".concat(escapeODataString(projectCode_1), "'"))
                            .top(5000)()];
                case 2:
                    spItems = _c.sent();
                    return [3 /*break*/, 4];
                case 3:
                    filterErr_1 = _c.sent();
                    console.warn('[ProjectDetails] OData filter failed, falling back to client filter:', filterErr_1);
                    return [3 /*break*/, 4];
                case 4:
                    if (!(spItems.length === 0 && projectCode_1)) return [3 /*break*/, 6];
                    return [4 /*yield*/, (_b = sp.web.lists
                            .getByTitle('TaskDetails')
                            .items)
                            .select.apply(_b, taskFields).top(5000)()];
                case 5:
                    allItems = _c.sent();
                    spItems = allItems.filter(function (item) {
                        return projectCodesMatch(projectCode_1, getFieldValue(item, 'ProjectCode'));
                    });
                    _c.label = 6;
                case 6:
                    matchedItems = spItems;
                    // Sort items client-side by Sno (numeric sorting)
                    matchedItems.sort(function (a, b) {
                        var snoA = parseInt(getFieldValue(a, 'Sno') || '0', 10);
                        var snoB = parseInt(getFieldValue(b, 'Sno') || '0', 10);
                        return snoA - snoB;
                    });
                    if (matchedItems.length === 0) {
                        isDemoProject = projectCode_1 === 'PRJ-2026-01' || (project.name && project.name.indexOf('Orion') >= 0) ||
                            projectCode_1 === 'PRJ-2026-02' || (project.name && project.name.indexOf('Helios') >= 0) ||
                            projectCode_1 === 'PRJ-2026-03' || (project.name && project.name.indexOf('Aurora') >= 0);
                        if (isDemoProject) {
                            template = SAMPLE_TASKS;
                            if (projectCode_1 === 'PRJ-2026-01' || (project.name && project.name.indexOf('Orion') >= 0)) {
                                template = ORION_TASKS;
                            }
                            else if (projectCode_1 === 'PRJ-2026-02' || (project.name && project.name.indexOf('Helios') >= 0)) {
                                template = HELIOS_TASKS;
                            }
                            else if (projectCode_1 === 'PRJ-2026-03' || (project.name && project.name.indexOf('Aurora') >= 0)) {
                                template = AURORA_TASKS;
                            }
                            setTasks(template.map(function (t) { return (tslib_1.__assign(tslib_1.__assign({}, t), { id: "".concat(projectCode_1, "-").concat(t.id) })); }));
                            return [2 /*return*/];
                        }
                        setTasks([]);
                        return [2 /*return*/];
                    }
                    mapped = matchedItems.map(function (item, idx) {
                        var owner = getFieldValue(item, 'Assignee') || 'Unassigned';
                        var taskName = getFieldValue(item, 'Task') || "Task ".concat(idx + 1);
                        var sno = getFieldValue(item, 'Sno') || String(idx + 1);
                        var status = normaliseStatus(getFieldValue(item, 'Status') || '');
                        var lane = getFieldValue(item, 'lane') || '';
                        var effort = getFieldValue(item, 'Effort') || '';
                        var startD = getFieldValue(item, 'StartDate') || '';
                        var endD = getFieldValue(item, 'EndDate') || '';
                        return {
                            id: "".concat(projectCode_1, "-T").concat(sno.toString().padStart(2, '0')),
                            name: taskName,
                            associated: lane ? "Lane: ".concat(lane) : 'Not Associated',
                            tags: lane ? [lane] : [],
                            owner: owner,
                            ownerInitials: getInitials(owner),
                            priority: 'medium',
                            status: status,
                            startDate: formatDate(startD),
                            dueDate: formatDate(endD),
                            progress: status === 'completed' ? 100
                                : status === 'review' ? 75
                                    : status === 'in_progress' ? 50
                                        : status === 'blocked' ? 10
                                            : 0,
                            workHours: effort ? "".concat(effort, "h") : '0h',
                            timeLog: '00:00',
                            difference: effort ? "- ".concat(effort, "h") : '00:00',
                            billingType: 'None',
                            effort: effort ? String(effort) : '0',
                            lane: lane || 'development'
                        };
                    });
                    setTasks(mapped);
                    return [3 /*break*/, 9];
                case 7:
                    error_1 = _c.sent();
                    console.error('[ProjectDetails] Error fetching tasks from SharePoint:', error_1);
                    setTasks(SAMPLE_TASKS);
                    return [3 /*break*/, 9];
                case 8:
                    setLoading(false);
                    return [7 /*endfinally*/];
                case 9: return [2 /*return*/];
            }
        });
    }); }, [project.id, project.name]);
    React.useEffect(function () {
        fetchTasks().catch(console.error);
    }, [fetchTasks]);
    // ── Selection helpers ─────────────────────────────────────────────────────
    var toggleRow = function (id) {
        setSelectedIds(function (prev) {
            var next = new Set(prev);
            if (next.has(id)) {
                next.delete(id);
            }
            else {
                next.add(id);
            }
            return next;
        });
    };
    var toggleAll = function () {
        if (selectedIds.size === tasks.length) {
            setSelectedIds(new Set());
        }
        else {
            setSelectedIds(new Set(tasks.map(function (t) { return t.id; })));
        }
    };
    // ── Grouped task logic ────────────────────────────────────────────────────
    var displayedTasks = React.useMemo(function () {
        if (groupBy === 'By Status') {
            var order_1 = ['in_progress', 'review', 'open', 'blocked', 'completed'];
            return tslib_1.__spreadArray([], tasks, true).sort(function (a, b) { return order_1.indexOf(a.status) - order_1.indexOf(b.status); });
        }
        if (groupBy === 'By Owner') {
            return tslib_1.__spreadArray([], tasks, true).sort(function (a, b) { return a.owner.localeCompare(b.owner); });
        }
        if (groupBy === 'By Priority') {
            var order_2 = ['critical', 'high', 'medium', 'low'];
            return tslib_1.__spreadArray([], tasks, true).sort(function (a, b) { return order_2.indexOf(a.priority) - order_2.indexOf(b.priority); });
        }
        return tasks;
    }, [tasks, groupBy]);
    // ── Render: Tasks table ───────────────────────────────────────────────────
    var renderTasksTable = function () {
        if (loading) {
            return (React.createElement("div", { className: css.loadingWrap, "aria-live": "polite" },
                React.createElement("div", { className: css.spinnerRing }),
                React.createElement("span", null,
                    "Loading tasks for project ",
                    React.createElement("strong", null, project.id),
                    "\u2026")));
        }
        if (displayedTasks.length === 0) {
            return (React.createElement("div", { className: css.emptyState },
                React.createElement("svg", { viewBox: "0 0 24 24", className: css.emptyIcon, fill: "none", "aria-hidden": "true" },
                    React.createElement("rect", { x: "4", y: "4", width: "16", height: "16", rx: "3", stroke: "currentColor", strokeWidth: "1.8" }),
                    React.createElement("path", { d: "M8 10h8M8 14h5", stroke: "currentColor", strokeWidth: "1.8", strokeLinecap: "round" })),
                React.createElement("p", { className: css.emptyTitle }, "No tasks found"),
                React.createElement("p", { className: css.emptyDesc },
                    "No tasks in ",
                    React.createElement("strong", null, "TaskDetails"),
                    " match project code ",
                    React.createElement("code", { className: css.codeTag }, project.id))));
        }
        return (React.createElement("div", { className: css.tableCard },
            React.createElement("div", { className: css.tableCardGlow, "aria-hidden": "true" }),
            React.createElement("div", { className: css.gridWrap },
                React.createElement("table", { className: css.dataGrid },
                    React.createElement("thead", null,
                        React.createElement("tr", null,
                            React.createElement("th", { className: css.colCheck },
                                React.createElement("label", { className: css.checkLabel },
                                    React.createElement("input", { type: "checkbox", checked: selectedIds.size === displayedTasks.length && displayedTasks.length > 0, onChange: toggleAll, "aria-label": "Select all tasks" }),
                                    React.createElement("span", { className: css.checkBox }))),
                            React.createElement("th", { className: css.colTaskName }, "Task"),
                            React.createElement("th", { className: css.colEffort }, "Effort (h)"),
                            React.createElement("th", { className: css.colOwner }, "Assignee"),
                            React.createElement("th", { className: css.colDate }, "Start Date"),
                            React.createElement("th", { className: css.colDate }, "End Date"),
                            React.createElement("th", { className: css.colStatus }, "Status"))),
                    React.createElement("tbody", null, displayedTasks.map(function (task) {
                        var selected = selectedIds.has(task.id);
                        return (React.createElement("tr", { key: task.id, className: selected ? css.rowSelected : undefined },
                            React.createElement("td", { className: css.colCheck },
                                React.createElement("label", { className: css.checkLabel },
                                    React.createElement("input", { type: "checkbox", checked: selected, onChange: function () { return toggleRow(task.id); }, "aria-label": "Select ".concat(task.name) }),
                                    React.createElement("span", { className: css.checkBox }))),
                            React.createElement("td", { className: css.colTaskName },
                                React.createElement("div", { className: css.taskNameCell },
                                    React.createElement("span", { className: "".concat(css.statusIndicator, " ").concat(css["status_".concat(task.status)]), title: STATUS_LABEL[task.status] }),
                                    React.createElement("div", null,
                                        React.createElement("span", { className: css.taskTitle }, task.name),
                                        task.lane && (React.createElement("span", { className: css.laneTag }, task.lane))))),
                            React.createElement("td", { className: css.colEffort },
                                React.createElement("span", { className: css.effortBadge },
                                    task.effort,
                                    "h")),
                            React.createElement("td", { className: css.colOwner },
                                React.createElement("div", { className: css.assigneeCell },
                                    React.createElement("span", { className: css.ownerAvatar }, task.ownerInitials),
                                    React.createElement("span", { className: css.ownerName }, task.owner))),
                            React.createElement("td", { className: css.colDate },
                                React.createElement("span", { className: css.dateVal }, task.startDate || '—')),
                            React.createElement("td", { className: css.colDate },
                                React.createElement("span", { className: css.dateVal }, task.dueDate)),
                            React.createElement("td", { className: css.colStatus },
                                React.createElement("span", { className: "".concat(css.statusChip, " ").concat(css["status_".concat(task.status)]) },
                                    React.createElement("span", { className: css.statusDot }),
                                    STATUS_LABEL[task.status]))));
                    }))))));
    };
    // ── Render: Log Hours table ───────────────────────────────────────────────
    var totalEffortHrs = displayedTasks.reduce(function (s, t) { return s + (parseInt(t.effort, 10) || 0); }, 0);
    var renderLogHours = function () {
        if (loading) {
            return (React.createElement("div", { className: css.loadingWrap, "aria-live": "polite" },
                React.createElement("div", { className: css.spinnerRing }),
                React.createElement("span", null, "Loading work logs\u2026")));
        }
        return (React.createElement("div", { className: css.tableCard },
            React.createElement("div", { className: css.tableCardGlow, "aria-hidden": "true" }),
            React.createElement("div", { className: css.logsBanner },
                React.createElement("span", null, "Project Work Logs & Effort"),
                React.createElement("span", { className: css.totalWarn },
                    "Total Effort: ",
                    totalEffortHrs,
                    "h")),
            React.createElement("div", { className: css.gridWrap },
                React.createElement("table", { className: css.dataGrid },
                    React.createElement("thead", null,
                        React.createElement("tr", null,
                            React.createElement("th", { className: css.colName }, "Task"),
                            React.createElement("th", { className: css.colHours }, "Effort (h)"),
                            React.createElement("th", { className: css.colHours }, "Timelog Total"),
                            React.createElement("th", { className: css.colDiff }, "Difference"),
                            React.createElement("th", { className: css.colBilling }, "Billing Type"))),
                    React.createElement("tbody", null, displayedTasks.map(function (task) { return (React.createElement("tr", { key: task.id },
                        React.createElement("td", { className: css.colName },
                            React.createElement("div", { className: css.taskCellCompact },
                                React.createElement("span", { className: css.taskTitle }, task.name),
                                React.createElement("span", { className: css.taskIdMeta }, task.id))),
                        React.createElement("td", { className: css.colHours },
                            React.createElement("span", { className: css.cellMuted }, task.workHours)),
                        React.createElement("td", { className: css.colHours },
                            React.createElement("span", { className: css.boldVal }, task.timeLog)),
                        React.createElement("td", { className: css.colDiff },
                            React.createElement("span", { className: task.difference.startsWith('-') ? css.diffBad : css.diffNeutral }, task.difference)),
                        React.createElement("td", { className: css.colBilling },
                            React.createElement("span", { className: css.billingText }, task.billingType)))); }))))));
    };
    // ── JSX ───────────────────────────────────────────────────────────────────
    return (React.createElement("div", { className: css.page },
        React.createElement("div", { className: css.pageMesh, "aria-hidden": "true" }),
        React.createElement("div", { className: css.pageOrb1, "aria-hidden": "true" }),
        React.createElement("div", { className: css.pageOrb2, "aria-hidden": "true" }),
        React.createElement("header", { className: css.stickyHeader },
            React.createElement("div", { className: css.headerLeft },
                React.createElement("button", { type: "button", className: css.backBtn, onClick: onBack, "aria-label": "Back to projects" },
                    React.createElement("svg", { viewBox: "0 0 24 24", className: css.backIcon, "aria-hidden": "true" },
                        React.createElement("path", { d: "M15 19l-7-7 7-7", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round", fill: "none" }))),
                React.createElement("div", { className: css.headerTitles },
                    React.createElement("h1", { className: css.appTitle }, "Project Task Manager"),
                    React.createElement("p", { className: css.projectMeta },
                        React.createElement("span", { className: css.projectIdPill }, project.id),
                        React.createElement("span", { className: css.metaSep }, "\u00B7"),
                        project.name,
                        loading && React.createElement("span", { className: css.loadingBadge }, "\u27F3 Loading tasks\u2026")))),
            React.createElement("div", { className: css.headerRight },
                React.createElement("span", { className: css.systemBadge },
                    React.createElement("span", { className: css.pulseDot, "aria-hidden": "true" }),
                    "AI SYSTEM ONLINE"),
                React.createElement("div", { className: css.searchWrap },
                    React.createElement("svg", { viewBox: "0 0 24 24", className: css.searchSvg, "aria-hidden": "true" },
                        React.createElement("circle", { cx: "11", cy: "11", r: "7", stroke: "currentColor", strokeWidth: "2.2", fill: "none" }),
                        React.createElement("path", { d: "M20 20l-4.3-4.3", stroke: "currentColor", strokeWidth: "2.2", strokeLinecap: "round", fill: "none" })),
                    React.createElement("input", { placeholder: "Search core intelligence...", "aria-label": "Search" })),
                React.createElement("button", { type: "button", className: css.userMenu, "aria-label": "User menu" },
                    React.createElement("div", { className: css.userMenuText },
                        React.createElement("strong", null,
                            greeting,
                            ", ",
                            displayName),
                        email ? React.createElement("small", null, email) : null),
                    React.createElement("span", { className: css.avatar }, initials)))),
        React.createElement("div", { className: css.bodyLayout },
            React.createElement("main", { className: css.mainColumn },
                React.createElement("nav", { className: css.viewTabs, "aria-label": "Project views" }, TABS.map(function (t) { return (React.createElement("button", { key: t.id, type: "button", className: tab === t.id ? css.tabActive : css.tabBtn, onClick: function () { return setTab(t.id); } },
                    React.createElement(TabIcon, { type: t.icon, className: css.tabIcon }),
                    t.label)); })),
                React.createElement("div", { className: css.contentToolbar },
                    React.createElement("label", { className: css.groupByWrap },
                        React.createElement("span", { className: css.groupByLabel }, "Group By:"),
                        React.createElement("select", { value: groupBy, onChange: function (e) { return setGroupBy(e.target.value); }, "aria-label": "Group by" }, GROUP_OPTIONS.map(function (opt) { return (React.createElement("option", { key: opt, value: opt }, opt)); }))),
                    React.createElement("div", { className: css.toolbarRight },
                        React.createElement("span", { className: css.taskCount },
                            "Showing ",
                            React.createElement("strong", null, displayedTasks.length),
                            " task",
                            displayedTasks.length !== 1 ? 's' : ''),
                        tab === 'tasks' && (React.createElement("button", { type: "button", className: css.newTaskBtn }, "+ New Task")))),
                tab === 'tasks' && renderTasksTable(),
                tab === 'logs' && renderLogHours()))));
};
exports.default = ProjectDetails;
//# sourceMappingURL=ProjectDetails.js.map