"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var navbar_module_scss_1 = tslib_1.__importDefault(require("./navbar.module.scss"));
var approvalData_1 = require("../Approvals/approvalData");
var DashboardIcon = function () { return (React.createElement("svg", { viewBox: "0 0 24 24", "aria-hidden": "true" },
    React.createElement("rect", { x: "4", y: "4", width: "7", height: "7", rx: "1.5" }),
    React.createElement("rect", { x: "13", y: "4", width: "7", height: "7", rx: "1.5" }),
    React.createElement("rect", { x: "4", y: "13", width: "7", height: "7", rx: "1.5" }),
    React.createElement("rect", { x: "13", y: "13", width: "7", height: "7", rx: "1.5" }))); };
var PeopleIcon = function () { return (React.createElement("svg", { viewBox: "0 0 24 24", "aria-hidden": "true" },
    React.createElement("circle", { cx: "9", cy: "8", r: "3" }),
    React.createElement("path", { d: "M3.5 18c0-2.6 2.4-4.5 5.5-4.5s5.5 1.9 5.5 4.5" }),
    React.createElement("circle", { cx: "17", cy: "9", r: "2.5" }),
    React.createElement("path", { d: "M14 17.5c.7-1.6 2.3-2.7 4.5-2.7 1.3 0 2.3.4 3 .9" }))); };
var ApprovalIcon = function () { return (React.createElement("svg", { viewBox: "0 0 24 24", "aria-hidden": "true" },
    React.createElement("path", { d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2" }),
    React.createElement("rect", { x: "9", y: "3", width: "6", height: "4", rx: "1" }),
    React.createElement("path", { d: "M9 12l2 2 4-4" }))); };
var navItems = [
    { key: 'dashboard', label: 'Dashboard', icon: React.createElement(DashboardIcon, null) },
    { key: 'employee', label: 'Employee', icon: React.createElement(PeopleIcon, null) },
    { key: 'approvals', label: 'Approvals', icon: React.createElement(ApprovalIcon, null) }
];
var NavBar = function (_a) {
    var _b = _a.activeItem, activeItem = _b === void 0 ? 'dashboard' : _b, onNavigate = _a.onNavigate, pendingApprovalsCount = _a.pendingApprovalsCount;
    var _c = React.useState(0), pendingCount = _c[0], setPendingCount = _c[1];
    React.useEffect(function () {
        if (pendingApprovalsCount !== undefined) {
            setPendingCount(pendingApprovalsCount);
            return;
        }
        var cancelled = false;
        (0, approvalData_1.fetchPendingApprovalsCount)()
            .then(function (count) {
            if (!cancelled)
                setPendingCount(count);
        })
            .catch(function () {
            if (!cancelled)
                setPendingCount(0);
        });
        return function () { cancelled = true; };
    }, [pendingApprovalsCount, activeItem]);
    return (React.createElement("aside", { className: navbar_module_scss_1.default.sidebar },
        React.createElement("div", { className: navbar_module_scss_1.default.brand },
            React.createElement("div", { className: navbar_module_scss_1.default.logoWrap },
                React.createElement("svg", { viewBox: "0 0 24 24", "aria-hidden": "true" },
                    React.createElement("path", { d: "M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3z" }),
                    React.createElement("path", { d: "M8.5 9.5h7M8.5 12h7M8.5 14.5h4.5" }))),
            React.createElement("div", null,
                React.createElement("h1", { className: navbar_module_scss_1.default.brandTitle }, "AEGIS OS"),
                React.createElement("p", { className: navbar_module_scss_1.default.brandSub }, "WORKSPACE AI"))),
        React.createElement("nav", { className: navbar_module_scss_1.default.menu }, navItems.map(function (item) {
            var active = item.key === activeItem;
            return (React.createElement("button", { key: item.key, type: "button", className: "".concat(navbar_module_scss_1.default.menuItem, " ").concat(active ? navbar_module_scss_1.default.active : '', " ").concat(item.key === 'approvals' ? navbar_module_scss_1.default.approvalsItem : ''), onClick: function () { return onNavigate && onNavigate(item.key); } },
                React.createElement("span", { className: navbar_module_scss_1.default.menuIcon }, item.icon),
                React.createElement("span", null, item.label),
                item.key === 'approvals' && pendingCount > 0 && (React.createElement("span", { className: navbar_module_scss_1.default.approvalsBadge }, pendingCount))));
        })),
        React.createElement("div", { className: navbar_module_scss_1.default.footerVersion }, "v4.1.2 - SECURE MODE")));
};
exports.default = NavBar;
//# sourceMappingURL=navbar.js.map