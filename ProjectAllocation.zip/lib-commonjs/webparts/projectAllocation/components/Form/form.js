"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var form_module_scss_1 = tslib_1.__importDefault(require("./form.module.scss"));
var XLSX = tslib_1.__importStar(require("xlsx"));
var aiagents_1 = require("../AI/aiagents");
var extractpdf_1 = require("../AI/extractpdf");
var initservice_1 = require("../../../../service/initservice");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/items");
var STEPS = [
    'SOURCE',
    'INTAKE SPEC',
    'STAFF RECOMMENDATION',
    'PROJECT PLAN',
    'APPROVALS',
    'SUCCESS NOTES'
];
var SKILL_OPTIONS = [
    'React',
    'Azure',
    'Python',
    'AI/ML',
    'Node.js',
    'TypeScript',
    'DevOps',
    'Security',
    'SharePoint',
    'Power Platform'
];
var PRIORITIES = ['Low', 'Medium', 'High', 'Critical'];
var STAFF_POOL = [
    { EmployeeID: "Emp001", initials: 'SJ', name: 'Sarah Jenkins', role: 'PROJECT MANAGER', department: 'Program Delivery', match: 98, availability: 85, success: 94 },
    { EmployeeID: "Emp002", initials: 'AM', name: 'Amina Al-Mansoor', role: 'SOLUTION ARCHITECT', department: 'Enterprise Architecture', match: 95, availability: 72, success: 91 },
    { EmployeeID: "Emp003", initials: 'MC', name: 'Michael Chen', role: 'AI ENGINEER', department: 'AI Innovation Lab', match: 99, availability: 68, success: 97 },
    { EmployeeID: "Emp004", initials: 'CO', name: 'Clara Oswald', role: 'FRONTEND DEVELOPER', department: 'Digital Experience', match: 94, availability: 80, success: 89 },
    { EmployeeID: "Emp005", initials: 'ER', name: 'Elena Rostova', role: 'BACKEND DEVELOPER', department: 'Platform Engineering', match: 96, availability: 75, success: 92 },
    { EmployeeID: "Emp006", initials: 'SR', name: 'Siddharth Rao', role: 'QA ENGINEER', department: 'Quality Assurance', match: 92, availability: 88, success: 90 }
];
var PLAN_STATUSES = ['Not Started', 'In Progress', 'Done'];
var withPlanDefaults = function (item) {
    var _a, _b, _c;
    return (tslib_1.__assign(tslib_1.__assign({}, item), { assignee: (_a = item.assignee) !== null && _a !== void 0 ? _a : 'Sarah Jenkins', status: (_b = item.status) !== null && _b !== void 0 ? _b : 'Not Started', description: (_c = item.description) !== null && _c !== void 0 ? _c : '' }));
};
var DEFAULT_TIMELINE_COLUMNS = [
    '19-Feb-26', '20-Feb-26', '23-Feb-26', '24-Feb-26', '25-Feb-26', '26-Feb-26',
    '27-Feb-26', '02-Mar-26', '03-Mar-26', '04-Mar-26', '05-Mar-26', '06-Mar-26',
    '09-Mar-26', '10-Mar-26', '11-Mar-26', '12-Mar-26', '13-Mar-26', '16-Mar-26',
    '17-Mar-26', '18-Mar-26', '19-Mar-26', '20-Mar-26'
];
var PLAN_ITEMS = [
    withPlanDefaults({ slNo: 1, feature: 'General', task: 'List & Library Setup', startDate: '19-Feb-26', endDate: '19-Feb-26', efforts: 4, lane: 'development', startSlot: 0, durationSlots: 1, assignee: 'Sarah Jenkins' }),
    withPlanDefaults({ slNo: 1, feature: 'General', task: 'Solution Configuration', startDate: '19-Feb-26', endDate: '19-Feb-26', efforts: 4, lane: 'development', startSlot: 0, durationSlots: 1, assignee: 'Michael Chen' }),
    withPlanDefaults({ slNo: 1, feature: 'General', task: 'Role Management', startDate: '20-Feb-26', endDate: '20-Feb-26', efforts: 5, lane: 'development', startSlot: 1, durationSlots: 1, assignee: 'Elena Rostova' }),
    withPlanDefaults({ slNo: 2, feature: 'Dashboard', task: 'Dashboard Design', startDate: '20-Feb-26', endDate: '20-Feb-26', efforts: 6, lane: 'development', startSlot: 1, durationSlots: 1, assignee: 'Clara Oswald' }),
    withPlanDefaults({ slNo: 2, feature: 'Dashboard', task: 'Dashboard Functionality with Filters', startDate: '23-Feb-26', endDate: '23-Feb-26', efforts: 6, lane: 'development', startSlot: 2, durationSlots: 1, assignee: 'Clara Oswald' }),
    withPlanDefaults({ slNo: 2, feature: 'Dashboard', task: 'Export to Excel', startDate: '24-Feb-26', endDate: '24-Feb-26', efforts: 5, lane: 'development', startSlot: 3, durationSlots: 1, assignee: 'Michael Chen' }),
    withPlanDefaults({ slNo: 3, feature: 'Form', task: 'Request Form Design', startDate: '24-Feb-26', endDate: '24-Feb-26', efforts: 4, lane: 'development', startSlot: 3, durationSlots: 1, assignee: 'Clara Oswald' }),
    withPlanDefaults({ slNo: 3, feature: 'Form', task: 'Request Form Functionality', startDate: '25-Feb-26', endDate: '25-Feb-26', efforts: 5, lane: 'development', startSlot: 4, durationSlots: 1, assignee: 'Elena Rostova' }),
    withPlanDefaults({ slNo: 3, feature: 'Form', task: 'Store Manager Design', startDate: '26-Feb-26', endDate: '26-Feb-26', efforts: 8, lane: 'development', startSlot: 5, durationSlots: 1, assignee: 'Clara Oswald' }),
    withPlanDefaults({ slNo: 3, feature: 'Form', task: 'Store Manager Functionality', startDate: '27-Feb-26', endDate: '02-Mar-26', efforts: 10, lane: 'development', startSlot: 6, durationSlots: 2, assignee: 'Elena Rostova', status: 'In Progress' }),
    withPlanDefaults({ slNo: 3, feature: 'Form', task: 'All Documents Design', startDate: '02-Mar-26', endDate: '03-Mar-26', efforts: 8, lane: 'development', startSlot: 7, durationSlots: 2, assignee: 'Clara Oswald' }),
    withPlanDefaults({ slNo: 3, feature: 'Form', task: 'All Documents Functionality', startDate: '03-Mar-26', endDate: '04-Mar-26', efforts: 10, lane: 'development', startSlot: 8, durationSlots: 2, assignee: 'Michael Chen' }),
    withPlanDefaults({ slNo: 4, feature: 'Mail', task: 'Mail Conversation', startDate: '04-Mar-26', endDate: '04-Mar-26', efforts: 6, lane: 'development', startSlot: 9, durationSlots: 1, assignee: 'Elena Rostova' }),
    withPlanDefaults({ slNo: 4, feature: 'Mail', task: 'Notifications', startDate: '05-Mar-26', endDate: '05-Mar-26', efforts: 4, lane: 'development', startSlot: 10, durationSlots: 1, assignee: 'Sarah Jenkins' }),
    withPlanDefaults({ slNo: 5, feature: 'Testing', task: 'System Testing & Sign-off', startDate: '05-Mar-26', endDate: '06-Mar-26', efforts: 12, lane: 'testing', startSlot: 10, durationSlots: 2, assignee: 'Siddharth Rao' }),
    withPlanDefaults({ slNo: 6, feature: 'Demo followed by UAT deployment', task: 'Demo & UAT Deployment', startDate: '06-Mar-26', endDate: '06-Mar-26', efforts: 12, lane: 'demo', startSlot: 11, durationSlots: 1, assignee: 'Sarah Jenkins' })
];
var getAssigneeInitials = function (name, pool) {
    if (pool === void 0) { pool = STAFF_POOL; }
    var found = pool.find(function (s) { return s.name === name; });
    if (found)
        return found.initials;
    return name
        .split(' ')
        .map(function (p) { return p[0]; })
        .join('')
        .slice(0, 2)
        .toUpperCase();
};
var parsePlanDate = function (dateStr) {
    if (!dateStr)
        return new Date(0);
    var parts = dateStr.split('-');
    if (parts.length === 3) {
        var day = parseInt(parts[0], 10);
        var monthStr = parts[1];
        var year = parseInt(parts[2], 10);
        if (year < 100)
            year += 2000;
        var months = {
            jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5,
            jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11
        };
        var month = months[monthStr.toLowerCase()];
        if (month !== undefined && !isNaN(day) && !isNaN(year)) {
            return new Date(year, month, day);
        }
    }
    return new Date(0);
};
var AI_LOADING_MS = 10000;
var defaultIntake = {
    projectName: 'Project Secure Flight Portal',
    clientName: 'Boeing Aviation Systems',
    budget: '$125,000',
    startDate: '2026-06-01',
    endDate: '2026-10-31',
    projectDescription: 'Secure flight data portal with role-based access, dashboard analytics, and document workflow. Target go-live aligned with Q4 2026.',
    priority: 'High',
    skills: ['React'],
    architectNotes: ''
};
var ChipIcon = function () { return (React.createElement("svg", { width: "22", height: "22", viewBox: "0 0 24 24", fill: "none", "aria-hidden": "true" },
    React.createElement("rect", { x: "4", y: "4", width: "16", height: "16", rx: "3", stroke: "white", strokeWidth: "1.5" }),
    React.createElement("path", { d: "M9 9h6v6H9z", fill: "white", opacity: "0.9" }),
    React.createElement("path", { d: "M12 4v3M12 17v3M4 12h3M17 12h3", stroke: "white", strokeWidth: "1.2", strokeLinecap: "round" }))); };
var CheckIcon = function () { return (React.createElement("svg", { width: "14", height: "14", viewBox: "0 0 14 14", fill: "none", "aria-hidden": "true" },
    React.createElement("path", { d: "M3 7l3 3 5-6", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }))); };
var SourceDiamondIcon = function () { return (React.createElement("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", "aria-hidden": "true" },
    React.createElement("path", { d: "M12 3l7 4v10l-7 4-7-4V7l7-4z", stroke: "currentColor", strokeWidth: "1.8", strokeLinejoin: "round" }))); };
var DocumentUploadIcon = function () { return (React.createElement("svg", { width: "26", height: "26", viewBox: "0 0 24 24", fill: "none", "aria-hidden": "true" },
    React.createElement("path", { d: "M8 4h8l2 4v12a1 1 0 01-1 1H7a1 1 0 01-1-1V4z", stroke: "currentColor", strokeWidth: "1.8", strokeLinejoin: "round" }),
    React.createElement("path", { d: "M8 4v4h10M12 12v5M9.5 14.5L12 17l2.5-2.5", stroke: "currentColor", strokeWidth: "1.8", strokeLinecap: "round", strokeLinejoin: "round" }))); };
var ManualEntryIcon = function () { return (React.createElement("svg", { width: "26", height: "26", viewBox: "0 0 24 24", fill: "none", "aria-hidden": "true" },
    React.createElement("path", { d: "M4 20h4l10-10-4-4L4 16v4z", stroke: "currentColor", strokeWidth: "1.8", strokeLinejoin: "round" }),
    React.createElement("path", { d: "M13.5 6.5l2 2", stroke: "currentColor", strokeWidth: "1.8", strokeLinecap: "round" }))); };
var CardArrowIcon = function () { return (React.createElement("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", "aria-hidden": "true" },
    React.createElement("path", { d: "M5 12h14M13 6l6 6-6 6", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }))); };
var ExternalLinkIcon = function () { return (React.createElement("svg", { width: "16", height: "16", viewBox: "0 0 16 16", fill: "none", "aria-hidden": "true" },
    React.createElement("path", { d: "M6 3h7v7M13 3L6 10M9 3H3v10h10V9", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round" }))); };
var SuccessCheckIcon = function () { return (React.createElement("svg", { className: form_module_scss_1.default.successCheckSvg, width: "36", height: "36", viewBox: "0 0 36 36", fill: "none", "aria-hidden": "true" },
    React.createElement("path", { className: form_module_scss_1.default.successCheckPath, d: "M8 18l7 7 13-14", stroke: "white", strokeWidth: "3", strokeLinecap: "round", strokeLinejoin: "round" }))); };
var AI_AGENTS = [
    { id: 'mapping', label: 'Agent mapping', task: 'Mapping project specs to resource ontology…' },
    { id: 'analysis', label: 'Agent analysis', task: 'Running cognitive analysis on intake parameters…' },
    { id: 'skills', label: 'Skill graph scan', task: 'Cross-referencing required skills against talent graph…' },
    { id: 'scoring', label: 'Availability scoring', task: 'Scoring load metrics and historical success rates…' },
    { id: 'foundry', label: 'Azure AI Foundry', task: 'Calculating suitability arrays and confidence scores…' },
    { id: 'allocate', label: 'Pod allocation', task: 'Finalising optimal staff allocation pod…' }
];
var DOC_ANALYSIS_AGENTS = [
    { id: 'parse', label: 'Document parsing', task: 'Extracting text and structure from uploaded SOW…' },
    { id: 'entities', label: 'Entity recognition', task: 'Identifying client, budget, and timeline entities…' },
    { id: 'scope', label: 'Scope analysis', task: 'Mapping deliverables to intake specification fields…' },
    { id: 'skills', label: 'Skills inference', task: 'Inferring required skills and priority from document…' },
    { id: 'validate', label: 'Confidence scoring', task: 'Validating extracted fields against Aegis ontology…' }
];
var AI_AGENT_PHASES = AI_AGENTS.map(function (a) { return a.task; });
var DOC_ANALYSIS_MS = 6000;
var SOURCE_ADVANCE_MS = 2800;
var SAMPLE_DOC_EXTRACTION = {
    projectName: 'Project Secure Flight Portal',
    clientName: 'Boeing Aviation Systems',
    budget: '$125,000',
    startDate: '2026-06-01',
    endDate: '2026-10-31',
    projectDescription: 'Secure flight data portal with role-based access, dashboard analytics, and document workflow. Target go-live aligned with Q4 2026.',
    priority: 'High',
    skills: ['React', 'Azure', 'Security'],
    architectNotes: 'Extracted from SOW v2.1: Secure flight data portal with role-based access, dashboard analytics, and document workflow. Target go-live aligned with Q4 2026.'
};
var AiSparkleLoader = function () { return (React.createElement("div", { className: form_module_scss_1.default.aiSparkleLoader, "aria-hidden": "true", role: "status" },
    React.createElement("svg", { className: form_module_scss_1.default.aiOrbitRing1, viewBox: "0 0 120 120", fill: "none" },
        React.createElement("circle", { cx: "60", cy: "60", r: "54", stroke: "rgba(124,58,237,0.18)", strokeWidth: "1.5", strokeDasharray: "8 6" })),
    React.createElement("svg", { className: form_module_scss_1.default.aiOrbitRing2, viewBox: "0 0 120 120", fill: "none" },
        React.createElement("circle", { cx: "60", cy: "60", r: "42", stroke: "rgba(37,99,235,0.2)", strokeWidth: "1.2", strokeDasharray: "5 8" })),
    React.createElement("div", { className: form_module_scss_1.default.aiOrbCore },
        React.createElement("div", { className: form_module_scss_1.default.aiOrbGlow }),
        React.createElement("svg", { className: form_module_scss_1.default.aiSparkleSvg, viewBox: "0 0 60 60", fill: "none" },
            React.createElement("path", { className: form_module_scss_1.default.aiSparkleMain, d: "M30 16l2.8 11.2L44 30l-11.2 2.8L30 44l-2.8-11.2L16 30l11.2-2.8L30 16z", fill: "#7c3aed" }),
            React.createElement("path", { className: form_module_scss_1.default.aiSparkleDot1, d: "M46 14l1.4 2.8 2.8 1.4-2.8 1.4L46 22l-1.4-2.8L41.8 18l2.8-1.4L46 14z", fill: "#a78bfa" }),
            React.createElement("path", { className: form_module_scss_1.default.aiSparkleDot2, d: "M16 40l1 2 2 1-2 1-1 2-1-2-2-1 2-1 1-2z", fill: "#818cf8" }))),
    React.createElement("div", { className: form_module_scss_1.default.aiOrbitDot1 }),
    React.createElement("div", { className: form_module_scss_1.default.aiOrbitDot2 }))); };
var getWeekday = function (dateStr) {
    if (!dateStr)
        return '';
    var parts = dateStr.split('-');
    if (parts.length === 3) {
        var day = parseInt(parts[0], 10);
        var monthStr = parts[1];
        var year = parseInt(parts[2], 10);
        if (year < 100)
            year += 2000;
        var months = {
            jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5,
            jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11
        };
        var month = months[monthStr.toLowerCase()];
        if (month !== undefined && !isNaN(day) && !isNaN(year)) {
            var date = new Date(year, month, day);
            var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            return days[date.getDay()];
        }
    }
    return '';
};
var getExcelColumnLabel = function (index) {
    var label = '';
    var temp = index;
    while (temp >= 0) {
        label = String.fromCharCode((temp % 26) + 65) + label;
        temp = Math.floor(temp / 26) - 1;
    }
    return label;
};
var getRowSpans = function (items) {
    var slSpans = [];
    var featSpans = [];
    var i = 0;
    while (i < items.length) {
        var j = i + 1;
        while (j < items.length && items[j].slNo === items[i].slNo) {
            j++;
        }
        var span = j - i;
        slSpans[i] = span;
        for (var k = i + 1; k < j; k++) {
            slSpans[k] = 0;
        }
        i = j;
    }
    i = 0;
    while (i < items.length) {
        var j = i + 1;
        while (j < items.length && items[j].feature === items[i].feature) {
            j++;
        }
        var span = j - i;
        featSpans[i] = span;
        for (var k = i + 1; k < j; k++) {
            featSpans[k] = 0;
        }
        i = j;
    }
    return { slSpans: slSpans, featSpans: featSpans };
};
var getMonthSpans = function (columns) {
    var spans = [];
    if (columns.length === 0)
        return spans;
    var currentMonthStr = '';
    var currentSpan = 0;
    columns.forEach(function (col) {
        var parts = col.split('-');
        var monthLabel = '';
        if (parts.length === 3) {
            var m = parts[1];
            var y = parseInt(parts[2], 10);
            if (y < 100)
                y += 2000;
            var monthNames = {
                jan: 'Jan', feb: 'Feb', mar: 'Mar', apr: 'Apr',
                may: 'May', jun: 'Jun', jul: 'Jul', aug: 'Aug',
                sep: 'Sep', oct: 'Oct', nov: 'Nov', dec: 'Dec'
            };
            var monthShort = monthNames[m.toLowerCase()] || m;
            monthLabel = "".concat(monthShort, " ").concat(y);
        }
        else {
            monthLabel = col;
        }
        if (monthLabel === currentMonthStr) {
            currentSpan++;
        }
        else {
            if (currentSpan > 0) {
                spans.push({ label: currentMonthStr, span: currentSpan });
            }
            currentMonthStr = monthLabel;
            currentSpan = 1;
        }
    });
    if (currentSpan > 0) {
        spans.push({ label: currentMonthStr, span: currentSpan });
    }
    return spans;
};
var ProjectIntakeForm = function (_a) {
    var onClose = _a.onClose, onStepChange = _a.onStepChange;
    var css = form_module_scss_1.default;
    var _b = React.useState(1), step = _b[0], setStep = _b[1];
    var _c = React.useState(defaultIntake), intake = _c[0], setIntake = _c[1];
    var _d = React.useState(null), sourceMode = _d[0], setSourceMode = _d[1];
    var _e = React.useState('choose'), sourcePhase = _e[0], setSourcePhase = _e[1];
    var _f = React.useState(null), uploadedFileName = _f[0], setUploadedFileName = _f[1];
    var _g = React.useState(false), aiLoading = _g[0], setAiLoading = _g[1];
    var _h = React.useState(0), aiProgress = _h[0], setAiProgress = _h[1];
    var _j = React.useState(''), aiMessage = _j[0], setAiMessage = _j[1];
    var _k = React.useState(STAFF_POOL), recommendedStaff = _k[0], setRecommendedStaff = _k[1];
    var _l = React.useState(PLAN_ITEMS), planItems = _l[0], setPlanItems = _l[1];
    var _m = React.useState(DEFAULT_TIMELINE_COLUMNS), timelineColumns = _m[0], setTimelineColumns = _m[1];
    var _o = React.useState({
        'General': true,
        'Dashboard': true,
        'Form': true,
        'Mail': true,
        'Testing': true,
        'Demo followed by UAT deployment': true,
        'Deployment': true,
        'New Feature': true
    }), expandedFeatures = _o[0], setExpandedFeatures = _o[1];
    var _p = React.useState(100), planZoom = _p[0], setPlanZoom = _p[1];
    var importFileRef = React.useRef(null);
    var sourceFileRef = React.useRef(null);
    var sourceAdvanceRef = React.useRef();
    React.useEffect(function () {
        onStepChange === null || onStepChange === void 0 ? void 0 : onStepChange(step);
    }, [step, onStepChange]);
    var toggleFeatureExpand = function (feat) {
        setExpandedFeatures(function (prev) {
            var _a;
            return (tslib_1.__assign(tslib_1.__assign({}, prev), (_a = {}, _a[feat] = !prev[feat], _a)));
        });
    };
    var loadingTimerRef = React.useRef();
    var progressTimerRef = React.useRef();
    var clearTimers = React.useCallback(function () {
        if (loadingTimerRef.current) {
            window.clearTimeout(loadingTimerRef.current);
            loadingTimerRef.current = undefined;
        }
        if (progressTimerRef.current) {
            window.clearInterval(progressTimerRef.current);
            progressTimerRef.current = undefined;
        }
    }, []);
    React.useEffect(function () { return function () { return clearTimers(); }; }, [clearTimers]);
    var resetSourceStep = React.useCallback(function () {
        setSourceMode(null);
        setSourcePhase('choose');
        setUploadedFileName(null);
        if (sourceFileRef.current) {
            sourceFileRef.current.value = '';
        }
    }, []);
    React.useEffect(function () {
        if (step !== 1 || sourcePhase !== 'complete')
            return undefined;
        sourceAdvanceRef.current = window.setTimeout(function () {
            setStep(2);
            resetSourceStep();
        }, SOURCE_ADVANCE_MS);
        return function () {
            if (sourceAdvanceRef.current) {
                window.clearTimeout(sourceAdvanceRef.current);
                sourceAdvanceRef.current = undefined;
            }
        };
    }, [step, sourcePhase, resetSourceStep]);
    var _q = React.useState(AI_AGENTS), loadingAgents = _q[0], setLoadingAgents = _q[1];
    var runAiLoading = React.useCallback(function (message, onComplete, durationMs, agents) {
        if (durationMs === void 0) { durationMs = AI_LOADING_MS; }
        if (agents === void 0) { agents = AI_AGENTS; }
        clearTimers();
        setLoadingAgents(agents);
        setAiLoading(true);
        setAiMessage(message);
        setAiProgress(0);
        var start = Date.now();
        progressTimerRef.current = window.setInterval(function () {
            var elapsed = Date.now() - start;
            setAiProgress(Math.min(100, (elapsed / durationMs) * 100));
        }, 100);
        loadingTimerRef.current = window.setTimeout(function () {
            clearTimers();
            setAiLoading(false);
            setAiProgress(100);
            onComplete();
        }, durationMs);
    }, [clearTimers]);
    var updateIntake = function (patch) {
        setIntake(function (prev) { return (tslib_1.__assign(tslib_1.__assign({}, prev), patch)); });
    };
    var toggleSkill = function (skill) {
        setIntake(function (prev) { return (tslib_1.__assign(tslib_1.__assign({}, prev), { skills: prev.skills.indexOf(skill) >= 0
                ? prev.skills.filter(function (s) { return s !== skill; })
                : tslib_1.__spreadArray(tslib_1.__spreadArray([], prev.skills, true), [skill], false) })); });
    };
    var handleContinueFromIntake = function () {
        if (aiLoading)
            return;
        setStep(3);
        console.log("intake.skills", intake.skills);
        console.log("intake", intake);
        debugger;
        (0, aiagents_1.StaffRecommandAgent)(intake.skills, intake)
            .then(function (data) {
            if (Array.isArray(data)) {
                setRecommendedStaff(data);
            }
        })
            .catch(function (err) {
            console.error("Staff recommendation agent failed:", err);
        });
        runAiLoading('Azure AI Foundry calculating suitability arrays...', function () {
            /* staff view shown when loading ends */
        });
    };
    var handleGeneratePlan = function () {
        if (aiLoading)
            return;
        (0, aiagents_1.ProjectPlanAgent)(recommendedStaff.map(function (s) { return s.name; }), intake)
            .then(function (data) {
            if (!Array.isArray(data))
                return;
            var datesList = [];
            data.forEach(function (item) {
                datesList.push(String(item.startDate));
                datesList.push(String(item.endDate));
            });
            var uniqueDates = Array.from(new Set(datesList))
                .sort(function (a, b) { return parsePlanDate(a).getTime() - parsePlanDate(b).getTime(); });
            var mapped = data.map(function (item) {
                var _a, _b;
                var startIdx = uniqueDates.indexOf(item.startDate);
                var endIdx = uniqueDates.indexOf(item.endDate);
                return tslib_1.__assign(tslib_1.__assign({}, item), { description: (_a = item.description) !== null && _a !== void 0 ? _a : '', startSlot: startIdx >= 0 ? startIdx : 0, durationSlots: endIdx >= startIdx ? endIdx - startIdx + 1 : 1, status: (_b = item.status) !== null && _b !== void 0 ? _b : 'Not Started' });
            });
            setTimelineColumns(uniqueDates);
            setPlanItems(mapped);
        })
            .catch(function (err) {
            console.error("ProjectPlanAgent failed:", err);
        });
        runAiLoading('Cognitive Model formulating SOW timeline phases...', function () { return setStep(4); }, 4000);
    };
    var handleSendForApproval = function () {
        setStep(5);
    };
    var handleApprove = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp_1, generateProjectCode, safeISOString_1, cleanBudget, newProjectCode_1, items, teamAllocation, updateplanItems, err_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 5, , 6]);
                    sp_1 = (0, initservice_1.getSP)();
                    generateProjectCode = function () {
                        var now = new Date();
                        var mVal = now.getMonth() + 1;
                        var mm = mVal < 10 ? '0' + mVal : String(mVal);
                        var yyyy = now.getFullYear();
                        var randomNum = Math.floor(100 + Math.random() * 900); // 3 digits
                        return "P-".concat(mm, "-").concat(yyyy, "-").concat(randomNum);
                    };
                    safeISOString_1 = function (dateStr) {
                        try {
                            var d = new Date(dateStr);
                            return isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
                        }
                        catch (_a) {
                            return new Date().toISOString();
                        }
                    };
                    cleanBudget = function (budgetStr) {
                        var cleaned = (budgetStr || '').replace(/[^0-9.-]+/g, "");
                        var num = Number(cleaned);
                        return isNaN(num) ? 0 : num;
                    };
                    newProjectCode_1 = generateProjectCode();
                    return [4 /*yield*/, sp_1.web.lists.getByTitle("Project").items.add({
                            ProjectCode: newProjectCode_1,
                            ProjectName: intake.projectName,
                            Client: intake.clientName,
                            isManagerApproved: false,
                            StartDate: safeISOString_1(intake.startDate),
                            EndDate: safeISOString_1(intake.endDate),
                            Priority: intake.priority,
                            RequiredSkills: intake.skills.join(', '),
                            Budget: cleanBudget(intake.budget),
                            Description: intake.projectDescription
                        })];
                case 1:
                    _a.sent();
                    debugger;
                    return [4 /*yield*/, sp_1.web.lists
                            .getByTitle("ProjectParticipation")
                            .items
                            .select("*")()];
                case 2:
                    items = _a.sent();
                    console.log("projectPlan", JSON.stringify(items));
                    debugger;
                    return [4 /*yield*/, Promise.all(recommendedStaff.map(function (staff) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
                            return tslib_1.__generator(this, function (_a) {
                                return [2 /*return*/, sp_1.web.lists.getByTitle("ProjectParticipation").items.add({
                                        field_1: staff.EmployeeID, // EmployeeID
                                        field_2: staff.name, // FullName
                                        field_3: newProjectCode_1, // ProjectCode (stored in field_3)
                                        field_4: staff.role, // RoleInProject
                                        field_5: staff.availability, // ContributionPercent
                                        field_6: safeISOString_1(intake.startDate), // StartDate
                                        field_7: safeISOString_1(intake.endDate), // EndDate
                                    })];
                            });
                        }); }))];
                case 3:
                    teamAllocation = _a.sent();
                    debugger;
                    return [4 /*yield*/, Promise.all(planItems.map(function (Task) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
                            return tslib_1.__generator(this, function (_a) {
                                return [2 /*return*/, sp_1.web.lists.getByTitle("TaskDetails").items.add({
                                        Task: Task.task, // EmployeeID
                                        Sno: Task.slNo.toString(), // FullName
                                        ProjectCode: newProjectCode_1, // ProjectCode
                                        Assignee: Task.assignee, // RoleInProject
                                        lane: Task.lane,
                                        Effort: Task.efforts.toString(),
                                        startSlot: Task.startSlot.toString(),
                                        durationSlots: Task.durationSlots.toString(),
                                        // Types:Task.lane,
                                        Status: Task.status,
                                        StartDate: safeISOString_1(intake.startDate), // StartDate
                                        EndDate: safeISOString_1(intake.endDate), // EndDate
                                    })];
                            });
                        }); }))];
                case 4:
                    updateplanItems = _a.sent();
                    debugger;
                    console.log("Successfully created project item in SharePoint!");
                    setStep(6);
                    return [3 /*break*/, 6];
                case 5:
                    err_1 = _a.sent();
                    console.error("Failed to save project item in SharePoint:", err_1);
                    setStep(6);
                    return [3 /*break*/, 6];
                case 6: return [2 /*return*/];
            }
        });
    }); };
    var handleReject = function () {
        clearTimers();
        setAiLoading(false);
        setAiProgress(0);
        setAiMessage('');
        setStep(2);
        resetSourceStep();
        setIntake(function (prev) { return (tslib_1.__assign(tslib_1.__assign({}, prev), { architectNotes: '' })); });
    };
    var handleBack = function () {
        if (aiLoading)
            return;
        clearTimers();
        setAiLoading(false);
        setAiProgress(0);
        setAiMessage('');
        if (sourceAdvanceRef.current) {
            window.clearTimeout(sourceAdvanceRef.current);
            sourceAdvanceRef.current = undefined;
        }
        if (step === 2) {
            setStep(1);
            resetSourceStep();
            return;
        }
        if (step > 2) {
            setStep(function (s) { return s - 1; });
        }
    };
    var handleSelectManualEntry = function () {
        if (aiLoading)
            return;
        setSourceMode('manual');
        setStep(2);
    };
    var handleSelectDocumentUpload = function () {
        if (aiLoading)
            return;
        setSourceMode('upload');
        setSourcePhase('upload');
    };
    var handleSourceFileSelected = function (e) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var file, pdfText_1, err_2;
        var _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    file = (_a = e.target.files) === null || _a === void 0 ? void 0 : _a[0];
                    if (!file || aiLoading)
                        return [2 /*return*/];
                    _b.label = 1;
                case 1:
                    _b.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, (0, extractpdf_1.extractPdfText)(file)];
                case 2:
                    pdfText_1 = _b.sent();
                    setUploadedFileName(file.name);
                    setSourcePhase('analyzing');
                    runAiLoading('Azure AI agent analyzing uploaded statement of work…', function () {
                        debugger;
                        console.log(pdfText_1, "pdfText");
                        (0, aiagents_1.uploadPdfAndAnalyze)(pdfText_1)
                            .then(function (data) {
                            var parsed = data;
                            if (data && typeof data.response === 'string') {
                                try {
                                    parsed = JSON.parse(data.response);
                                }
                                catch (e) {
                                    console.error("Failed to parse data.response as JSON string:", e);
                                }
                            }
                            else if (data && typeof data.response === 'object' && data.response !== null) {
                                parsed = data.response;
                            }
                            var projectName = parsed.ProjectName || parsed.projectName || 'Project Secure Flight Portal';
                            var clientName = parsed.Client || parsed.client || parsed.clientName || 'Boeing Aviation Systems';
                            var budget = '$125,000';
                            if (parsed.Budget !== undefined && parsed.Budget !== null) {
                                var bNum = Number(parsed.Budget);
                                if (!isNaN(bNum)) {
                                    budget = bNum.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
                                }
                                else {
                                    budget = String(parsed.Budget);
                                }
                            }
                            else if (parsed.budget) {
                                budget = String(parsed.budget);
                            }
                            var startDate = parsed.StartDate || parsed.startDate || '2026-06-01';
                            var endDate = parsed.EndDate || parsed.endDate || parsed.dueDate || '2026-10-31';
                            var priority = 'High';
                            var pRaw = String(parsed.Priority || parsed.priority || 'High').toLowerCase();
                            if (pRaw === 'low')
                                priority = 'Low';
                            else if (pRaw === 'medium')
                                priority = 'Medium';
                            else if (pRaw === 'high')
                                priority = 'High';
                            else if (pRaw === 'critical')
                                priority = 'Critical';
                            var skills = ['React'];
                            var rawSkills = parsed.RequiredSkills || parsed.skills || parsed.requiredSkills;
                            if (Array.isArray(rawSkills)) {
                                skills = rawSkills.map(function (s) {
                                    var match = SKILL_OPTIONS.find(function (opt) { return opt.toLowerCase() === String(s).toLowerCase(); });
                                    return match || String(s);
                                });
                            }
                            var projectDescription = parsed.Projectdescription || parsed.projectdescription || parsed.architectNotes || '';
                            var architectNotes = parsed.Projectdescription || parsed.projectdescription || parsed.architectNotes || '';
                            setIntake({
                                projectName: projectName,
                                clientName: clientName,
                                budget: budget,
                                startDate: startDate,
                                endDate: endDate,
                                projectDescription: projectDescription,
                                priority: priority,
                                skills: skills,
                                architectNotes: architectNotes
                            });
                            setSourcePhase('complete');
                        })
                            .catch(function (err) {
                            console.error("AI upload failed:", err);
                            setSourcePhase('complete');
                        });
                    }, DOC_ANALYSIS_MS, DOC_ANALYSIS_AGENTS);
                    console.log(pdfText_1);
                    return [3 /*break*/, 4];
                case 3:
                    err_2 = _b.sent();
                    console.error("PDF extraction failed", err_2);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var handlePlanChange = function (index, field, value) {
        setPlanItems(function (prev) {
            return prev.map(function (row, i) {
                var _a;
                if (i !== index)
                    return row;
                var updated = tslib_1.__assign(tslib_1.__assign({}, row), (_a = {}, _a[field] = value, _a));
                var startIdx = Math.max(0, timelineColumns.indexOf(updated.startDate));
                var endIdx = Math.max(startIdx, timelineColumns.indexOf(updated.endDate));
                updated.startSlot = startIdx;
                updated.durationSlots = Math.max(1, endIdx - startIdx + 1);
                return updated;
            });
        });
    };
    var handleGroupSlNoChange = function (oldVal, newVal) {
        setPlanItems(function (prev) {
            return prev.map(function (row) { return (row.slNo === oldVal ? tslib_1.__assign(tslib_1.__assign({}, row), { slNo: newVal }) : row); });
        });
    };
    var handleGroupFeatureChange = function (oldVal, newVal) {
        setPlanItems(function (prev) {
            return prev.map(function (row) { return (row.feature === oldVal ? tslib_1.__assign(tslib_1.__assign({}, row), { feature: newVal }) : row); });
        });
    };
    var handleAddPlanRow = function () {
        setPlanItems(function (prev) {
            var _a, _b;
            return tslib_1.__spreadArray(tslib_1.__spreadArray([], prev, true), [
                {
                    slNo: prev.length > 0 ? prev[prev.length - 1].slNo + 1 : 1,
                    feature: 'New Feature',
                    task: 'New Task',
                    description: '',
                    startDate: timelineColumns[0] || 'New Date',
                    endDate: timelineColumns[0] || 'New Date',
                    efforts: 1,
                    lane: 'development',
                    startSlot: 0,
                    durationSlots: 1,
                    assignee: (_b = (_a = recommendedStaff[0]) === null || _a === void 0 ? void 0 : _a.name) !== null && _b !== void 0 ? _b : 'Unassigned',
                    status: 'Not Started'
                }
            ], false);
        });
    };
    var handleRegeneratePlan = function () {
        if (aiLoading)
            return;
        (0, aiagents_1.ProjectPlanAgent)(recommendedStaff.map(function (s) { return s.name; }), intake)
            .then(function (data) {
            if (!Array.isArray(data))
                return;
            var datesList = [];
            data.forEach(function (item) {
                datesList.push(String(item.startDate));
                datesList.push(String(item.endDate));
            });
            var uniqueDates = Array.from(new Set(datesList))
                .sort(function (a, b) { return parsePlanDate(a).getTime() - parsePlanDate(b).getTime(); });
            var mapped = data.map(function (item) {
                var _a, _b;
                var startIdx = uniqueDates.indexOf(item.startDate);
                var endIdx = uniqueDates.indexOf(item.endDate);
                return tslib_1.__assign(tslib_1.__assign({}, item), { description: (_a = item.description) !== null && _a !== void 0 ? _a : '', startSlot: startIdx >= 0 ? startIdx : 0, durationSlots: endIdx >= startIdx ? endIdx - startIdx + 1 : 1, status: (_b = item.status) !== null && _b !== void 0 ? _b : 'Not Started' });
            });
            setTimelineColumns(uniqueDates);
            setPlanItems(mapped);
        })
            .catch(function (err) {
            console.error("ProjectPlanAgent failed:", err);
        });
        runAiLoading('AI regenerating project plan from intake context...', function () {
            // Completed in async call above
        }, 3000);
    };
    // const handleImportExcel = (event: React.ChangeEvent<HTMLInputElement>): void => {
    //   const file = event.target.files?.[0];
    //   if (!file) return;
    //   const reader = new FileReader();
    //   reader.onload = (e): void => {
    //     const buffer = e.target?.result;
    //     if (!buffer) return;
    //     const workbook = XLSX.read(buffer, { type: 'array' });
    //     const sheetName = workbook.SheetNames[0];
    //     const sheet = workbook.Sheets[sheetName];
    //     const rows = XLSX.utils.sheet_to_json<Record<string, string | number>>(sheet, { defval: '' });
    //     const imported: PlanItem[] = rows
    //       .filter((row) => String(row.Tasks || row.Task || '').trim().length > 0)
    //       .map((row, idx) => {
    //         const startDate = String(row['Start Date'] || timelineColumns[0] || '19-Feb-26');
    //         const endDate = String(row['End Date'] || startDate);
    //         const startIdx = Math.max(0, timelineColumns.indexOf(startDate));
    //         const endIdx = Math.max(startIdx, timelineColumns.indexOf(endDate));
    //         const laneRaw = String(row.Lane || row.Type || 'development').toLowerCase();
    //         const lane: PlanLane =
    //           laneRaw.indexOf('test') >= 0 ? 'testing' : laneRaw.indexOf('demo') >= 0 || laneRaw.indexOf('deploy') >= 0 ? 'demo' : 'development';
    //         return withPlanDefaults({
    //           slNo: Number(row['Sl.No'] || row['#'] || idx + 1),
    //           feature: String(row.Feature || 'Imported'),
    //           task: String(row.Tasks || row.Task || `Task ${idx + 1}`),
    //           startDate,
    //           endDate,
    //           efforts: Math.max(1, Number(row['Efforts (in hrs)'] || row['Effort (hrs)'] || row.Efforts || 1)),
    //           lane,
    //           startSlot: startIdx,
    //           durationSlots: Math.max(1, endIdx - startIdx + 1),
    //           assignee: String(row.Assignee || STAFF_POOL[0]?.name || 'Unassigned'),
    //           status: (String(row.Status || 'Not Started') as PlanStatus)
    //         });
    //       });
    //     if (imported.length > 0) {
    //       setPlanItems(imported);
    //     }
    //     if (importFileRef.current) {
    //       importFileRef.current.value = '';
    //     }
    //   };
    //   reader.readAsArrayBuffer(file);
    // };
    var handleAddTimelineColumn = function () {
        var nextLabel = "Day-".concat(timelineColumns.length + 1);
        setTimelineColumns(function (prev) { return tslib_1.__spreadArray(tslib_1.__spreadArray([], prev, true), [nextLabel], false); });
    };
    var handleRemoveTimelineColumn = function () {
        setTimelineColumns(function (prev) {
            if (prev.length <= 1)
                return prev;
            var next = prev.slice(0, -1);
            setPlanItems(function (items) {
                return items.map(function (item) {
                    var maxSlot = next.length - 1;
                    var startSlot = Math.min(item.startSlot, maxSlot);
                    var durationSlots = Math.max(1, Math.min(item.durationSlots, next.length - startSlot));
                    return tslib_1.__assign(tslib_1.__assign({}, item), { startSlot: startSlot, durationSlots: durationSlots, startDate: next[startSlot], endDate: next[Math.min(next.length - 1, startSlot + durationSlots - 1)] });
                });
            });
            return next;
        });
    };
    var handleRenameTimelineColumn = function (index, label) {
        var trimmed = label.trim();
        if (!trimmed)
            return;
        setTimelineColumns(function (prev) {
            var oldLabel = prev[index];
            var next = tslib_1.__spreadArray([], prev, true);
            next[index] = trimmed;
            setPlanItems(function (items) {
                return items.map(function (item) { return (tslib_1.__assign(tslib_1.__assign({}, item), { startDate: item.startDate === oldLabel ? trimmed : item.startDate, endDate: item.endDate === oldLabel ? trimmed : item.endDate })); });
            });
            return next;
        });
    };
    var handleDeletePlanRow = function (index) {
        setPlanItems(function (prev) { return prev.filter(function (_, i) { return i !== index; }); });
    };
    var handleExportProjectPlan = function () {
        var headers = tslib_1.__spreadArray([
            'Sl.No',
            'Feature',
            'Tasks',
            'Description',
            'Type',
            'Start Date',
            'End Date',
            'Effort (hrs)',
            'Assignee',
            'Status'
        ], timelineColumns, true);
        var rows = planItems.map(function (item) {
            var timelineCells = timelineColumns.map(function (_, slot) {
                return slot >= item.startSlot && slot < item.startSlot + item.durationSlots ? item.lane : '';
            });
            return tslib_1.__spreadArray([
                item.slNo,
                item.feature,
                item.task,
                item.description || '',
                item.lane,
                item.startDate,
                item.endDate,
                item.efforts,
                item.assignee,
                item.status
            ], timelineCells, true);
        });
        var sheet = XLSX.utils.aoa_to_sheet(tslib_1.__spreadArray([headers], rows, true));
        var workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, sheet, 'Project Plan');
        var safeProjectName = (intake.projectName || 'Project Plan').replace(/[\\/:*?"<>|]+/g, '-').trim();
        XLSX.writeFile(workbook, "".concat(safeProjectName, " - Project Plan.xlsx"));
    };
    var skillsSummary = intake.skills.length > 0 ? intake.skills.join(', ') : 'general delivery';
    var renderStepper = function () { return (React.createElement("div", { className: form_module_scss_1.default.stepper }, STEPS.map(function (label, index) {
        var stepNum = index + 1;
        var nextStep = stepNum + 1;
        var isDone = stepNum < step;
        var isActive = stepNum === step && !aiLoading;
        var showCheck = isDone && stepNum !== step;
        var connectorDone = nextStep < step;
        var connectorToActive = nextStep === step;
        return (React.createElement("div", { key: label, className: form_module_scss_1.default.stepItem },
            index < STEPS.length - 1 && (React.createElement("div", { className: "".concat(form_module_scss_1.default.stepConnector, " ").concat(connectorDone ? form_module_scss_1.default.connectorDone : '', " ").concat(connectorToActive ? form_module_scss_1.default.connectorToActive : '') })),
            React.createElement("div", { className: "".concat(form_module_scss_1.default.stepCircle, " ").concat(isActive ? form_module_scss_1.default.active : '', " ").concat(isDone ? form_module_scss_1.default.done : '') }, showCheck ? React.createElement(CheckIcon, null) : stepNum),
            React.createElement("span", { className: "".concat(form_module_scss_1.default.stepLabel, " ").concat(isActive ? form_module_scss_1.default.active : '', " ").concat(isDone ? form_module_scss_1.default.done : '') }, label)));
    }))); };
    var loadingPhases = loadingAgents.map(function (a) { return a.task; });
    var activePhaseIndex = Math.min(loadingPhases.length - 1, Math.floor((aiProgress / 100) * loadingPhases.length));
    var renderAiLoading = function (title, agents) {
        var agentList = agents !== null && agents !== void 0 ? agents : loadingAgents;
        var phases = agentList.map(function (a) { return a.task; });
        var statusText = aiMessage || phases[activePhaseIndex];
        return (React.createElement("div", { className: form_module_scss_1.default.aiLoading },
            React.createElement(AiSparkleLoader, null),
            React.createElement("h3", { className: form_module_scss_1.default.aiLoadingTitle }, title),
            React.createElement("p", { className: form_module_scss_1.default.aiLoadingSub },
                statusText,
                React.createElement("span", { className: form_module_scss_1.default.aiLoadingDots, "aria-hidden": "true" },
                    React.createElement("span", null, "."),
                    React.createElement("span", null, "."),
                    React.createElement("span", null, "."))),
            React.createElement("div", { className: form_module_scss_1.default.aiProgressWrap },
                React.createElement("div", { className: form_module_scss_1.default.aiProgress },
                    React.createElement("div", { className: form_module_scss_1.default.aiProgressBar, style: { width: "".concat(aiProgress, "%") } })),
                React.createElement("span", { className: form_module_scss_1.default.aiProgressPct },
                    Math.round(aiProgress),
                    "%")),
            React.createElement("ul", { className: form_module_scss_1.default.aiAgentSteps, "aria-label": "Agent processing steps" }, agentList.map(function (agent, idx) {
                var isDone = idx < activePhaseIndex;
                var isActive = idx === activePhaseIndex;
                return (React.createElement("li", { key: agent.id, className: "".concat(form_module_scss_1.default.aiAgentStep, " ").concat(isDone ? form_module_scss_1.default.aiAgentStepDone : '', " ").concat(isActive ? form_module_scss_1.default.aiAgentStepActive : '') },
                    React.createElement("span", { className: form_module_scss_1.default.aiAgentStepMark, "aria-hidden": "true" }, isDone ? '✓' : isActive ? React.createElement("span", { className: form_module_scss_1.default.aiAgentStepSpinner }) : '○'),
                    React.createElement("span", { className: form_module_scss_1.default.aiAgentStepLabel }, agent.label),
                    isActive && React.createElement("span", { className: form_module_scss_1.default.aiAgentStepStatus }, "processing")));
            }))));
    };
    var renderSourceResult = function () { return (React.createElement("div", { className: form_module_scss_1.default.sourceResult },
        React.createElement("div", { className: form_module_scss_1.default.sourceResultBadge },
            React.createElement(CheckIcon, null),
            React.createElement("span", null, "Analysis complete")),
        React.createElement("h3", { className: form_module_scss_1.default.sourceResultTitle }, "Agent extraction summary"),
        React.createElement("p", { className: form_module_scss_1.default.sourceResultFile },
            "Source: ",
            React.createElement("strong", null, uploadedFileName)),
        React.createElement("div", { className: form_module_scss_1.default.sourceResultCard },
            React.createElement("dl", { className: form_module_scss_1.default.sourceResultGrid },
                React.createElement("div", null,
                    React.createElement("dt", null, "Project"),
                    React.createElement("dd", null, SAMPLE_DOC_EXTRACTION.projectName)),
                React.createElement("div", null,
                    React.createElement("dt", null, "Client"),
                    React.createElement("dd", null, SAMPLE_DOC_EXTRACTION.clientName)),
                React.createElement("div", null,
                    React.createElement("dt", null, "Budget"),
                    React.createElement("dd", null, SAMPLE_DOC_EXTRACTION.budget)),
                React.createElement("div", null,
                    React.createElement("dt", null, "Priority"),
                    React.createElement("dd", null, SAMPLE_DOC_EXTRACTION.priority)),
                React.createElement("div", { className: form_module_scss_1.default.sourceResultFull },
                    React.createElement("dt", null, "Skills detected"),
                    React.createElement("dd", null, SAMPLE_DOC_EXTRACTION.skills.join(', '))),
                React.createElement("div", { className: form_module_scss_1.default.sourceResultFull },
                    React.createElement("dt", null, "Scope notes"),
                    React.createElement("dd", null, SAMPLE_DOC_EXTRACTION.architectNotes)))),
        React.createElement("p", { className: form_module_scss_1.default.sourceResultHint }, "Fields pre-filled in Intake Spec \u2014 advancing automatically\u2026"))); };
    var renderSourceUpload = function () { return (React.createElement("div", { className: form_module_scss_1.default.sourceUpload },
        React.createElement("button", { type: "button", className: form_module_scss_1.default.uploadZone, onClick: function () { var _a; return (_a = sourceFileRef.current) === null || _a === void 0 ? void 0 : _a.click(); }, "aria-label": "Upload document" },
            React.createElement("span", { className: form_module_scss_1.default.uploadIcon, "aria-hidden": "true" },
                React.createElement("svg", { viewBox: "0 0 24 24", width: "32", height: "32", fill: "none" },
                    React.createElement("path", { d: "M12 16V4M12 4l-4 4M12 4l4 4", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
                    React.createElement("path", { d: "M4 14v4a2 2 0 002 2h12a2 2 0 002-2v-4", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round" }))),
            React.createElement("strong", null, "Drop file here or click to browse"),
            React.createElement("span", null, "PDF, DOCX, or TXT \u2014 max 25 MB")),
        React.createElement("input", { ref: sourceFileRef, type: "file", className: form_module_scss_1.default.hiddenFileInput, accept: ".pdf,.doc,.docx,.txt", onChange: handleSourceFileSelected, "aria-hidden": "true", tabIndex: -1 }),
        React.createElement("button", { type: "button", className: form_module_scss_1.default.sourceBackLink, onClick: resetSourceStep }, "\u2190 Choose a different source method"))); };
    var renderSourceHero = function (title, desc, icon) { return (React.createElement("div", { className: form_module_scss_1.default.sourceHero },
        React.createElement("div", { className: form_module_scss_1.default.sourceHeroIcon }, icon),
        React.createElement("div", null,
            React.createElement("h2", { className: form_module_scss_1.default.sourceHeroTitle }, title),
            React.createElement("p", { className: form_module_scss_1.default.sourceHeroDesc }, desc)))); };
    var renderSourceChoose = function () { return (React.createElement("div", { className: form_module_scss_1.default.sourcePanel },
        React.createElement("div", { className: form_module_scss_1.default.sourceOptions },
            React.createElement("button", { type: "button", className: "".concat(form_module_scss_1.default.sourceOptionCard, " ").concat(form_module_scss_1.default.sourceOptionUpload), onClick: handleSelectDocumentUpload },
                React.createElement("span", { className: form_module_scss_1.default.sourceOptionAccent, "aria-hidden": "true" }),
                React.createElement("span", { className: form_module_scss_1.default.sourceOptionBadge }, "AI Powered"),
                React.createElement("span", { className: "".concat(form_module_scss_1.default.sourceOptionIconWrap, " ").concat(form_module_scss_1.default.sourceOptionIconUpload) },
                    React.createElement(DocumentUploadIcon, null)),
                React.createElement("span", { className: form_module_scss_1.default.sourceOptionTitle }, "Document Upload"),
                React.createElement("span", { className: form_module_scss_1.default.sourceOptionDesc }, "Upload a SOW or brief. The AI agent will analyze it and pre-fill intake fields."),
                React.createElement("ul", { className: form_module_scss_1.default.sourceOptionFeatures },
                    React.createElement("li", null, "PDF, DOCX, TXT"),
                    React.createElement("li", null, "Auto-extract fields")),
                React.createElement("span", { className: form_module_scss_1.default.sourceOptionCta },
                    "Select upload ",
                    React.createElement(CardArrowIcon, null))),
            React.createElement("button", { type: "button", className: "".concat(form_module_scss_1.default.sourceOptionCard, " ").concat(form_module_scss_1.default.sourceOptionManual), onClick: handleSelectManualEntry },
                React.createElement("span", { className: form_module_scss_1.default.sourceOptionAccent, "aria-hidden": "true" }),
                React.createElement("span", { className: "".concat(form_module_scss_1.default.sourceOptionBadge, " ").concat(form_module_scss_1.default.sourceOptionBadgeMuted) }, "Self-guided"),
                React.createElement("span", { className: "".concat(form_module_scss_1.default.sourceOptionIconWrap, " ").concat(form_module_scss_1.default.sourceOptionIconManual) },
                    React.createElement(ManualEntryIcon, null)),
                React.createElement("span", { className: form_module_scss_1.default.sourceOptionTitle }, "Manual Entry"),
                React.createElement("span", { className: form_module_scss_1.default.sourceOptionDesc }, "Enter project specifications yourself on the next step."),
                React.createElement("ul", { className: form_module_scss_1.default.sourceOptionFeatures },
                    React.createElement("li", null, "Full control"),
                    React.createElement("li", null, "Skip analysis")),
                React.createElement("span", { className: form_module_scss_1.default.sourceOptionCta },
                    "Continue manually ",
                    React.createElement(CardArrowIcon, null)))))); };
    var renderSourceStep = function () {
        if (sourcePhase === 'analyzing' && aiLoading) {
            return (React.createElement("div", { className: form_module_scss_1.default.sourceStepInner }, renderAiLoading('Analyzing uploaded document', DOC_ANALYSIS_AGENTS)));
        }
        if (sourcePhase === 'complete') {
            return React.createElement("div", { className: form_module_scss_1.default.sourceStepInner }, renderSourceResult());
        }
        if (sourceMode === 'upload' && sourcePhase === 'upload') {
            return (React.createElement("div", { className: form_module_scss_1.default.sourceStepInner },
                renderSourceHero('Document Upload', 'Upload your statement of work or project brief. Our agent will extract key intake fields automatically.', React.createElement(DocumentUploadIcon, null)),
                renderSourceUpload()));
        }
        return (React.createElement("div", { className: form_module_scss_1.default.sourceStepInner },
            renderSourceHero('Choose Intake Source', 'Select how you want to provide project information for this intake wizard.', React.createElement(SourceDiamondIcon, null)),
            renderSourceChoose()));
    };
    var renderIntakeSpec = function () { return (React.createElement(React.Fragment, null,
        React.createElement("h2", { className: form_module_scss_1.default.sectionTitle },
            React.createElement("span", { className: form_module_scss_1.default.sectionIcon, "aria-hidden": "true" }, "\u270F\uFE0F"),
            "Manual Project Specification Entry"),
        React.createElement("p", { className: form_module_scss_1.default.sectionDesc }, "Provide direct properties to formulate optimized AI capacity allocations."),
        React.createElement("div", { className: form_module_scss_1.default.formGrid },
            React.createElement("div", { className: form_module_scss_1.default.field },
                React.createElement("label", { className: form_module_scss_1.default.label, htmlFor: "projectName" }, "Project Name"),
                React.createElement("input", { id: "projectName", className: form_module_scss_1.default.input, value: intake.projectName, onChange: function (e) { return updateIntake({ projectName: e.target.value }); } })),
            React.createElement("div", { className: form_module_scss_1.default.field },
                React.createElement("label", { className: form_module_scss_1.default.label, htmlFor: "clientName" }, "Client Name"),
                React.createElement("input", { id: "clientName", className: form_module_scss_1.default.input, value: intake.clientName, onChange: function (e) { return updateIntake({ clientName: e.target.value }); } })),
            React.createElement("div", { className: form_module_scss_1.default.field },
                React.createElement("label", { className: form_module_scss_1.default.label, htmlFor: "budget" }, "Budget Limit Amount"),
                React.createElement("input", { id: "budget", className: form_module_scss_1.default.input, value: intake.budget, onChange: function (e) { return updateIntake({ budget: e.target.value }); } })),
            React.createElement("div", { className: form_module_scss_1.default.field },
                React.createElement("label", { className: form_module_scss_1.default.label, htmlFor: "startDate" }, "Start Date"),
                React.createElement("div", { className: form_module_scss_1.default.dateWrap },
                    React.createElement("input", { id: "startDate", type: "date", className: form_module_scss_1.default.input, value: intake.startDate, onChange: function (e) { return updateIntake({ startDate: e.target.value }); } }),
                    React.createElement("span", { className: form_module_scss_1.default.dateIcon, "aria-hidden": "true" }, "\uD83D\uDCC5"))),
            React.createElement("div", { className: form_module_scss_1.default.field },
                React.createElement("label", { className: form_module_scss_1.default.label, htmlFor: "endDate" }, "End Date"),
                React.createElement("div", { className: form_module_scss_1.default.dateWrap },
                    React.createElement("input", { id: "endDate", type: "date", className: form_module_scss_1.default.input, value: intake.endDate, onChange: function (e) { return updateIntake({ endDate: e.target.value }); } }),
                    React.createElement("span", { className: form_module_scss_1.default.dateIcon, "aria-hidden": "true" }, "\uD83D\uDCC5"))),
            React.createElement("div", { className: "".concat(form_module_scss_1.default.field, " ").concat(form_module_scss_1.default.fieldFull) },
                React.createElement("label", { className: form_module_scss_1.default.label, htmlFor: "projectDescription" }, "Project Description"),
                React.createElement("input", { id: "projectDescription", type: "text", className: form_module_scss_1.default.input, style: { height: '80px' }, value: intake.projectDescription, onChange: function (e) { return updateIntake({ projectDescription: e.target.value }); } }))),
        React.createElement("div", { className: form_module_scss_1.default.priorityRow },
            React.createElement("span", { className: form_module_scss_1.default.label }, "Select Priority Level"),
            React.createElement("div", { className: form_module_scss_1.default.priorityBtns }, PRIORITIES.map(function (p) { return (React.createElement("button", { key: p, type: "button", className: "".concat(form_module_scss_1.default.priorityBtn, " ").concat(intake.priority === p ? form_module_scss_1.default.selected : ''), onClick: function () { return updateIntake({ priority: p }); } }, p)); }))),
        React.createElement("div", { className: form_module_scss_1.default.skillsSection },
            React.createElement("span", { className: form_module_scss_1.default.skillsLabel }, "Required Skills"),
            React.createElement("div", { className: form_module_scss_1.default.skillsChips }, SKILL_OPTIONS.map(function (skill) {
                var selected = intake.skills.indexOf(skill) >= 0;
                return (React.createElement("button", { key: skill, type: "button", className: "".concat(form_module_scss_1.default.skillChip, " ").concat(selected ? form_module_scss_1.default.selected : ''), onClick: function () { return toggleSkill(skill); } },
                    selected ? '✓' : '+',
                    " ",
                    skill));
            }))))); };
    var renderStaffRecommendation = function () {
        if (aiLoading) {
            return renderAiLoading('Recommended Staff Allocation Pod');
        }
        return (React.createElement(React.Fragment, null,
            React.createElement("h2", { className: form_module_scss_1.default.sectionTitle }, "Recommended Staff Allocation Pod"),
            React.createElement("p", { className: form_module_scss_1.default.sectionDesc }, "Continuous cognitive mapping analyzed load metrics, historical success and client contract alignment."),
            React.createElement("div", { className: form_module_scss_1.default.staffLayout },
                React.createElement("div", { className: form_module_scss_1.default.staffGrid }, recommendedStaff.map(function (member) { return (React.createElement("div", { key: member.initials, className: form_module_scss_1.default.staffCard },
                    React.createElement("div", { className: form_module_scss_1.default.staffCardTop },
                        React.createElement("span", { className: form_module_scss_1.default.roleBadge }, member.role),
                        React.createElement("span", { className: form_module_scss_1.default.matchScore },
                            "Match: ",
                            member.match,
                            "%")),
                    React.createElement("div", { className: form_module_scss_1.default.staffProfile },
                        React.createElement("div", { className: form_module_scss_1.default.avatar }, member.initials),
                        React.createElement("div", null,
                            React.createElement("p", { className: form_module_scss_1.default.staffName }, member.name),
                            React.createElement("p", { className: form_module_scss_1.default.staffDept }, member.department))),
                    React.createElement("div", { className: form_module_scss_1.default.staffStats },
                        React.createElement("span", null,
                            "Availability: ",
                            React.createElement("strong", null,
                                member.availability,
                                "%")),
                        React.createElement("span", null,
                            "Success: ",
                            React.createElement("strong", null,
                                member.success,
                                "%"))))); })),
                React.createElement("aside", { className: form_module_scss_1.default.cognitivePanel },
                    React.createElement("h3", { className: form_module_scss_1.default.cognitiveTitle }, "COGNITIVE OVERVIEW"),
                    React.createElement("div", { className: form_module_scss_1.default.cognitiveRow },
                        React.createElement("span", { className: form_module_scss_1.default.cognitiveLabel }, "AI Confidence Score"),
                        React.createElement("span", { className: form_module_scss_1.default.confidenceBox }, "96%")),
                    React.createElement("div", { className: form_module_scss_1.default.cognitiveRow },
                        React.createElement("span", { className: form_module_scss_1.default.cognitiveLabel }, "Estimated Budget"),
                        React.createElement("span", { className: form_module_scss_1.default.cognitiveValue }, intake.budget)),
                    React.createElement("div", { className: form_module_scss_1.default.cognitiveRow },
                        React.createElement("span", { className: form_module_scss_1.default.cognitiveLabel }, "Start Date"),
                        React.createElement("span", { className: form_module_scss_1.default.cognitiveValue }, intake.startDate)),
                    React.createElement("div", { className: form_module_scss_1.default.cognitiveRow },
                        React.createElement("span", { className: form_module_scss_1.default.cognitiveLabel }, "End Date"),
                        React.createElement("span", { className: form_module_scss_1.default.cognitiveValue }, intake.endDate)),
                    React.createElement("div", { className: form_module_scss_1.default.cognitiveRow },
                        React.createElement("span", { className: form_module_scss_1.default.cognitiveLabel }, "Delivery Risk Level"),
                        React.createElement("span", { className: form_module_scss_1.default.riskBadge }, "Low Risk")),
                    React.createElement("div", { className: form_module_scss_1.default.auditBox },
                        React.createElement("strong", null, "Audit notes:"),
                        "Azure AI Foundry mapped ",
                        skillsSummary,
                        " against pod suitability vectors. Priority tier ",
                        intake.priority,
                        " applied to allocation weighting.")))));
    };
    var renderProjectPlan = function () {
        var _a;
        if (aiLoading) {
            return renderAiLoading('Task Schedule & Agile Timeline');
        }
        // Group items by feature
        var groups = {};
        var groupCounter = 0;
        var orderedFeatures = [];
        planItems.forEach(function (item, index) {
            var feat = item.feature || 'General';
            if (orderedFeatures.indexOf(feat) === -1) {
                orderedFeatures.push(feat);
                groupCounter++;
                groups[feat] = {
                    items: [],
                    indices: [],
                    totalEfforts: 0,
                    groupNum: groupCounter
                };
            }
            groups[feat].items.push(item);
            groups[feat].indices.push(index);
            groups[feat].totalEfforts += item.efforts;
        });
        var monthSpans = getMonthSpans(timelineColumns);
        var renderChevronDown = function () { return (React.createElement("svg", { className: css.chevronIcon, width: "10", height: "10", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "3", strokeLinecap: "round", strokeLinejoin: "round" },
            React.createElement("polyline", { points: "6 9 12 15 18 9" }))); };
        var renderChevronRight = function () { return (React.createElement("svg", { className: css.chevronIcon, width: "10", height: "10", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "3", strokeLinecap: "round", strokeLinejoin: "round" },
            React.createElement("polyline", { points: "9 18 15 12 9 6" }))); };
        var renderFolderIcon = function () { return (React.createElement("svg", { className: css.folderIcon, width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round" },
            React.createElement("path", { d: "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" }))); };
        var totalEffort = planItems.reduce(function (sum, item) { return sum + item.efforts; }, 0);
        var uniqueAssignees = new Set(planItems.map(function (item) { return item.assignee; }).filter(Boolean));
        var dateRangeLabel = timelineColumns.length > 0
            ? "".concat(timelineColumns[0], " \u2013 ").concat(timelineColumns[timelineColumns.length - 1])
            : 'No dates';
        var timeMarkerSlot = 0;
        var completedCount = planItems.filter(function (item) { return item.status === 'Done'; }).length;
        var progressPct = planItems.length > 0 ? Math.round((completedCount / planItems.length) * 100) : 0;
        var zoomScale = planZoom / 100;
        return (React.createElement("div", { className: form_module_scss_1.default.planStudio },
            React.createElement("div", { className: form_module_scss_1.default.planPageHead },
                React.createElement("div", null,
                    React.createElement("h2", { className: form_module_scss_1.default.planPageTitle }, "Project Plan"),
                    React.createElement("p", { className: form_module_scss_1.default.planPageSubtitle },
                        intake.projectName,
                        " \u00B7 Cognitive timeline generated from intake and staff allocation"))),
            React.createElement("div", { className: form_module_scss_1.default.planKpiRow },
                React.createElement("div", { className: form_module_scss_1.default.planKpiCard },
                    React.createElement("span", { className: form_module_scss_1.default.planKpiIcon, "aria-hidden": "true" }, "\u23F1"),
                    React.createElement("div", null,
                        React.createElement("span", { className: form_module_scss_1.default.planKpiLabel }, "Total Effort"),
                        React.createElement("strong", { className: form_module_scss_1.default.planKpiValue },
                            totalEffort,
                            " hrs"))),
                React.createElement("div", { className: form_module_scss_1.default.planKpiCard },
                    React.createElement("span", { className: form_module_scss_1.default.planKpiIcon, "aria-hidden": "true" }, "\uD83D\uDCC5"),
                    React.createElement("div", null,
                        React.createElement("span", { className: form_module_scss_1.default.planKpiLabel }, "Estimated Duration"),
                        React.createElement("strong", { className: form_module_scss_1.default.planKpiValue },
                            timelineColumns.length,
                            " Days"))),
                React.createElement("div", { className: form_module_scss_1.default.planKpiCard },
                    React.createElement("span", { className: form_module_scss_1.default.planKpiIcon, "aria-hidden": "true" }, "\uD83D\uDC65"),
                    React.createElement("div", null,
                        React.createElement("span", { className: form_module_scss_1.default.planKpiLabel }, "Resources Allocated"),
                        React.createElement("strong", { className: form_module_scss_1.default.planKpiValue },
                            uniqueAssignees.size || 3,
                            " Members"))),
                React.createElement("div", { className: form_module_scss_1.default.planKpiCard },
                    React.createElement("span", { className: form_module_scss_1.default.planKpiIcon, "aria-hidden": "true" }, "\u25CE"),
                    React.createElement("div", null,
                        React.createElement("span", { className: form_module_scss_1.default.planKpiLabel }, "Progress"),
                        React.createElement("strong", { className: form_module_scss_1.default.planKpiValue },
                            progressPct,
                            "%")))),
            React.createElement("div", { className: form_module_scss_1.default.planToolbar },
                React.createElement("div", { className: form_module_scss_1.default.planToolbarLeft },
                    React.createElement("button", { type: "button", className: form_module_scss_1.default.planToolbarPrimary, onClick: handleAddPlanRow }, "+ Add Task"),
                    React.createElement("button", { type: "button", className: form_module_scss_1.default.planToolbarGhost, onClick: handleRegeneratePlan }, "AI Generate Plan"),
                    React.createElement("button", { type: "button", className: form_module_scss_1.default.planToolbarGhost, onClick: function () { var _a; return (_a = importFileRef.current) === null || _a === void 0 ? void 0 : _a.click(); } }, "Import Excel"),
                    React.createElement("button", { type: "button", className: form_module_scss_1.default.planToolbarGhost, onClick: handleExportProjectPlan }, "Export Excel")),
                React.createElement("div", { className: form_module_scss_1.default.planToolbarRight },
                    React.createElement("div", { className: form_module_scss_1.default.planZoomControl },
                        React.createElement("button", { type: "button", onClick: function () { return setPlanZoom(function (z) { return Math.max(70, z - 10); }); }, "aria-label": "Zoom out" }, "\u2212"),
                        React.createElement("span", null,
                            planZoom,
                            "%"),
                        React.createElement("button", { type: "button", onClick: function () { return setPlanZoom(function (z) { return Math.min(130, z + 10); }); }, "aria-label": "Zoom in" }, "+")),
                    React.createElement("span", { className: form_module_scss_1.default.planDateRange }, dateRangeLabel))),
            React.createElement("div", { className: form_module_scss_1.default.planWorkspace },
                React.createElement("div", { className: css.ganttWrap, style: (_a = {}, _a['--plan-zoom'] = zoomScale, _a) },
                    React.createElement("table", { className: css.ganttTable },
                        React.createElement("thead", null,
                            React.createElement("tr", { className: css.timelineMonthRow },
                                React.createElement("th", { rowSpan: 3, className: css.indexColHeader }, "#"),
                                React.createElement("th", { rowSpan: 3, className: css.featureColHeader }, "Feature"),
                                React.createElement("th", { rowSpan: 3, className: css.taskColHeader }, "Task"),
                                React.createElement("th", { rowSpan: 3, className: css.descColHeader }, "Description"),
                                React.createElement("th", { rowSpan: 3, className: css.typeColHeader }, "Type"),
                                React.createElement("th", { rowSpan: 3, className: css.dateColHeader }, "Start Date"),
                                React.createElement("th", { rowSpan: 3, className: css.dateColHeader }, "End Date"),
                                React.createElement("th", { rowSpan: 3, className: css.effortsColHeader }, "Effort (hrs)"),
                                React.createElement("th", { rowSpan: 3, className: css.assigneeColHeader }, "Assignee"),
                                React.createElement("th", { rowSpan: 3, className: css.statusColHeader }, "Status"),
                                React.createElement("th", { rowSpan: 3, className: css.actionsColHeader }, "Actions"),
                                monthSpans.map(function (m, index) { return (React.createElement("th", { key: "month-".concat(index), colSpan: m.span, className: css.timelineMonthCol }, m.label)); })),
                            React.createElement("tr", { className: css.timelineNumRow }, timelineColumns.map(function (column, index) {
                                var parts = column.split('-');
                                var dateNum = parts[0] || column;
                                var isActive = column === timelineColumns[0];
                                return (React.createElement("th", { key: "num-".concat(column, "-").concat(index), className: "".concat(css.timelineNumCol, " ").concat(isActive ? css.activeDate : '') }, dateNum));
                            })),
                            React.createElement("tr", { className: css.timelineDayRow }, timelineColumns.map(function (column, index) {
                                var isActive = column === timelineColumns[0];
                                return (React.createElement("th", { key: "day-".concat(column, "-").concat(index), className: "".concat(css.timelineDayCol, " ").concat(isActive ? css.activeDate : '') }, getWeekday(column)));
                            }))),
                        React.createElement("tbody", null,
                            orderedFeatures.map(function (feat) {
                                var group = groups[feat];
                                var isExpanded = expandedFeatures[feat] !== false;
                                return (React.createElement(React.Fragment, { key: "group-".concat(feat) },
                                    React.createElement("tr", { className: css.groupHeaderRow },
                                        React.createElement("td", { className: css.excelRowHeaderCell, onClick: function () { return toggleFeatureExpand(feat); } },
                                            React.createElement("span", { className: css.accordionTrigger }, isExpanded ? renderChevronDown() : renderChevronRight())),
                                        React.createElement("td", { className: css.groupFeatureNameCell },
                                            React.createElement("div", { className: css.groupFeatureWrapper },
                                                React.createElement("span", { className: css.folderIconWrapper }, renderFolderIcon()),
                                                React.createElement("input", { className: form_module_scss_1.default.groupFeatureInput, value: feat, onChange: function (e) { return handleGroupFeatureChange(feat, e.target.value); } }))),
                                        React.createElement("td", { className: css.groupEffortsSumCell, colSpan: 9 },
                                            React.createElement("span", { className: css.groupEffortsText },
                                                group.totalEfforts,
                                                " hrs")),
                                        timelineColumns.map(function (_, slot) { return (React.createElement("td", { key: "header-slot-".concat(slot), className: css.timelineCell })); })),
                                    isExpanded &&
                                        group.items.map(function (item, childIndex) {
                                            var origIndex = group.indices[childIndex];
                                            var childNum = "".concat(group.groupNum, ".").concat(childIndex + 1);
                                            return (React.createElement("tr", { key: "".concat(item.feature, "-").concat(item.task, "-").concat(origIndex), className: css.excelRow },
                                                React.createElement("td", { className: css.decimalNumCell }, childNum),
                                                React.createElement("td", { className: css.blankFeatureCell }),
                                                React.createElement("td", { className: css.excelTaskCell },
                                                    React.createElement("input", { className: form_module_scss_1.default.planInput, value: item.task, onChange: function (e) { return handlePlanChange(origIndex, 'task', e.target.value); } })),
                                                React.createElement("td", { className: css.excelDescCell },
                                                    React.createElement("textarea", { className: form_module_scss_1.default.planTextarea, value: item.description || '', onChange: function (e) { return handlePlanChange(origIndex, 'description', e.target.value); }, rows: 1 })),
                                                React.createElement("td", { className: css.typeBadgeCell },
                                                    React.createElement("select", { className: "".concat(css.badgeSelect, " ").concat(item.lane === 'development'
                                                            ? css.badgeDevelopment
                                                            : item.lane === 'testing'
                                                                ? css.badgeTesting
                                                                : css.badgeDeployment), value: item.lane, onChange: function (e) { return handlePlanChange(origIndex, 'lane', e.target.value); } },
                                                        React.createElement("option", { value: "development" }, "Development"),
                                                        React.createElement("option", { value: "testing" }, "Testing"),
                                                        React.createElement("option", { value: "demo" }, "Deployment"))),
                                                React.createElement("td", null,
                                                    React.createElement("select", { className: form_module_scss_1.default.planSelect, value: item.startDate, onChange: function (e) { return handlePlanChange(origIndex, 'startDate', e.target.value); } }, timelineColumns.map(function (column) { return (React.createElement("option", { key: "start-".concat(column), value: column }, column)); }))),
                                                React.createElement("td", null,
                                                    React.createElement("select", { className: form_module_scss_1.default.planSelect, value: item.endDate, onChange: function (e) { return handlePlanChange(origIndex, 'endDate', e.target.value); } }, timelineColumns.map(function (column) { return (React.createElement("option", { key: "end-".concat(column), value: column }, column)); }))),
                                                React.createElement("td", null,
                                                    React.createElement("input", { className: form_module_scss_1.default.planInputCompact, value: item.efforts, type: "number", min: 1, onChange: function (e) { return handlePlanChange(origIndex, 'efforts', Math.max(1, Number(e.target.value) || 1)); } })),
                                                React.createElement("td", { className: css.assigneeCell },
                                                    React.createElement("div", { className: form_module_scss_1.default.assigneeCellInner },
                                                        React.createElement("span", { className: form_module_scss_1.default.assigneeAvatar }, getAssigneeInitials(item.assignee, recommendedStaff)),
                                                        React.createElement("select", { className: form_module_scss_1.default.planSelectAssignee, value: item.assignee, onChange: function (e) { return handlePlanChange(origIndex, 'assignee', e.target.value); } }, recommendedStaff.map(function (member) { return (React.createElement("option", { key: member.name, value: member.name }, member.name)); })))),
                                                React.createElement("td", { className: css.statusCell },
                                                    React.createElement("select", { className: "".concat(form_module_scss_1.default.planStatusSelect, " ").concat(item.status === 'Done'
                                                            ? form_module_scss_1.default.statusDone
                                                            : item.status === 'In Progress'
                                                                ? form_module_scss_1.default.statusInProgress
                                                                : form_module_scss_1.default.statusNotStarted), value: item.status, onChange: function (e) { return handlePlanChange(origIndex, 'status', e.target.value); } }, PLAN_STATUSES.map(function (status) { return (React.createElement("option", { key: status, value: status }, status)); }))),
                                                React.createElement("td", { className: css.excelActionCell },
                                                    React.createElement("div", { className: css.actionsContainer },
                                                        React.createElement("span", { className: css.threeDots }, "\u22EE"),
                                                        React.createElement("button", { type: "button", className: form_module_scss_1.default.planDeleteBtn, onClick: function () { return handleDeletePlanRow(origIndex); } }, "Delete"))),
                                                timelineColumns.map(function (_, slot) {
                                                    var filled = slot >= item.startSlot && slot < item.startSlot + item.durationSlots;
                                                    var pillClass = '';
                                                    if (filled) {
                                                        if (item.durationSlots === 1) {
                                                            pillClass = css.timelinePillSingle;
                                                        }
                                                        else if (slot === item.startSlot) {
                                                            pillClass = css.timelinePillStart;
                                                        }
                                                        else if (slot === item.startSlot + item.durationSlots - 1) {
                                                            pillClass = css.timelinePillEnd;
                                                        }
                                                        else {
                                                            pillClass = css.timelinePillMiddle;
                                                        }
                                                    }
                                                    var laneColorClass = item.lane === 'development'
                                                        ? css.barDevelopment
                                                        : item.lane === 'testing'
                                                            ? css.barTesting
                                                            : css.barDeployment;
                                                    return (React.createElement("td", { key: "".concat(item.task, "-").concat(slot), className: "".concat(css.timelineCell, " ").concat(slot === timeMarkerSlot ? css.timeMarkerCol : '') },
                                                        slot === timeMarkerSlot && childIndex === 0 && (React.createElement("span", { className: css.timeMarkerLabel }, "TIME")),
                                                        filled && (React.createElement("div", { className: "".concat(css.timelinePill, " ").concat(pillClass, " ").concat(laneColorClass) }))));
                                                })));
                                        })));
                            }),
                            React.createElement("tr", { className: css.excelTotalRow },
                                React.createElement("td", { className: css.excelTotalLabel, colSpan: 7 }, "Total"),
                                React.createElement("td", { className: css.excelTotalValue },
                                    totalEffort,
                                    " hrs"),
                                React.createElement("td", { colSpan: 3 }),
                                React.createElement("td", { colSpan: timelineColumns.length }))))),
                React.createElement("aside", { className: form_module_scss_1.default.planSidebar },
                    React.createElement("section", { className: form_module_scss_1.default.planSidebarBlock },
                        React.createElement("h3", { className: form_module_scss_1.default.planSidebarTitle }, "AI Insights"),
                        React.createElement("ul", { className: form_module_scss_1.default.planInsightList },
                            React.createElement("li", null,
                                React.createElement("span", null, "Total Effort"),
                                React.createElement("strong", null,
                                    totalEffort,
                                    " hrs")),
                            React.createElement("li", null,
                                React.createElement("span", null, "Duration"),
                                React.createElement("strong", null,
                                    timelineColumns.length,
                                    " days")),
                            React.createElement("li", null,
                                React.createElement("span", null, "Resources"),
                                React.createElement("strong", null,
                                    uniqueAssignees.size,
                                    " members")),
                            React.createElement("li", null,
                                React.createElement("span", null, "Delivery Confidence"),
                                React.createElement("strong", { className: form_module_scss_1.default.planInsightGood }, "92%")),
                            React.createElement("li", null,
                                React.createElement("span", null, "Risk Level"),
                                React.createElement("strong", { className: form_module_scss_1.default.planInsightGood }, "Low")))),
                    React.createElement("section", { className: form_module_scss_1.default.planSidebarBlock },
                        React.createElement("h3", { className: form_module_scss_1.default.planSidebarTitle }, "AI Recommendations"),
                        React.createElement("p", { className: form_module_scss_1.default.planRecommendationText }, "Shift testing tasks 1 day earlier to protect the deployment window and reduce schedule risk."),
                        React.createElement("button", { type: "button", className: form_module_scss_1.default.planSuggestionBtn }, "Apply Suggestion")),
                    React.createElement("section", { className: form_module_scss_1.default.planSidebarBlock },
                        React.createElement("h3", { className: form_module_scss_1.default.planSidebarTitle }, "Legend"),
                        React.createElement("div", { className: form_module_scss_1.default.planSidebarLegend },
                            React.createElement("span", null,
                                React.createElement("i", { className: "".concat(css.legendSwatch, " ").concat(css.barDevelopment) }),
                                "Development"),
                            React.createElement("span", null,
                                React.createElement("i", { className: "".concat(css.legendSwatch, " ").concat(css.barTesting) }),
                                "Testing"),
                            React.createElement("span", null,
                                React.createElement("i", { className: "".concat(css.legendSwatch, " ").concat(css.barDeployment) }),
                                "Deployment")))))));
    };
    var renderApprovals = function () { return (React.createElement(React.Fragment, null,
        React.createElement("h2", { className: form_module_scss_1.default.sectionTitle }, "Manager Review & Project Authorization"),
        React.createElement("p", { className: form_module_scss_1.default.sectionDesc }, "Authorize active SLA, headcount parameters, and financial cost centers immediately."),
        React.createElement("div", { className: form_module_scss_1.default.approvalSummary },
            React.createElement("div", { className: form_module_scss_1.default.summaryLeft },
                React.createElement("div", { className: form_module_scss_1.default.summaryTag }, "PROJECT SPECIFICATIONS SUMMARY"),
                React.createElement("h3", { className: form_module_scss_1.default.summaryProjectTitle }, intake.projectName.toUpperCase()),
                React.createElement("p", { className: form_module_scss_1.default.summaryDesc },
                    "Enterprise portal connecting secure LLM engines with custom RAG filtering policies and high availability standards. Skills: ",
                    skillsSummary,
                    ".")),
            React.createElement("div", { className: form_module_scss_1.default.summaryRight },
                React.createElement("div", { className: form_module_scss_1.default.summaryRow },
                    React.createElement("span", { className: form_module_scss_1.default.summaryRowLabel }, "Client Contract Node"),
                    React.createElement("span", { className: form_module_scss_1.default.summaryRowValue }, intake.clientName)),
                React.createElement("div", { className: form_module_scss_1.default.summaryRow },
                    React.createElement("span", { className: form_module_scss_1.default.summaryRowLabel }, "Staff Allocated"),
                    React.createElement("span", { className: form_module_scss_1.default.summaryRowValue }, "6 members pod")),
                React.createElement("div", { className: form_module_scss_1.default.summaryRow },
                    React.createElement("span", { className: form_module_scss_1.default.summaryRowLabel }, "Est Expenditure SOW"),
                    React.createElement("span", { className: form_module_scss_1.default.summaryRowValue }, intake.budget)),
                React.createElement("div", { className: form_module_scss_1.default.summaryRow },
                    React.createElement("span", { className: form_module_scss_1.default.summaryRowLabel }, "Estimated Timeline"),
                    React.createElement("span", { className: form_module_scss_1.default.summaryRowValue },
                        intake.startDate,
                        " to ",
                        intake.endDate)),
                React.createElement("div", { className: form_module_scss_1.default.summaryRow },
                    React.createElement("span", { className: form_module_scss_1.default.summaryRowLabel }, "Priority"),
                    React.createElement("span", { className: form_module_scss_1.default.summaryRowValue }, intake.priority)))),
        React.createElement("label", { className: form_module_scss_1.default.label, htmlFor: "architectNotes" }, "Lead Architect SOW Notes (Optional)"),
        React.createElement("textarea", { id: "architectNotes", className: form_module_scss_1.default.textarea, placeholder: "Comment on allocation logic, constraints or priority overrides...", value: intake.architectNotes, onChange: function (e) { return updateIntake({ architectNotes: e.target.value }); } }))); };
    var renderSuccess = function () { return (React.createElement("div", { className: form_module_scss_1.default.successPanel },
        React.createElement("div", { className: form_module_scss_1.default.successHero, "aria-hidden": "true" },
            React.createElement("div", { className: form_module_scss_1.default.successHalo }),
            React.createElement("div", { className: form_module_scss_1.default.successIcon },
                React.createElement(SuccessCheckIcon, null))),
        React.createElement("h2", { className: form_module_scss_1.default.successTitle }, "Project Authorized Successfully!"),
        React.createElement("p", { className: form_module_scss_1.default.successDesc },
            React.createElement("strong", null, intake.projectName),
            " has been approved. Success nodes are now active in the Aegis Secure SDM platform."))); };
    var renderBody = function () {
        switch (step) {
            case 1:
                return renderSourceStep();
            case 2:
                return renderIntakeSpec();
            case 3:
                return renderStaffRecommendation();
            case 4:
                return renderProjectPlan();
            case 5:
                return renderApprovals();
            case 6:
                return renderSuccess();
            default:
                return renderIntakeSpec();
        }
    };
    var renderFooter = function () {
        if (step === 6) {
            return (React.createElement("div", { className: form_module_scss_1.default.footerSuccess },
                React.createElement("button", { type: "button", className: form_module_scss_1.default.btnDashboard, onClick: onClose },
                    React.createElement(ExternalLinkIcon, null),
                    "Go to Project Dashboard")));
        }
        if (step === 1) {
            return (React.createElement("div", { className: form_module_scss_1.default.footer },
                React.createElement("button", { type: "button", className: form_module_scss_1.default.btnBack, disabled: true },
                    React.createElement("span", { className: form_module_scss_1.default.btnText }, "BACK")),
                React.createElement("div", { className: form_module_scss_1.default.footerRight })));
        }
        if (step === 3 && aiLoading) {
            return (React.createElement("div", { className: form_module_scss_1.default.footer },
                React.createElement("button", { type: "button", className: form_module_scss_1.default.btnBack, disabled: true },
                    React.createElement("span", { className: form_module_scss_1.default.btnText }, "BACK")),
                React.createElement("button", { type: "button", className: form_module_scss_1.default.btnPrimary, disabled: true },
                    React.createElement("span", { className: form_module_scss_1.default.btnText }, "GENERATE PROJECT PLAN"))));
        }
        return (React.createElement("div", { className: form_module_scss_1.default.footer },
            React.createElement("button", { type: "button", className: form_module_scss_1.default.btnBack, onClick: handleBack, disabled: step <= 1 || aiLoading },
                React.createElement("span", { className: form_module_scss_1.default.btnText }, "BACK")),
            React.createElement("div", { className: form_module_scss_1.default.footerRight },
                step === 5 && (React.createElement("button", { type: "button", className: form_module_scss_1.default.btnReject, onClick: handleReject },
                    React.createElement("span", { className: form_module_scss_1.default.btnText }, "REJECT PROJECT"))),
                step === 2 && (React.createElement("button", { type: "button", className: form_module_scss_1.default.btnPrimary, onClick: handleContinueFromIntake },
                    React.createElement("span", { className: form_module_scss_1.default.btnText }, "CONTINUE"))),
                step === 3 && !aiLoading && (React.createElement("button", { type: "button", className: form_module_scss_1.default.btnPrimary, onClick: handleGeneratePlan },
                    React.createElement("span", { className: form_module_scss_1.default.btnText }, "GENERATE PROJECT PLAN"))),
                step === 4 && !aiLoading && (React.createElement("button", { type: "button", className: form_module_scss_1.default.btnPrimary, onClick: handleSendForApproval },
                    React.createElement("span", { className: form_module_scss_1.default.btnText }, "SEND FOR MANAGER APPROVAL"))),
                step === 5 && (React.createElement("button", { type: "button", className: form_module_scss_1.default.btnPrimary, onClick: handleApprove },
                    React.createElement("span", { className: form_module_scss_1.default.btnText }, "CONFIRM"))))));
    };
    return (React.createElement("div", { className: "".concat(form_module_scss_1.default.wizard, " ").concat(step === 4 ? form_module_scss_1.default.wizardPlan : '') },
        React.createElement("div", { className: form_module_scss_1.default.card },
            React.createElement("header", { className: form_module_scss_1.default.header },
                React.createElement("div", { className: form_module_scss_1.default.headerLeft },
                    React.createElement("div", { className: form_module_scss_1.default.logo },
                        React.createElement(ChipIcon, null)),
                    React.createElement("div", null,
                        React.createElement("h1", { className: form_module_scss_1.default.title }, "AI PROJECT INTAKE WIZARD"),
                        React.createElement("p", { className: form_module_scss_1.default.subtitle }, step === 6 ? 'Aegis Secure SDM Provisioning Platform' : 'Aegis Secure SOW Provisioning Platform'))),
                React.createElement("button", { type: "button", className: form_module_scss_1.default.closeBtn, "aria-label": "Close wizard", onClick: onClose }, "\u00D7")),
            renderStepper(),
            React.createElement("div", { className: "".concat(form_module_scss_1.default.body, " ").concat(step === 1 ? form_module_scss_1.default.bodySource : '') }, renderBody()),
            renderFooter())));
};
exports.default = ProjectIntakeForm;
//# sourceMappingURL=form.js.map