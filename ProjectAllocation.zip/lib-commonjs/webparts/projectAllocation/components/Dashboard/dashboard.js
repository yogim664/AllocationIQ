"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var dashboard_module_scss_1 = tslib_1.__importDefault(require("./dashboard.module.scss"));
var navbar_1 = tslib_1.__importDefault(require("../NavBar/navbar"));
var UserBadge_1 = tslib_1.__importDefault(require("../UserContext/UserBadge"));
var initservice_1 = require("../../../../service/initservice");
// ─── Constants ────────────────────────────────────────────────────────────────
var SAMPLE_PROJECTS = [
    {
        id: 'PRJ-2026-01',
        name: 'Project Orion Data Nexus',
        subtitle: 'Cloud architecture, infrastructure scale',
        startDate: 'Jan 15, 2026',
        endDate: 'Aug 30, 2026',
        budget: '$142,500',
        team: ['SJ', 'AK', 'TM'],
        teamExtra: 2
    },
    {
        id: 'PRJ-2026-02',
        name: 'Project Helios AI Optimizer',
        subtitle: 'Core telemetry and workflow analytics',
        startDate: 'Feb 01, 2026',
        endDate: 'Dec 15, 2026',
        budget: '$295,000',
        team: ['SM', 'RG', 'NP'],
        teamExtra: 3
    },
    {
        id: 'PRJ-2026-03',
        name: 'Project Aurora CoPilot',
        subtitle: 'Natural language interface extension',
        startDate: 'Mar 10, 2026',
        endDate: 'Oct 20, 2026',
        budget: '$88,000',
        team: ['CM', 'NL', 'HM'],
        teamExtra: 2
    }
];
var AVATAR_COLORS = ['#dbeafe', '#e0e7ff', '#fce7f3', '#d1fae5', '#fef3c7'];
var AVATAR_TEXT = ['#6d28d9', '#7c3aed', '#be185d', '#047857', '#b45309'];
// ─── Helpers ──────────────────────────────────────────────────────────────────
var getFieldValue = function (item, fieldName) {
    if (!item)
        return undefined;
    var lower = fieldName.toLowerCase();
    for (var _i = 0, _a = Object.keys(item); _i < _a.length; _i++) {
        var key = _a[_i];
        if (key.toLowerCase() === lower) {
            var val = item[key];
            if (val && typeof val === 'object') {
                if (val.LookupValue !== undefined)
                    return val.LookupValue;
                if (val.Title !== undefined)
                    return val.Title;
                if (val.Label !== undefined)
                    return val.Label;
            }
            return val;
        }
    }
    return undefined;
};
var formatDate = function (dateStr) {
    if (!dateStr)
        return '';
    try {
        var d = new Date(dateStr);
        if (isNaN(d.getTime()))
            return dateStr;
        return d.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    }
    catch (_a) {
        return dateStr;
    }
};
var getInitials = function (fullName) {
    if (!fullName)
        return '??';
    var parts = fullName.trim().split(/\s+/);
    if (parts.length === 1)
        return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
};
var parseBudget = function (val) {
    if (typeof val === 'number')
        return isNaN(val) ? 0 : val;
    if (typeof val === 'string') {
        var cleaned = val.replace(/[^0-9.-]+/g, '');
        var n = parseFloat(cleaned);
        return isNaN(n) ? 0 : n;
    }
    return 0;
};
// ─── Component ────────────────────────────────────────────────────────────────
var Dashboard = function (_a) {
    var onCreateProject = _a.onCreateProject, onOpenProject = _a.onOpenProject, onNavigate = _a.onNavigate;
    var css = dashboard_module_scss_1.default;
    // All hooks must be at the top of the component
    var _b = React.useState([]), projects = _b[0], setProjects = _b[1];
    var _c = React.useState(true), loading = _c[0], setLoading = _c[1];
    // Decide which list to render — SP data when available, otherwise sample data
    var projectsToRender = projects.length > 0 ? projects : SAMPLE_PROJECTS;
    // ── Derived stats ──────────────────────────────────────────────────────────
    var totalBudget = React.useMemo(function () { return projectsToRender.reduce(function (sum, p) { return sum + parseBudget(p.budget); }, 0); }, [projectsToRender]);
    var avgDurationMonths = React.useMemo(function () {
        var totalMonths = 0;
        var valid = 0;
        projectsToRender.forEach(function (p) {
            var start = new Date(p.startDate);
            var end = new Date(p.endDate);
            if (!isNaN(start.getTime()) && !isNaN(end.getTime())) {
                totalMonths += Math.abs(end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24 * 30.4);
                valid++;
            }
        });
        return valid > 0 ? (totalMonths / valid).toFixed(1) : '0';
    }, [projectsToRender]);
    // ── Fetch from SharePoint ──────────────────────────────────────────────────
    var fetchProjects = React.useCallback(function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, spItems, participations_1, _a, mapped, error_1;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 6, 7, 8]);
                    setLoading(true);
                    sp = (0, initservice_1.getSP)();
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle('Project')
                            .items
                            .select('Id', 'ProjectCode', 'ProjectName', 'Client', 'StartDate', 'EndDate', 'Budget', 'RequiredSkills', 'Description')
                            .top(5000)()];
                case 1:
                    spItems = _b.sent();
                    participations_1 = [];
                    _b.label = 2;
                case 2:
                    _b.trys.push([2, 4, , 5]);
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle('ProjectParticipation')
                            .items
                            .select('field_2', 'field_3')
                            .top(5000)()];
                case 3:
                    participations_1 = _b.sent();
                    return [3 /*break*/, 5];
                case 4:
                    _a = _b.sent();
                    return [3 /*break*/, 5];
                case 5:
                    mapped = spItems.map(function (item) {
                        var projectCode = getFieldValue(item, 'ProjectCode') || '';
                        var budgetVal = getFieldValue(item, 'Budget');
                        var budgetNum = parseBudget(budgetVal);
                        var budgetStr = "$".concat(budgetNum.toLocaleString());
                        var nameVal = getFieldValue(item, 'ProjectName') || 'Untitled Project';
                        var descVal = getFieldValue(item, 'Description') || getFieldValue(item, 'Client') || '';
                        var startVal = getFieldValue(item, 'StartDate') || '';
                        var endVal = getFieldValue(item, 'EndDate') || '';
                        var spId = getFieldValue(item, 'Id') || '';
                        // Collect team members for this project
                        var members = participations_1
                            .filter(function (p) { return p.field_3 === projectCode && p.field_2; })
                            .map(function (p) { return String(p.field_2); });
                        var visibleTeam = members.slice(0, 3).map(getInitials);
                        var extraCount = Math.max(0, members.length - 3);
                        return {
                            id: projectCode || "PRJ-".concat(spId),
                            name: nameVal,
                            subtitle: descVal,
                            startDate: formatDate(startVal),
                            endDate: formatDate(endVal),
                            budget: budgetStr,
                            team: visibleTeam,
                            teamExtra: extraCount
                        };
                    });
                    setProjects(mapped);
                    return [3 /*break*/, 8];
                case 6:
                    error_1 = _b.sent();
                    console.error('Dashboard: Error fetching projects from SharePoint:', error_1);
                    return [3 /*break*/, 8];
                case 7:
                    setLoading(false);
                    return [7 /*endfinally*/];
                case 8: return [2 /*return*/];
            }
        });
    }); }, []);
    React.useEffect(function () {
        fetchProjects().catch(console.error);
    }, [fetchProjects]);
    // ── Render ─────────────────────────────────────────────────────────────────
    return (React.createElement("div", { className: css.page },
        React.createElement("div", { className: css.pageMesh, "aria-hidden": "true" }),
        React.createElement("div", { className: css.pageOrb, "aria-hidden": "true" }),
        React.createElement("div", { className: css.pageOrb2, "aria-hidden": "true" }),
        React.createElement(navbar_1.default, { activeItem: "dashboard", onNavigate: onNavigate }),
        React.createElement("main", { className: css.main },
            React.createElement("header", { className: css.topBar },
                React.createElement("div", { className: css.topBarLeft },
                    React.createElement("h2", { className: css.workspaceTitle }, "Project Workspace"),
                    React.createElement("span", { className: css.enterpriseBadge }, "Enterprise")),
                React.createElement(UserBadge_1.default, { classNames: {
                        userBadge: css.userBadge,
                        userText: css.userText,
                        userName: css.userName,
                        userMail: css.userMail,
                        userAvatar: css.userAvatar
                    } })),
            React.createElement("section", { className: css.statsRow, "aria-label": "Workspace summary" },
                React.createElement("article", { className: "".concat(css.statCard, " ").concat(css.statProjects) },
                    React.createElement("div", { className: css.statCardHead },
                        React.createElement("p", { className: css.statLabel }, "Active Projects"),
                        React.createElement("span", { className: css.statIcon, "aria-hidden": "true" }, "\u25C6")),
                    React.createElement("p", { className: css.statValue }, projectsToRender.length),
                    React.createElement("span", { className: css.statTrend }, "All on track")),
                React.createElement("article", { className: "".concat(css.statCard, " ").concat(css.statBudget) },
                    React.createElement("div", { className: css.statCardHead },
                        React.createElement("p", { className: css.statLabel }, "Total Budget"),
                        React.createElement("span", { className: css.statIcon, "aria-hidden": "true" }, "$")),
                    React.createElement("p", { className: css.statValue },
                        "$",
                        (totalBudget / 1000).toFixed(1),
                        "K"),
                    React.createElement("span", { className: css.statTrend }, "FY26 allocated")),
                React.createElement("article", { className: "".concat(css.statCard, " ").concat(css.statDuration) },
                    React.createElement("div", { className: css.statCardHead },
                        React.createElement("p", { className: css.statLabel }, "Avg. Duration"),
                        React.createElement("span", { className: css.statIcon, "aria-hidden": "true" }, "\u23F1")),
                    React.createElement("p", { className: css.statValue },
                        avgDurationMonths,
                        " mo"),
                    React.createElement("span", { className: css.statTrend }, "Across pipeline"))),
            React.createElement("section", { className: css.card },
                React.createElement("div", { className: css.cardGlow, "aria-hidden": "true" }),
                React.createElement("div", { className: css.cardInner },
                    React.createElement("div", { className: css.cardHead },
                        React.createElement("div", { className: css.cardHeadText },
                            React.createElement("span", { className: css.cardKicker }, "Pipeline"),
                            React.createElement("h3", null, "Active Initiatives"),
                            React.createElement("p", null, "Overview of current pipeline scope, schedules, and financial allocations.")),
                        React.createElement("button", { type: "button", className: css.createBtn, onClick: onCreateProject },
                            React.createElement("span", { className: css.createBtnIcon, "aria-hidden": "true" }, "+"),
                            "Create Project")),
                    loading ? (React.createElement("div", { className: css.loadingWrap, "aria-live": "polite" },
                        React.createElement("div", { className: css.spinner }),
                        React.createElement("span", null, "Loading projects\u2026"))) : (React.createElement("div", { className: css.tableWrap },
                        React.createElement("table", { className: css.table },
                            React.createElement("thead", null,
                                React.createElement("tr", null,
                                    React.createElement("th", null, "Project ID"),
                                    React.createElement("th", null, "Project Name"),
                                    React.createElement("th", null, "Start Date"),
                                    React.createElement("th", null, "End Date"),
                                    React.createElement("th", { className: css.budgetCol }, "Budgeted Amount"),
                                    React.createElement("th", { className: css.teamCol }, "Team Members"),
                                    React.createElement("th", { className: css.colAction, "aria-hidden": "true" }))),
                            React.createElement("tbody", null, projectsToRender.map(function (project) { return (React.createElement("tr", { key: project.id, className: css.projectRow, onClick: function () { return onOpenProject(project); }, onKeyDown: function (e) {
                                    if (e.key === 'Enter' || e.key === ' ') {
                                        e.preventDefault();
                                        onOpenProject(project);
                                    }
                                }, tabIndex: 0, role: "button", "aria-label": "Open ".concat(project.name) },
                                React.createElement("td", { className: css.idCell },
                                    React.createElement("span", { className: css.idPill }, project.id)),
                                React.createElement("td", { className: css.nameCell },
                                    React.createElement("strong", null, project.name),
                                    React.createElement("span", null, project.subtitle)),
                                React.createElement("td", { className: css.dateCell }, project.startDate),
                                React.createElement("td", { className: css.dateCell }, project.endDate),
                                React.createElement("td", { className: "".concat(css.amountCell, " ").concat(css.budgetCol) },
                                    React.createElement("span", { className: css.amountVal }, project.budget),
                                    React.createElement("small", null, "USD")),
                                React.createElement("td", { className: css.teamCol },
                                    React.createElement("div", { className: css.teamRow }, (project.team || []).length === 0 ? (React.createElement("span", { className: css.teamEmpty }, "No team")) : (React.createElement(React.Fragment, null,
                                        (project.team || []).map(function (initials, i) { return (React.createElement("span", { key: "".concat(initials, "-").concat(i), className: css.teamChip, style: {
                                                background: AVATAR_COLORS[i % AVATAR_COLORS.length],
                                                color: AVATAR_TEXT[i % AVATAR_TEXT.length],
                                                zIndex: (project.team || []).length - i
                                            } }, initials)); }),
                                        project.teamExtra > 0 && (React.createElement("span", { className: css.teamMore },
                                            "+",
                                            project.teamExtra)))))),
                                React.createElement("td", { className: css.colAction },
                                    React.createElement("span", { className: css.rowChevron, "aria-hidden": "true" },
                                        React.createElement("svg", { viewBox: "0 0 24 24" },
                                            React.createElement("path", { d: "M9 6l6 6-6 6", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", fill: "none" })))))); }))))),
                    React.createElement("div", { className: css.cardFoot },
                        React.createElement("span", null,
                            "Showing ",
                            React.createElement("strong", null, projectsToRender.length),
                            " of",
                            ' ',
                            React.createElement("strong", null, projectsToRender.length),
                            " projects"),
                        React.createElement("span", { className: css.pipelineHint },
                            "Pipeline value \u00B7 $",
                            totalBudget.toLocaleString(),
                            " USD")))))));
};
exports.default = Dashboard;
//# sourceMappingURL=dashboard.js.map