"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IProjectAllocationProps.js.map