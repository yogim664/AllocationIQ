"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var approvals_module_scss_1 = tslib_1.__importDefault(require("./approvals.module.scss"));
var navbar_1 = tslib_1.__importDefault(require("../NavBar/navbar"));
var UserBadge_1 = tslib_1.__importDefault(require("../UserContext/UserBadge"));
var initservice_1 = require("../../../../service/initservice");
// ─── SharePoint helpers ──────────────────────────────────────────────────────
var getFieldValue = function (item, fieldName) {
    if (!item)
        return undefined;
    var lower = fieldName.toLowerCase();
    for (var _i = 0, _a = Object.keys(item); _i < _a.length; _i++) {
        var key = _a[_i];
        if (key.toLowerCase() === lower) {
            var val = item[key];
            if (val && typeof val === 'object') {
                if (val.LookupValue !== undefined)
                    return val.LookupValue;
                if (val.Title !== undefined)
                    return val.Title;
                if (val.Label !== undefined)
                    return val.Label;
            }
            return val;
        }
    }
    return undefined;
};
var getManagerApprovedValue = function (item) {
    var _a, _b, _c;
    var raw = (_c = (_b = (_a = item.isManagerApproved) !== null && _a !== void 0 ? _a : item.IsManagerApproved) !== null && _b !== void 0 ? _b : getFieldValue(item, 'isManagerApproved')) !== null && _c !== void 0 ? _c : getFieldValue(item, 'IsManagerApproved');
    if (raw === true || raw === 1 || raw === '1' || raw === 'true' || raw === 'Yes')
        return true;
    if (raw === false || raw === 0 || raw === '0' || raw === 'false' || raw === 'No')
        return false;
    return null;
};
/** Only items where isManagerApproved is explicitly false */
var isManagerApprovedFalse = function (item) {
    return getManagerApprovedValue(item) === false;
};
var projectCodesMatch = function (a, b) {
    return (a || '').trim().toLowerCase() === (b || '').trim().toLowerCase();
};
var escapeODataString = function (value) {
    return value.replace(/'/g, "''");
};
var PARTICIPATION_SELECT = [
    'Id', 'field_1', 'field_2', 'field_3', 'field_4', 'field_5', 'field_6', 'field_7'
];
var readTextField = function (item) {
    var _a, _b, _c, _d;
    var names = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        names[_i - 1] = arguments[_i];
    }
    for (var _e = 0, names_1 = names; _e < names_1.length; _e++) {
        var name_1 = names_1[_e];
        var val = (_a = getFieldValue(item, name_1)) !== null && _a !== void 0 ? _a : item[name_1];
        if (val == null || val === '')
            continue;
        if (typeof val === 'object') {
            var text = (_d = (_c = (_b = val.LookupValue) !== null && _b !== void 0 ? _b : val.Title) !== null && _c !== void 0 ? _c : val.Label) !== null && _d !== void 0 ? _d : val.value;
            if (text != null && text !== '')
                return String(text).trim();
        }
        else {
            return String(val).trim();
        }
    }
    return '';
};
var getParticipationProjectCode = function (item) {
    return readTextField(item, 'field_3', 'ProjectCode', 'projectcode');
};
var getParticipationName = function (item) {
    return readTextField(item, 'field_2', 'FullName', 'Title');
};
var formatDate = function (dateStr) {
    if (!dateStr)
        return '';
    try {
        var d = new Date(dateStr);
        if (isNaN(d.getTime()))
            return dateStr;
        return d.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    }
    catch (_a) {
        return dateStr;
    }
};
var getInitials = function (fullName) {
    if (!fullName)
        return '??';
    var parts = fullName.trim().split(/\s+/);
    if (parts.length === 1)
        return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
};
var normaliseLane = function (raw) {
    var lane = (raw || '').toLowerCase();
    if (lane === 'testing')
        return 'testing';
    if (lane === 'demo')
        return 'demo';
    return 'development';
};
var normalisePlanStatus = function (raw) {
    var s = (raw || '').toLowerCase();
    if (s === 'in progress' || s === 'in_progress')
        return 'In Progress';
    if (s === 'done' || s === 'completed')
        return 'Done';
    return 'Not Started';
};
var mapParticipationToStaff = function (item) {
    var name = getParticipationName(item);
    var availability = parseInt(readTextField(item, 'field_5', 'ContributionPercent') || '75', 10) || 75;
    var role = (readTextField(item, 'field_4', 'RoleInProject') || 'TEAM MEMBER').toUpperCase();
    return {
        initials: getInitials(name),
        name: name,
        role: role,
        department: 'Project Team',
        match: Math.min(99, availability + 10),
        availability: availability,
        success: 90
    };
};
var mapTaskToPlanItem = function (t, idx) { return ({
    slNo: parseInt(String(getFieldValue(t, 'Sno') || idx + 1), 10) || idx + 1,
    feature: (getFieldValue(t, 'lane') || 'General').toString(),
    task: (getFieldValue(t, 'Task') || "Task ".concat(idx + 1)).toString(),
    startDate: formatDate(getFieldValue(t, 'StartDate') || ''),
    endDate: formatDate(getFieldValue(t, 'EndDate') || ''),
    efforts: parseInt(String(getFieldValue(t, 'Effort') || '0'), 10) || 0,
    lane: normaliseLane(getFieldValue(t, 'lane') || ''),
    assignee: (getFieldValue(t, 'Assignee') || 'Unassigned').toString(),
    status: normalisePlanStatus(getFieldValue(t, 'Status') || '')
}); };
var filterParticipationByProject = function (items, projectCode) {
    return items
        .filter(function (p) { return projectCodesMatch(getParticipationProjectCode(p), projectCode); })
        .filter(function (p) { return getParticipationName(p); })
        .map(mapParticipationToStaff);
};
var fetchStaffForProject = function (projectCode) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    var code, sp, escaped, byField3, err_1, allItems, matched, error_1;
    var _a, _b;
    return tslib_1.__generator(this, function (_c) {
        switch (_c.label) {
            case 0:
                code = (projectCode || '').trim();
                if (!code)
                    return [2 /*return*/, []];
                sp = (0, initservice_1.getSP)();
                escaped = escapeODataString(code);
                _c.label = 1;
            case 1:
                _c.trys.push([1, 3, , 4]);
                return [4 /*yield*/, (_a = sp.web.lists
                        .getByTitle('ProjectParticipation')
                        .items)
                        .select.apply(_a, PARTICIPATION_SELECT).filter("field_3 eq '".concat(escaped, "'"))
                        .top(500)()];
            case 2:
                byField3 = _c.sent();
                if (byField3.length > 0) {
                    return [2 /*return*/, filterParticipationByProject(byField3, code)];
                }
                return [3 /*break*/, 4];
            case 3:
                err_1 = _c.sent();
                console.warn('[fetchStaffForProject] field_3 OData filter failed:', err_1);
                return [3 /*break*/, 4];
            case 4:
                _c.trys.push([4, 6, , 7]);
                return [4 /*yield*/, (_b = sp.web.lists
                        .getByTitle('ProjectParticipation')
                        .items)
                        .select.apply(_b, PARTICIPATION_SELECT).top(5000)()];
            case 5:
                allItems = _c.sent();
                matched = filterParticipationByProject(allItems, code);
                if (matched.length === 0 && allItems.length > 0) {
                    console.warn('[fetchStaffForProject] No match for project code:', code, 'Available codes:', allItems.map(function (p) { return getParticipationProjectCode(p); }).filter(Boolean));
                }
                return [2 /*return*/, matched];
            case 6:
                error_1 = _c.sent();
                console.error('[fetchStaffForProject] Failed to load ProjectParticipation:', error_1);
                return [2 /*return*/, []];
            case 7: return [2 /*return*/];
        }
    });
}); };
var fetchPlanItemsForProject = function (projectCode) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    var sp, taskFields, escaped, items, _a;
    var _b, _c;
    return tslib_1.__generator(this, function (_d) {
        switch (_d.label) {
            case 0:
                if (!projectCode)
                    return [2 /*return*/, []];
                sp = (0, initservice_1.getSP)();
                taskFields = ['Task', 'Sno', 'ProjectCode', 'Assignee', 'lane', 'Effort', 'Status', 'StartDate', 'EndDate'];
                escaped = escapeODataString(projectCode);
                items = [];
                _d.label = 1;
            case 1:
                _d.trys.push([1, 3, , 5]);
                return [4 /*yield*/, (_b = sp.web.lists
                        .getByTitle('TaskDetails')
                        .items)
                        .select.apply(_b, taskFields).filter("ProjectCode eq '".concat(escaped, "'"))
                        .top(5000)()];
            case 2:
                items = _d.sent();
                return [3 /*break*/, 5];
            case 3:
                _a = _d.sent();
                return [4 /*yield*/, (_c = sp.web.lists
                        .getByTitle('TaskDetails')
                        .items)
                        .select.apply(_c, taskFields).top(5000)()];
            case 4:
                items = _d.sent();
                items = items.filter(function (t) { return projectCodesMatch(String(getFieldValue(t, 'ProjectCode') || ''), projectCode); });
                return [3 /*break*/, 5];
            case 5: return [2 /*return*/, items
                    .map(function (t, idx) { return mapTaskToPlanItem(t, idx); })
                    .sort(function (a, b) { return a.slNo - b.slNo; })];
        }
    });
}); };
var parseBudget = function (val) {
    if (typeof val === 'number')
        return isNaN(val) ? 0 : val;
    if (typeof val === 'string') {
        var cleaned = val.replace(/[^0-9.-]+/g, '');
        var n = parseFloat(cleaned);
        return isNaN(n) ? 0 : n;
    }
    return 0;
};
var normalisePriority = function (raw) {
    var p = (raw || 'Medium').toLowerCase();
    if (p === 'low')
        return 'Low';
    if (p === 'high')
        return 'High';
    if (p === 'critical')
        return 'Critical';
    return 'Medium';
};
// ─── Small icons ─────────────────────────────────────────────────────────────
var ClipboardCheckIcon = function () { return (React.createElement("svg", { width: "22", height: "22", viewBox: "0 0 24 24", fill: "none", "aria-hidden": "true" },
    React.createElement("path", { d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2", stroke: "white", strokeWidth: "1.5", strokeLinecap: "round" }),
    React.createElement("rect", { x: "9", y: "3", width: "6", height: "4", rx: "1", stroke: "white", strokeWidth: "1.5" }),
    React.createElement("path", { d: "M9 12l2 2 4-4", stroke: "white", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round" }))); };
var CheckSvgIcon = function () { return (React.createElement("svg", { width: "40", height: "40", viewBox: "0 0 40 40", fill: "none", "aria-hidden": "true" },
    React.createElement("path", { d: "M10 20l8 8 14-14", stroke: "#fff", strokeWidth: "3.2", strokeLinecap: "round", strokeLinejoin: "round" }))); };
var ChevronRightIcon = function () { return (React.createElement("svg", { width: "14", height: "14", viewBox: "0 0 14 14", fill: "none", "aria-hidden": "true" },
    React.createElement("path", { d: "M5 3l4 4-4 4", stroke: "currentColor", strokeWidth: "1.8", strokeLinecap: "round", strokeLinejoin: "round" }))); };
var STEPS = ['PROJECT REVIEW', 'PLAN REVIEW'];
var ReviewDialog = function (_a) {
    var project = _a.project, onClose = _a.onClose, onApprove = _a.onApprove, onReject = _a.onReject;
    var css = approvals_module_scss_1.default;
    var _b = React.useState(1), step = _b[0], setStep = _b[1];
    var _c = React.useState([]), staff = _c[0], setStaff = _c[1];
    var _d = React.useState([]), planItems = _d[0], setPlanItems = _d[1];
    var _e = React.useState(true), detailLoading = _e[0], setDetailLoading = _e[1];
    var _f = React.useState(false), approving = _f[0], setApproving = _f[1];
    var _g = React.useState(null), approveError = _g[0], setApproveError = _g[1];
    React.useEffect(function () {
        var cancelled = false;
        setStep(1);
        setDetailLoading(true);
        setStaff([]);
        setPlanItems([]);
        void Promise.all([
            fetchStaffForProject(project.id),
            fetchPlanItemsForProject(project.id)
        ])
            .then(function (_a) {
            var staffData = _a[0], planData = _a[1];
            if (!cancelled) {
                setStaff(staffData);
                setPlanItems(planData);
            }
        })
            .catch(function (err) {
            console.error('[ReviewDialog] Failed to load project details:', err);
        })
            .then(function () {
            if (!cancelled)
                setDetailLoading(false);
        });
        return function () { cancelled = true; };
    }, [project.id]);
    var initials = function (name) {
        return name.split(' ').map(function (p) { return p[0]; }).join('').slice(0, 2).toUpperCase();
    };
    var getLaneCls = function (lane) {
        if (lane === 'testing')
            return approvals_module_scss_1.default.testing;
        if (lane === 'demo')
            return approvals_module_scss_1.default.demo;
        return approvals_module_scss_1.default.dev;
    };
    var getStatusCls = function (status) {
        if (status === 'In Progress')
            return approvals_module_scss_1.default.inProgress;
        if (status === 'Done')
            return approvals_module_scss_1.default.done;
        return approvals_module_scss_1.default.notStarted;
    };
    var totalEfforts = planItems.reduce(function (s, i) { return s + i.efforts; }, 0);
    var uniqueFeatures = planItems.reduce(function (acc, i) {
        if (acc.indexOf(i.feature) === -1)
            acc.push(i.feature);
        return acc;
    }, []).length;
    var priorityClass = function () {
        var p = project.priority.toLowerCase();
        if (p === 'high')
            return approvals_module_scss_1.default.high;
        if (p === 'medium')
            return approvals_module_scss_1.default.medium;
        if (p === 'low')
            return approvals_module_scss_1.default.low;
        return approvals_module_scss_1.default.critical;
    };
    var handleApprove = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    setApproving(true);
                    setApproveError(null);
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, 4, 5]);
                    return [4 /*yield*/, onApprove()];
                case 2:
                    _a.sent();
                    setStep(3);
                    window.setTimeout(function () { return onClose(); }, 2200);
                    return [3 /*break*/, 5];
                case 3:
                    error_2 = _a.sent();
                    console.error('[ReviewDialog] Failed to approve project:', error_2);
                    setApproveError('Could not update isManagerApproved. Please try again.');
                    return [3 /*break*/, 5];
                case 4:
                    setApproving(false);
                    return [7 /*endfinally*/];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    return (React.createElement("div", { className: approvals_module_scss_1.default.overlay, onClick: function (e) { if (e.target === e.currentTarget)
            onClose(); } },
        React.createElement("div", { className: approvals_module_scss_1.default.dialog, role: "dialog", "aria-modal": "true", "aria-label": "Project approval review" },
            React.createElement("div", { className: approvals_module_scss_1.default.dialogHeader },
                React.createElement("div", { className: approvals_module_scss_1.default.dialogHeaderLeft },
                    React.createElement("div", { className: approvals_module_scss_1.default.dialogLogo },
                        React.createElement(ClipboardCheckIcon, null)),
                    React.createElement("div", null,
                        React.createElement("h2", { className: approvals_module_scss_1.default.dialogTitle }, "APPROVAL REVIEW WIZARD"),
                        React.createElement("p", { className: approvals_module_scss_1.default.dialogSubtitle },
                            project.id,
                            " \u00B7 Aegis Secure SDM Authorization"))),
                React.createElement("button", { type: "button", className: approvals_module_scss_1.default.dialogClose, "aria-label": "Close", onClick: onClose }, "\u00D7")),
            step < 3 && (React.createElement("div", { className: approvals_module_scss_1.default.stepper }, STEPS.map(function (label, idx) {
                var stepNum = idx + 1;
                var isActive = stepNum === step;
                var isDone = stepNum < step;
                var isLast = idx === STEPS.length - 1;
                return (React.createElement("div", { key: label, className: approvals_module_scss_1.default.stepItem },
                    !isLast && (React.createElement("div", { className: "".concat(approvals_module_scss_1.default.stepConnector, " ").concat(isDone ? approvals_module_scss_1.default.connectorDone : (isActive ? approvals_module_scss_1.default.connectorToActive : '')) })),
                    React.createElement("div", { className: "".concat(approvals_module_scss_1.default.stepCircle, " ").concat(isActive ? approvals_module_scss_1.default.active : '', " ").concat(isDone ? approvals_module_scss_1.default.done : '') }, isDone ? '✓' : stepNum),
                    React.createElement("span", { className: "".concat(approvals_module_scss_1.default.stepLabel, " ").concat(isActive ? approvals_module_scss_1.default.active : '', " ").concat(isDone ? approvals_module_scss_1.default.done : '') }, label)));
            }))),
            React.createElement("div", { className: approvals_module_scss_1.default.dialogBody },
                step === 1 && (React.createElement(React.Fragment, null,
                    React.createElement("div", { className: approvals_module_scss_1.default.reviewGrid },
                        React.createElement("div", { className: approvals_module_scss_1.default.reviewSection },
                            React.createElement("h3", { className: approvals_module_scss_1.default.reviewSectionTitle },
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewSectionIcon }, "\uD83D\uDCCB"),
                                "Project Details"),
                            React.createElement("div", { className: approvals_module_scss_1.default.reviewField },
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldLabel }, "Project Name"),
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldValue }, project.name)),
                            React.createElement("div", { className: approvals_module_scss_1.default.reviewField },
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldLabel }, "Client"),
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldValue }, project.client)),
                            React.createElement("div", { className: approvals_module_scss_1.default.reviewField },
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldLabel }, "Budget"),
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldValue }, project.budget)),
                            React.createElement("div", { className: approvals_module_scss_1.default.reviewField },
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldLabel }, "Timeline"),
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldValue },
                                    project.startDate,
                                    " \u2192 ",
                                    project.endDate)),
                            React.createElement("div", { className: approvals_module_scss_1.default.reviewField },
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldLabel }, "Priority"),
                                React.createElement("span", { className: "".concat(approvals_module_scss_1.default.priorityTag, " ").concat(priorityClass()) }, project.priority)),
                            React.createElement("div", { className: approvals_module_scss_1.default.reviewField },
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldLabel }, "Required Skills"),
                                React.createElement("div", { className: approvals_module_scss_1.default.skillsWrap }, project.skills.map(function (s) { return (React.createElement("span", { key: s, className: approvals_module_scss_1.default.skillTag }, s)); })))),
                        React.createElement("div", { className: approvals_module_scss_1.default.reviewSection },
                            React.createElement("h3", { className: approvals_module_scss_1.default.reviewSectionTitle },
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewSectionIcon }, "\uD83D\uDCCA"),
                                "Project Summary"),
                            React.createElement("div", { className: approvals_module_scss_1.default.reviewField },
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldLabel }, "Scope"),
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldValue }, project.subtitle)),
                            React.createElement("div", { className: approvals_module_scss_1.default.reviewField },
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldLabel }, "Project ID"),
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldValue }, project.id)),
                            React.createElement("div", { className: approvals_module_scss_1.default.reviewField },
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldLabel }, "Team Size"),
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldValue }, detailLoading ? '…' : "".concat(staff.length, " members"))),
                            React.createElement("div", { className: approvals_module_scss_1.default.reviewField },
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldLabel }, "Plan Tasks"),
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldValue }, detailLoading
                                    ? '…'
                                    : "".concat(planItems.length, " tasks across ").concat(uniqueFeatures, " features"))),
                            React.createElement("div", { className: approvals_module_scss_1.default.reviewField },
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldLabel }, "Total Effort"),
                                React.createElement("span", { className: approvals_module_scss_1.default.reviewFieldValue },
                                    totalEfforts,
                                    " hours")))),
                    React.createElement("h3", { className: approvals_module_scss_1.default.reviewSectionTitle, style: { margin: '0 0 14px' } },
                        React.createElement("span", { className: approvals_module_scss_1.default.reviewSectionIcon }, "\uD83D\uDC65"),
                        "Recommended Staff Allocation Pod"),
                    detailLoading ? (React.createElement("div", { className: css.staffLoading },
                        "Loading staff for ",
                        project.id,
                        "\u2026")) : staff.length === 0 ? (React.createElement("div", { className: css.staffEmpty },
                        "No staff found in ",
                        React.createElement("strong", null, "ProjectParticipation"),
                        " for project code ",
                        React.createElement("code", null, project.id),
                        ".")) : (React.createElement("div", { className: approvals_module_scss_1.default.staffGrid }, staff.map(function (member, idx) { return (React.createElement("div", { key: "".concat(member.name, "-").concat(idx), className: approvals_module_scss_1.default.staffCard },
                        React.createElement("div", { className: approvals_module_scss_1.default.staffCardTop },
                            React.createElement("span", { className: approvals_module_scss_1.default.roleBadge }, member.role),
                            React.createElement("span", { className: approvals_module_scss_1.default.matchScore },
                                member.match,
                                "% match")),
                        React.createElement("div", { className: approvals_module_scss_1.default.staffProfile },
                            React.createElement("div", { className: approvals_module_scss_1.default.staffAvatar }, member.initials),
                            React.createElement("div", null,
                                React.createElement("p", { className: approvals_module_scss_1.default.staffName }, member.name),
                                React.createElement("p", { className: approvals_module_scss_1.default.staffDept }, member.department))),
                        React.createElement("div", { className: approvals_module_scss_1.default.staffStats },
                            React.createElement("span", null,
                                "Avail ",
                                React.createElement("strong", null,
                                    member.availability,
                                    "%")),
                            React.createElement("span", null,
                                "Success ",
                                React.createElement("strong", null,
                                    member.success,
                                    "%"))))); }))))),
                step === 2 && (React.createElement(React.Fragment, null,
                    React.createElement("div", { className: approvals_module_scss_1.default.planSummaryRow },
                        React.createElement("div", { className: approvals_module_scss_1.default.planKpi },
                            React.createElement("span", { className: approvals_module_scss_1.default.planKpiIcon }, "\uD83D\uDCCB"),
                            React.createElement("div", null,
                                React.createElement("span", { className: approvals_module_scss_1.default.planKpiLabel }, "Total Tasks"),
                                React.createElement("span", { className: approvals_module_scss_1.default.planKpiValue }, planItems.length))),
                        React.createElement("div", { className: approvals_module_scss_1.default.planKpi },
                            React.createElement("span", { className: approvals_module_scss_1.default.planKpiIcon }, "\u23F1\uFE0F"),
                            React.createElement("div", null,
                                React.createElement("span", { className: approvals_module_scss_1.default.planKpiLabel }, "Total Effort"),
                                React.createElement("span", { className: approvals_module_scss_1.default.planKpiValue },
                                    totalEfforts,
                                    "h"))),
                        React.createElement("div", { className: approvals_module_scss_1.default.planKpi },
                            React.createElement("span", { className: approvals_module_scss_1.default.planKpiIcon }, "\uD83D\uDDC2\uFE0F"),
                            React.createElement("div", null,
                                React.createElement("span", { className: approvals_module_scss_1.default.planKpiLabel }, "Features"),
                                React.createElement("span", { className: approvals_module_scss_1.default.planKpiValue }, uniqueFeatures))),
                        React.createElement("div", { className: approvals_module_scss_1.default.planKpi },
                            React.createElement("span", { className: approvals_module_scss_1.default.planKpiIcon }, "\uD83D\uDC65"),
                            React.createElement("div", null,
                                React.createElement("span", { className: approvals_module_scss_1.default.planKpiLabel }, "Team Size"),
                                React.createElement("span", { className: approvals_module_scss_1.default.planKpiValue }, staff.length)))),
                    React.createElement("div", { className: approvals_module_scss_1.default.planReviewWrap },
                        React.createElement("table", { className: approvals_module_scss_1.default.planTable },
                            React.createElement("thead", null,
                                React.createElement("tr", null,
                                    React.createElement("th", null, "#"),
                                    React.createElement("th", null, "Feature"),
                                    React.createElement("th", null, "Task"),
                                    React.createElement("th", null, "Type"),
                                    React.createElement("th", null, "Start Date"),
                                    React.createElement("th", null, "End Date"),
                                    React.createElement("th", { className: approvals_module_scss_1.default.centered }, "Efforts (h)"),
                                    React.createElement("th", null, "Assignee"),
                                    React.createElement("th", { className: approvals_module_scss_1.default.centered }, "Status"))),
                            React.createElement("tbody", null, planItems.map(function (item, idx) { return (React.createElement("tr", { key: idx },
                                React.createElement("td", { className: approvals_module_scss_1.default.planIndexCell }, idx + 1),
                                React.createElement("td", { className: approvals_module_scss_1.default.planFeatureCell }, item.feature),
                                React.createElement("td", { className: approvals_module_scss_1.default.planTaskCell }, item.task),
                                React.createElement("td", null,
                                    React.createElement("span", { className: "".concat(approvals_module_scss_1.default.planLaneBadge, " ").concat(getLaneCls(item.lane)) }, item.lane)),
                                React.createElement("td", { className: approvals_module_scss_1.default.planDateCell }, item.startDate),
                                React.createElement("td", { className: approvals_module_scss_1.default.planDateCell }, item.endDate),
                                React.createElement("td", { className: approvals_module_scss_1.default.planEffortsCell }, item.efforts),
                                React.createElement("td", { className: approvals_module_scss_1.default.planAssigneeCell },
                                    React.createElement("div", { className: approvals_module_scss_1.default.planAvatarWrap },
                                        React.createElement("div", { className: approvals_module_scss_1.default.planAvatar }, initials(item.assignee)),
                                        item.assignee)),
                                React.createElement("td", null,
                                    React.createElement("span", { className: "".concat(approvals_module_scss_1.default.planStatusBadge, " ").concat(getStatusCls(item.status)) }, item.status)))); })))))),
                step === 3 && (React.createElement("div", { className: approvals_module_scss_1.default.successPanel },
                    React.createElement("div", { className: approvals_module_scss_1.default.successHero },
                        React.createElement("div", { className: approvals_module_scss_1.default.successHalo }),
                        React.createElement("div", { className: approvals_module_scss_1.default.successIcon },
                            React.createElement(CheckSvgIcon, null))),
                    React.createElement("h2", { className: approvals_module_scss_1.default.successTitle }, "Project Approved Successfully!"),
                    React.createElement("p", { className: approvals_module_scss_1.default.successDesc },
                        React.createElement("strong", null, project.name),
                        " has been approved and is now authorized. All stakeholders have been notified and the project is ready to proceed."),
                    React.createElement("div", { className: approvals_module_scss_1.default.successMeta },
                        React.createElement("span", { className: approvals_module_scss_1.default.successMetaTag },
                            "\u2713 ",
                            project.id),
                        React.createElement("span", { className: approvals_module_scss_1.default.successMetaTag },
                            "\u2713 ",
                            staff.length,
                            " staff allocated"),
                        React.createElement("span", { className: approvals_module_scss_1.default.successMetaTag }, "\u2713 Plan authorized"))))),
            step < 3 && (React.createElement("div", { className: approvals_module_scss_1.default.dialogFooter },
                React.createElement("button", { type: "button", className: approvals_module_scss_1.default.btnBack, onClick: function () { return step > 1 ? setStep((step - 1)) : onClose(); } }, step === 1 ? 'Cancel' : '← Back'),
                React.createElement("div", { className: approvals_module_scss_1.default.footerRight },
                    step === 2 && (React.createElement("button", { type: "button", className: approvals_module_scss_1.default.btnReject, onClick: onReject }, "\u2715 Reject Project")),
                    step === 1 && (React.createElement("button", { type: "button", className: approvals_module_scss_1.default.btnNext, onClick: function () { return setStep(2); } },
                        "Next \u2014 Review Plan ",
                        React.createElement(ChevronRightIcon, null))),
                    step === 2 && (React.createElement("button", { type: "button", className: approvals_module_scss_1.default.btnApprove, disabled: approving, onClick: function () { handleApprove().catch(console.error); } }, approving ? 'Approving…' : '✓ Approve Project')),
                    approveError && (React.createElement("p", { className: css.approveError, role: "alert" }, approveError))))))));
};
var Approvals = function (_a) {
    var onNavigate = _a.onNavigate;
    var css = approvals_module_scss_1.default;
    var _b = React.useState([]), projects = _b[0], setProjects = _b[1];
    var _c = React.useState(0), approvedCount = _c[0], setApprovedCount = _c[1];
    var _d = React.useState(true), loading = _d[0], setLoading = _d[1];
    var _e = React.useState(null), fetchError = _e[0], setFetchError = _e[1];
    var _f = React.useState(null), reviewProject = _f[0], setReviewProject = _f[1];
    var pending = projects.filter(function (p) { return p.status === 'Pending'; }).length;
    var approved = approvedCount;
    var total = pending + approved;
    var fetchApprovals = React.useCallback(function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, projectFields, spItems, approvedTotal, approvedItems, _a, allProjects, participations_1, _b, taskItems_1, _c, mapped, error_3;
        var _d, _e, _f;
        return tslib_1.__generator(this, function (_g) {
            switch (_g.label) {
                case 0:
                    _g.trys.push([0, 15, 16, 17]);
                    setLoading(true);
                    setFetchError(null);
                    sp = (0, initservice_1.getSP)();
                    projectFields = [
                        'Id', 'ProjectCode', 'ProjectName', 'Client', 'StartDate', 'EndDate',
                        'Budget', 'RequiredSkills', 'Description', 'Priority', 'isManagerApproved'
                    ];
                    spItems = [];
                    approvedTotal = 0;
                    _g.label = 1;
                case 1:
                    _g.trys.push([1, 4, , 6]);
                    return [4 /*yield*/, (_d = sp.web.lists
                            .getByTitle('Project')
                            .items)
                            .select.apply(_d, projectFields).filter('isManagerApproved eq false')
                            .top(5000)()];
                case 2:
                    spItems = _g.sent();
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle('Project')
                            .items
                            .select('Id')
                            .filter('isManagerApproved eq true')
                            .top(5000)()];
                case 3:
                    approvedItems = _g.sent();
                    approvedTotal = approvedItems.length;
                    return [3 /*break*/, 6];
                case 4:
                    _a = _g.sent();
                    return [4 /*yield*/, (_e = sp.web.lists
                            .getByTitle('Project')
                            .items)
                            .select.apply(_e, projectFields).top(5000)()];
                case 5:
                    allProjects = _g.sent();
                    spItems = allProjects.filter(isManagerApprovedFalse);
                    approvedTotal = allProjects.filter(function (item) { return getManagerApprovedValue(item) === true; }).length;
                    return [3 /*break*/, 6];
                case 6:
                    // Ensure only isManagerApproved === false (exclude null / true)
                    spItems = spItems.filter(isManagerApprovedFalse);
                    setApprovedCount(approvedTotal);
                    participations_1 = [];
                    _g.label = 7;
                case 7:
                    _g.trys.push([7, 9, , 10]);
                    return [4 /*yield*/, (_f = sp.web.lists
                            .getByTitle('ProjectParticipation')
                            .items)
                            .select.apply(_f, PARTICIPATION_SELECT).top(5000)()];
                case 8:
                    participations_1 = _g.sent();
                    return [3 /*break*/, 10];
                case 9:
                    _b = _g.sent();
                    participations_1 = [];
                    return [3 /*break*/, 10];
                case 10:
                    taskItems_1 = [];
                    _g.label = 11;
                case 11:
                    _g.trys.push([11, 13, , 14]);
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle('TaskDetails')
                            .items
                            .select('Task', 'Sno', 'ProjectCode', 'Assignee', 'lane', 'Effort', 'Status', 'StartDate', 'EndDate')
                            .top(5000)()];
                case 12:
                    taskItems_1 = _g.sent();
                    return [3 /*break*/, 14];
                case 13:
                    _c = _g.sent();
                    taskItems_1 = [];
                    return [3 /*break*/, 14];
                case 14:
                    mapped = spItems.map(function (item) {
                        var _a;
                        var projectCode = (getFieldValue(item, 'ProjectCode') || '').toString();
                        var spItemId = Number((_a = item.Id) !== null && _a !== void 0 ? _a : getFieldValue(item, 'Id')) || 0;
                        var budgetNum = parseBudget(getFieldValue(item, 'Budget'));
                        var skillsRaw = getFieldValue(item, 'RequiredSkills') || '';
                        var skills = skillsRaw
                            ? skillsRaw.split(',').map(function (s) { return s.trim(); }).filter(Boolean)
                            : [];
                        var members = participations_1
                            .filter(function (p) { return projectCodesMatch(getParticipationProjectCode(p), projectCode) && getParticipationName(p); })
                            .map(function (p) { return getParticipationName(p); });
                        var staff = participations_1
                            .filter(function (p) { return projectCodesMatch(getParticipationProjectCode(p), projectCode) && getParticipationName(p); })
                            .map(mapParticipationToStaff);
                        var planItems = taskItems_1
                            .filter(function (t) { return projectCodesMatch(String(getFieldValue(t, 'ProjectCode') || ''), projectCode); })
                            .map(function (t, idx) { return mapTaskToPlanItem(t, idx); })
                            .sort(function (a, b) { return a.slNo - b.slNo; });
                        var visibleTeam = members.slice(0, 3).map(getInitials);
                        return {
                            spItemId: spItemId,
                            id: projectCode || "PRJ-".concat(spItemId),
                            name: (getFieldValue(item, 'ProjectName') || 'Untitled Project').toString(),
                            subtitle: (getFieldValue(item, 'Description') || '').toString(),
                            client: (getFieldValue(item, 'Client') || '—').toString(),
                            budget: "$".concat(budgetNum.toLocaleString()),
                            startDate: formatDate(getFieldValue(item, 'StartDate') || ''),
                            endDate: formatDate(getFieldValue(item, 'EndDate') || ''),
                            priority: normalisePriority(getFieldValue(item, 'Priority') || ''),
                            skills: skills,
                            team: visibleTeam,
                            teamExtra: Math.max(0, members.length - 3),
                            status: 'Pending',
                            staff: staff,
                            planItems: planItems
                        };
                    });
                    setProjects(mapped);
                    return [3 /*break*/, 17];
                case 15:
                    error_3 = _g.sent();
                    console.error('Approvals: Error fetching projects from SharePoint:', error_3);
                    setProjects([]);
                    setApprovedCount(0);
                    setFetchError('Could not load projects from SharePoint. Please refresh and try again.');
                    return [3 /*break*/, 17];
                case 16:
                    setLoading(false);
                    return [7 /*endfinally*/];
                case 17: return [2 /*return*/];
            }
        });
    }); }, []);
    React.useEffect(function () {
        fetchApprovals().catch(console.error);
    }, [fetchApprovals]);
    var handleApprove = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!reviewProject) {
                        throw new Error('No project selected for approval');
                    }
                    if (!reviewProject.spItemId || reviewProject.spItemId <= 0) {
                        throw new Error("Missing SharePoint item ID for project ".concat(reviewProject.id));
                    }
                    sp = (0, initservice_1.getSP)();
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle('Project')
                            .items
                            .getById(reviewProject.spItemId)
                            .update({ isManagerApproved: true })];
                case 1:
                    _a.sent();
                    setProjects(function (prev) { return prev.filter(function (p) { return p.id !== reviewProject.id; }); });
                    setApprovedCount(function (prev) { return prev + 1; });
                    return [2 /*return*/];
            }
        });
    }); };
    var handleReject = function () {
        if (!reviewProject)
            return;
        setProjects(function (prev) { return prev.filter(function (p) { return p.id !== reviewProject.id; }); });
        setReviewProject(null);
    };
    return (React.createElement("div", { className: css.page },
        React.createElement("div", { className: css.pageMesh, "aria-hidden": "true" }),
        React.createElement("div", { className: css.pageOrb, "aria-hidden": "true" }),
        React.createElement(navbar_1.default, { activeItem: "approvals", onNavigate: onNavigate, pendingApprovalsCount: projects.length }),
        React.createElement("main", { className: css.main },
            React.createElement("header", { className: css.topBar },
                React.createElement("div", { className: css.topBarLeft },
                    React.createElement("h2", { className: css.pageTitle }, "Approvals"),
                    React.createElement("span", { className: css.pageBadge }, "Manager Review")),
                React.createElement(UserBadge_1.default, { classNames: {
                        userBadge: css.userBadge,
                        userText: css.userText,
                        userName: css.userName,
                        userMail: css.userMail,
                        userAvatar: css.userAvatar
                    } })),
            React.createElement("section", { className: css.statsRow, "aria-label": "Approval summary" },
                React.createElement("article", { className: css.statCard },
                    React.createElement("p", { className: css.statLabel }, "Pending Approval"),
                    React.createElement("p", { className: css.statValue }, pending),
                    React.createElement("span", { className: css.statTrend }, "Requires action")),
                React.createElement("article", { className: css.statCard },
                    React.createElement("p", { className: css.statLabel }, "Approved"),
                    React.createElement("p", { className: css.statValue }, approved),
                    React.createElement("span", { className: css.statTrend, style: { color: '#10b981' } }, "Authorized")),
                React.createElement("article", { className: css.statCard },
                    React.createElement("p", { className: css.statLabel }, "Total Submitted"),
                    React.createElement("p", { className: css.statValue }, total),
                    React.createElement("span", { className: css.statTrend }, "This cycle"))),
            React.createElement("section", { className: css.card },
                React.createElement("div", { className: css.cardGlow, "aria-hidden": "true" }),
                React.createElement("div", { className: css.cardInner },
                    React.createElement("div", { className: css.cardHead },
                        React.createElement("div", null,
                            React.createElement("h3", null, "Pending Approval Queue"),
                            React.createElement("p", null, "Review and authorize submitted project intake requests before they are provisioned."))),
                    loading ? (React.createElement("div", { className: css.loadingWrap, "aria-live": "polite" },
                        React.createElement("div", { className: css.spinner }),
                        React.createElement("span", null, "Loading pending approvals\u2026"))) : fetchError ? (React.createElement("div", { className: css.emptyState, "aria-live": "polite" },
                        React.createElement("p", { className: css.emptyTitle }, "Unable to load approvals"),
                        React.createElement("p", { className: css.emptyDesc }, fetchError))) : projects.length === 0 ? (React.createElement("div", { className: css.emptyState, "aria-live": "polite" },
                        React.createElement("p", { className: css.emptyTitle }, "No pending approvals"),
                        React.createElement("p", { className: css.emptyDesc },
                            "Projects from the ",
                            React.createElement("strong", null, "Project"),
                            " list with ",
                            React.createElement("code", null, "isManagerApproved = false"),
                            " will appear here."))) : (React.createElement("div", { className: css.tableWrap },
                        React.createElement("table", { className: css.table },
                            React.createElement("thead", null,
                                React.createElement("tr", null,
                                    React.createElement("th", null, "Project ID"),
                                    React.createElement("th", null, "Project Name"),
                                    React.createElement("th", null, "Client"),
                                    React.createElement("th", null, "Priority"),
                                    React.createElement("th", null, "Start Date"),
                                    React.createElement("th", null, "End Date"),
                                    React.createElement("th", null, "Budget"),
                                    React.createElement("th", null, "Status"),
                                    React.createElement("th", null, "Action"))),
                            React.createElement("tbody", null, projects.map(function (project) { return (React.createElement("tr", { key: project.id, className: css.projectRow },
                                React.createElement("td", { className: css.idCell },
                                    React.createElement("span", { className: css.idPill }, project.id)),
                                React.createElement("td", { className: css.nameCell },
                                    React.createElement("strong", null, project.name),
                                    project.subtitle && React.createElement("span", null, project.subtitle)),
                                React.createElement("td", { className: css.dateCell }, project.client),
                                React.createElement("td", { className: css.dateCell }, project.priority),
                                React.createElement("td", { className: css.dateCell }, project.startDate || '—'),
                                React.createElement("td", { className: css.dateCell }, project.endDate || '—'),
                                React.createElement("td", { className: css.amountCell },
                                    React.createElement("span", { className: css.amountVal }, project.budget),
                                    React.createElement("small", null, "USD")),
                                React.createElement("td", null,
                                    React.createElement("span", { className: "".concat(css.statusPill, " ").concat(project.status === 'Approved' ? css.statusApproved
                                            : project.status === 'Rejected' ? css.statusRejected
                                                : css.statusPending) },
                                        React.createElement("span", { className: css.statusDot }),
                                        project.status)),
                                React.createElement("td", null,
                                    React.createElement("button", { type: "button", className: css.actionBtn, disabled: project.status !== 'Pending', onClick: function () { return setReviewProject(project); } }, "Review & Act")))); }))))),
                    React.createElement("div", { className: css.cardFoot },
                        React.createElement("span", null,
                            "Showing ",
                            React.createElement("strong", null, projects.length),
                            " of ",
                            React.createElement("strong", null, projects.length),
                            " submissions"),
                        React.createElement("span", { className: css.pendingHint },
                            "\u23F3 ",
                            pending,
                            " pending review"))))),
        reviewProject && (React.createElement(ReviewDialog, { project: reviewProject, onClose: function () { return setReviewProject(null); }, onApprove: function () { return handleApprove(); }, onReject: handleReject }))));
};
exports.default = Approvals;
//# sourceMappingURL=approvals.js.map