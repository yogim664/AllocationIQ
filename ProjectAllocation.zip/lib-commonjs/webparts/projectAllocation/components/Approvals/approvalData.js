"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchPendingApprovalsCount = fetchPendingApprovalsCount;
var tslib_1 = require("tslib");
var initservice_1 = require("../../../../service/initservice");
var getFieldValue = function (item, fieldName) {
    if (!item)
        return undefined;
    var lower = fieldName.toLowerCase();
    for (var _i = 0, _a = Object.keys(item); _i < _a.length; _i++) {
        var key = _a[_i];
        if (key.toLowerCase() === lower) {
            var val = item[key];
            if (val && typeof val === 'object') {
                if (val.LookupValue !== undefined)
                    return val.LookupValue;
                if (val.Title !== undefined)
                    return val.Title;
                if (val.Label !== undefined)
                    return val.Label;
            }
            return val;
        }
    }
    return undefined;
};
var getManagerApprovedValue = function (item) {
    var _a, _b, _c;
    var raw = (_c = (_b = (_a = item.isManagerApproved) !== null && _a !== void 0 ? _a : item.IsManagerApproved) !== null && _b !== void 0 ? _b : getFieldValue(item, 'isManagerApproved')) !== null && _c !== void 0 ? _c : getFieldValue(item, 'IsManagerApproved');
    if (raw === true || raw === 1 || raw === '1' || raw === 'true' || raw === 'Yes')
        return true;
    if (raw === false || raw === 0 || raw === '0' || raw === 'false' || raw === 'No')
        return false;
    return null;
};
var isManagerApprovedFalse = function (item) {
    return getManagerApprovedValue(item) === false;
};
/** Count of projects in the Pending Approval Queue (isManagerApproved === false). */
function fetchPendingApprovalsCount() {
    return tslib_1.__awaiter(this, void 0, void 0, function () {
        var sp, items, _a, allItems;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    sp = (0, initservice_1.getSP)();
                    _b.label = 1;
                case 1:
                    _b.trys.push([1, 3, , 5]);
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle('Project')
                            .items
                            .select('Id', 'isManagerApproved')
                            .filter('isManagerApproved eq false')
                            .top(5000)()];
                case 2:
                    items = _b.sent();
                    return [2 /*return*/, items.filter(isManagerApprovedFalse).length];
                case 3:
                    _a = _b.sent();
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle('Project')
                            .items
                            .select('Id', 'isManagerApproved')
                            .top(5000)()];
                case 4:
                    allItems = _b.sent();
                    return [2 /*return*/, allItems.filter(isManagerApprovedFalse).length];
                case 5: return [2 /*return*/];
            }
        });
    });
}
//# sourceMappingURL=approvalData.js.map