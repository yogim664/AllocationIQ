"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var UserContext_1 = require("./UserContext");
var UserBadge = function (_a) {
    var css = _a.classNames;
    var _b = (0, UserContext_1.useUser)(), displayName = _b.displayName, email = _b.email, initials = _b.initials, greeting = _b.greeting;
    return (React.createElement("div", { className: css.userBadge },
        React.createElement("div", { className: css.userText },
            React.createElement("p", { className: css.userName },
                greeting,
                ", ",
                displayName),
            email ? React.createElement("p", { className: css.userMail }, email) : null),
        React.createElement("div", { className: css.userAvatar, "aria-hidden": "true" }, initials)));
};
exports.default = UserBadge;
//# sourceMappingURL=UserBadge.js.map