"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.useUser = exports.UserContextProvider = void 0;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var defaultValue = {
    displayName: 'User',
    email: '',
    initials: 'U',
    greeting: 'Hi'
};
var UserContext = React.createContext(defaultValue);
var getInitials = function (fullName) {
    if (!fullName)
        return 'U';
    var parts = fullName.trim().split(/\s+/);
    if (parts.length === 1)
        return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
};
var UserContextProvider = function (_a) {
    var context = _a.context, children = _a.children;
    var displayName = context.pageContext.user.displayName || 'User';
    var email = context.pageContext.user.email || '';
    var value = React.useMemo(function () { return ({
        displayName: displayName,
        email: email,
        initials: getInitials(displayName),
        greeting: 'Hi'
    }); }, [displayName, email]);
    return (React.createElement(UserContext.Provider, { value: value }, children));
};
exports.UserContextProvider = UserContextProvider;
var useUser = function () { return React.useContext(UserContext); };
exports.useUser = useUser;
//# sourceMappingURL=UserContext.js.map