"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var form_1 = tslib_1.__importDefault(require("./Form/form"));
var dashboard_1 = tslib_1.__importDefault(require("./Dashboard/dashboard"));
var ProjectDetails_1 = tslib_1.__importDefault(require("./ProjectDetails/ProjectDetails"));
var approvals_1 = tslib_1.__importDefault(require("./Approvals/approvals"));
var employee_1 = tslib_1.__importDefault(require("./Employee/employee"));
var UserContext_1 = require("./UserContext/UserContext");
require("../assets/style.css");
var ProjectAllocation = function (_a) {
    var context = _a.context;
    var _b = React.useState('dashboard'), view = _b[0], setView = _b[1];
    var _c = React.useState(null), selectedProject = _c[0], setSelectedProject = _c[1];
    var handleNavigate = function (target) {
        if (target === 'dashboard' || target === 'approvals' || target === 'employee') {
            setView(target);
        }
    };
    return (React.createElement(UserContext_1.UserContextProvider, { context: context },
        React.createElement("div", { className: "aegisApp", style: {
                position: 'relative',
                minHeight: '100vh',
                padding: 0,
                margin: 0,
                width: '100%',
                maxWidth: '100%',
                display: 'flex',
                flexDirection: 'column',
                boxSizing: 'border-box'
            } },
            view === 'details' && selectedProject ? (React.createElement(ProjectDetails_1.default, { project: selectedProject, onBack: function () { return setView('dashboard'); } })) : view === 'approvals' ? (React.createElement(approvals_1.default, { onNavigate: handleNavigate })) : view === 'employee' ? (React.createElement(employee_1.default, { onNavigate: handleNavigate })) : (React.createElement(dashboard_1.default, { onCreateProject: function () { return setView('form'); }, onOpenProject: function (project) {
                    setSelectedProject(project);
                    setView('details');
                }, onNavigate: handleNavigate })),
            view === 'form' && (React.createElement("div", { style: {
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: 'rgba(15, 23, 42, 0.6)',
                    backdropFilter: 'blur(8px)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    zIndex: 9999,
                    padding: '24px 16px'
                } },
                React.createElement("div", { style: {
                        width: '90vw',
                        maxWidth: '1480px',
                        height: '90vh',
                        maxHeight: '860px',
                        position: 'relative',
                        display: 'flex',
                        flexDirection: 'column'
                    } },
                    React.createElement(form_1.default, { onClose: function () { return setView('dashboard'); } })))))));
};
exports.default = ProjectAllocation;
//# sourceMappingURL=ProjectAllocation.js.map